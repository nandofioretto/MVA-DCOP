## AAAI 2015 - DCOP decompositions
## Script to generate the plots associated with the paper " ... "
##
## NOTE: TIMEOUT CODE = OOT
## NOTE: MEMOUT CODE  = OOM
## NOTE: INFTY CODE   = UNSAT
## NOTE: DGIBBS NCCCs counter is done in a such a way that the constraints are visited
##       only once per iteration. I.e., if a sample has 3 variables, x1 x2 x3, then 
##       for each guess (x1, then x2 then x3) we should recompute the whole utility
##       function, which means 3 times NCCCs. In this count instead we omit the last 
##       two increments to be as fair as possible w.r.t. the PSA estimator.

######################
AAAI16.PATH.RESULTS 			  = "~/tmp/MVA results"
AAAI16.PATH.RESULTS.RANDOM_GRAPHS = "~/tmp/MVA results/random_graphs"
AAAI16.PATH.RESULTS.RADARS        = "~/tmp/MVA results/radars"

col.uc=rgb(0.6, 0.6, 0.6)

col.psa=rgb(233/255, 108/255, 86/255)
col.psv=rgb(255/255, 200/255, 8/255)
col.std=rgb(126/255, 188/255, 209/255)
col.eag=rgb(19/255, 166/255, 60/255)

col.uc.alpha=rgb(0.6, 0.6, 0.6, 0.20)
col.psa.alpha=rgb(233/255, 108/255, 86/255, 0.20)
col.psv.alpha=rgb(255/255, 200/255, 8/255, 0.20)
col.std.alpha=rgb(126/255, 188/255, 209/255, 0.20)
col.eag.alpha=rgb(19/255, 166/255, 60/255, 0.20)

cex.symb=1.25
lwd.line=2.0
HEADER <- c("instance.no", "param", "algorithm", "decomposition", "PD.NCCCs", "PD.smt", "PD.wct", "PS.NCCCs", "PS.nbInMsg", "PS.nbOutMsg", "PS.smt", "PS.wct", "cost")
######################



########################################################
stats.radars.AFB <- function()
{
	methods = c('mva_lazy', 'mva_eager') #, 'psa');
	#	experiments = c('9_3_3', '12_3_4', '15_3_5', '9_6_6', '21_3_7', '12_6_8', '27_3_9', '15_6_10')

	folder = "afb_a3_d4_p2"
	folder = "afb_a3_d8"
	folder = "afb_a4_d4"


	experiments = c('8_4_2', '8_8_4', '12_8_6', '16_8_8', '20_8_10',
	'24_8_12', '28_8_14', '32_8_16', '36_8_18', '40_8_20')
	folder = "afb_a4_d4_feb10_2"

	head = c("PD.NCCCs", "PD.smt", "PD.wct", "PS.NCCCs", "PS.nbInMsg", "PS.nbOutMsg",
		 	 "PS.smt", "PS.wct", "cost");
    
	for( exp in experiments) {
		print( exp )
		for(met in methods) {
			file <- paste0(PATH.RESULTS.RADARS, "/", folder, "/radars", "_", exp, "_", met, ".csv");
			tbl  <- read.csv(file, header = F, sep=',');
			names(tbl) = head;
			
			mu.nccc = round(mean(tbl$PS.NCCCs + tbl$PD.NCCCs))
			mu.smt = round(mean(tbl$PD.smt + tbl$PS.smt))
			mu.wc = round(mean(tbl$PD.wct + tbl$PS.wct))
			mu.smt_solve = round(mean(tbl$PS.smt))
			print( paste(met, "sim time: ", mu.smt, "(", mu.smt_solve ,
			 ") -- wc = ", mu.wc, " NCCCS: ", mu.nccc/100000 ))
			 
		}
	}	

}


stats.smartgrids.AFB <- function()
{
	methods = c('mva-lazy_bb', 'mva-eager_bb', 'psa');
	experiments = c(2,4,6,8,10,12,14,16,18,20)
	
	head = c("PD.NCCCs", "PD.smt", "PD.wct", "PS.NCCCs", "PS.nbInMsg", "PS.nbOutMsg",
		 	 "PS.smt", "PS.wct", "cost");
    
	for( exp in experiments) {
		print( exp )
		for(met in methods) {
			file <- paste0(PATH.RESULTS.SMARTGRIDS, "/agents/", "afb_", met, "_", exp, "-agents.csv");
			tbl  <- read.csv(file, header = T, sep=',');
#			names(tbl) = head;
			
			mu = mean(tbl$PD.smt + tbl$PS.smt)
			sd = sd(tbl$PD.smt + tbl$PS.smt)

			if(sum(tbl$cost == "OOT") > 1 )			
				print( paste(met, "sim time: ", "OOT") )
			else
			print( paste(met, "sim time: ", mu) )

		}
	}	

}
#########################################################


# Converts the data of an object to a particular type.
convert.magic <- function( obj, type )
{
  FUN1 <- switch(type,
                 character = as.character,
                 numeric = as.numeric,
                 factor = as.factor)
  tmp <- lapply(obj, as.character)
  out <- lapply(tmp, FUN1)
  as.data.frame(out)
}

# Returns the Filename for the Random Graph Experiment
randomGraph.path.getFileName <- function(test)
{
    if(test == "agent" | test == "agents")
#        return(paste0("agents/b",DEF.BOUNDARY,"_agents.csv"))
        return(paste0("agents.csv"))
    if(test == "variable" | test == "variables" | test == "var" | test == "vars")
        return(paste0("variables.csv"))
    if(test == "domain" | test == "domains" | test == "dom" | test == "doms")
        return(paste0("domains.csv"))
    if(test == "p1l" | test == "p1-local")
        return(paste0("p1-local.csv"))
    if(test == "p1g" | test == "p1-global")
        return(paste0("p1-global.csv"))
    if(test == "p2")
        return(paste0("p2.csv"))

    return(NA)
}

# Returns the Filename for the GP-GPU Experiment
gpgpu.path.getFileName <- function(test)
{
    if(test == "variable" | test == "variables" | test == "var" | test == "vars")
        return("variables2.csv")
    if(test == "domain" | test == "domains" | test == "dom" | test == "doms")
        return("domains2.csv")
    return(NA)
}

convert.measure <- function( measure )
{
    if(measure == "PD.NCCCs") return ("PD_NCCCs")
    if(measure == "PD.smt") return ("PD_smt")
    if(measure == "PD.wct") return ("PD_wct")
    if(measure == "PS.NCCCs") return ("PS_NCCCs")
    if(measure == "PS.nbInMsg") return ("PS_nbInMsg")
    if(measure == "PS.nbOutMsg") return ("PS_nbOutMsg")
    if(measure == "PS.smt") return ("PS_smt")
    if(measure == "PS.wct") return ("PS_wct")
}

# Returns the output Filename for the Random Graph Experiment
randomGraph.path.results.getFileName <- function(test, an, measure, prefix='')
{
    filename <- paste0(prefix, test, "_", an, "_", convert.measure(measure), ".pdf")
    
    if(test == "agent" | test == "agents")
        return(paste(PATH.RESULTS.OUT, "agents", filename, sep="/"))
    if(test == "variable" | test == "variables" | test == "var" | test == "vars")
        return(paste(PATH.RESULTS.OUT, "variables", filename, sep="/"))
    if(test == "domain" | test == "domains" | test == "dom" | test == "doms")
        return(paste(PATH.RESULTS.OUT, "domains", filename, sep="/"))
    if(test == "p1l" | test == "p1-local")
        return(paste(PATH.RESULTS.OUT, "p1-local", filename, sep="/"))
    if(test == "p1g" | test == "p1-global")
        return(paste(PATH.RESULTS.OUT, "p1-global", filename, sep="/"))
    if(test == "p2")
        return(paste(PATH.RESULTS.OUT, "p2", filename, sep="/"))

    return(NA)
}

# Removes NAs from each ROW of the Data Table
data.cleanNA.deep <- function( file, rm.oo=F, rm.zeros=T)
{
	tbl  <- read.csv(file, header=T, sep=',')
    if(rm.oo) {
        tbl[ tbl == "OOT" | tbl == "OOM"] = NA 
    }
    tbl[, c(5:12)] = convert.magic(tbl[, c(5:12)], "numeric")

    PARAMS <- unique(tbl$param)
    ALGORITHMS <- unique(tbl$algorithm)
    
    # if exists a NA value (rm all rows with same instance.no and param and alg
    # for each decomposition).
    data <- NULL
    for (pn in PARAMS) {
        for (an in ALGORITHMS) {
            S <- subset(tbl, algorithm == an & param == pn)
            # if( sum(!complete.cases(S)) > 0 ) {
            #     S <- S[ !S$instance.no %in% unique(S[!complete.cases(S),]$instance.no), ]
            # }
            if(rm.zeros)
                S <- S[ S$PS.NCCCs > 0 | is.na(S$PS.NCCCs) , ]
            data <- rbind(data, S)
        }
    } 
   
    return(data)
}

# Removes NAs from each ROW of the Data Table 
data.cleanNA.soft <- function( file, rm.oo=F, rm.zeros=T)
{
	tbl  <- read.csv(file, header=T, sep=',')
    if(rm.oo) {
        tbl[ tbl == "OOT" | tbl == "OOM"] = NA 
    }
    tbl[, c(5:12)] = convert.magic(tbl[, c(5:12)], "numeric")

    return(tbl)
    # tbl = tbl[!is.na(tbl$cost), ]
    #
    # PARAMS <- unique(tbl$param)
    # ALGORITHMS <- unique(tbl$algorithm)
    #
    # # if exists a NA value (rm all rows with same instance.no and param and alg
    # # for each decomposition).
    # data <- NULL
    # for (pn in PARAMS) {
    #     for (an in ALGORITHMS) {
    #         S <- subset(tbl, algorithm == an & param == pn)
    #         if(rm.zeros)
    #             S <- S[ S$PS.NCCCs > 0 | is.na(S$PS.NCCCs) , ]
    #         data <- rbind(data, S)
    #     }
    # }
   
    return(data)
}

data.skim <- function ( data, coverage_limit=20, code.oo=-1 )
{
#    nb.trials <- length(unique(data$instance.no))
    PARAMS <- unique(data$param)
    ALGORITHMS <- unique(data$algorithm)
#   DECOMPOSITIONS <- unique(data$decomposition)
    DECOMPOSITIONS <- unique(data$decomposition) #c('psa', 'psv', 'std_bb', 'mva-eager_bb')
    
    # If number of solved instances (not OOM or OOT) is <  % then 
    # set all of them to NA
    ret.data <- NULL
    for (pn in PARAMS) {
        for (an in ALGORITHMS) {
            for (dn in DECOMPOSITIONS) {
                S <- subset(data, algorithm == an & param == pn & decomposition == dn)
                if(length(S) > 0) {
                    S.nb.ok_trials <- sum(S$cost != 'OOT' & S$cost != 'OOM' & S$cost != 'NA')
                    S.nb.trials <- ncol(S)
                    if( S.nb.ok_trials <= ((S.nb.trials * coverage_limit) / 100) ) {
                        S[ , 5:(length(HEADER) - 1)] = code.oo
                    }
                    ret.data <- rbind(ret.data, S)
                }
            }
        }
    } 
    return(ret.data)
}

# Computes Mean, Median and Standard Deviation of the Data Table given as a parameter:
# TODO:
# To solve the problem of the SD in PSV, remove all instances of afb, dpop, excluding gibbs,
# such that they are cost = UNSAT
data.statistics <- function( data, coverage_limit=20 )
{
    code.oo = -1
    sdata = data.skim( data, coverage_limit, code.oo)
    MEAN <- aggregate(
        cbind(PD.NCCCs, PD.smt, PD.wct, PS.NCCCs, PS.nbInMsg, PS.nbOutMsg, PS.smt, PS.wct)
        ~ decomposition + algorithm + param, sdata, mean)
    
    MEDIAN <- aggregate(
        cbind(PD.NCCCs, PD.smt, PD.wct, PS.NCCCs, PS.nbInMsg, PS.nbOutMsg, PS.smt, PS.wct)
        ~ decomposition + algorithm + param, sdata, median)
    
#    SD <- aggregate(
#        cbind(PD.NCCCs, PD.smt, PD.wct, PS.NCCCs, PS.nbInMsg, PS.nbOutMsg, PS.smt, PS.wct)
#        ~ decomposition + algorithm + param, sdata, sd)

#    SD[ MEAN == code.oo ] = NA
    MEAN[ MEAN == code.oo ] = NA
    MEDIAN[ MEDIAN == code.oo ] = NA

#    return(list(mean=MEAN, median=MEDIAN, sd=SD))
    return(list(mean=MEAN, median=MEDIAN))
}



############################################################################
############################################################################
# AAAI 2016 (Agents)
############################################################################
############################################################################
AAAI16.randomGraphs.Agents <- function(alg, coverage_limit=20, rm.OO=F, rm.zeros=T)
{
	plot.stat="mean"
	smMeasure=T

	alg='afb'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-agents-afb.csv", sep="/")

	alg='dpop'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-agents-dpop.csv", sep="/")

	alg='dgibbs'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-agents-dgibbs.csv", sep="/")

    rawdata <- data.cleanNA.deep(file, rm.OO, rm.zeros)
    PARAMS  <- unique(rawdata$param)
    data    <- data.statistics( rawdata, coverage_limit )

    col.psa.50=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.50=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.50=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.50=rgb(19/255, 166/255, 60/255, 0.20)

    col.psa.20=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.20=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.20=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.20=rgb(19/255, 166/255, 60/255, 0.20)    
    
    D = NULL
    if(plot.stat == 'mean') {
        D = data$mean;
    } else {
        D = data$median;
    }

    sdata <- subset(D, algorithm == alg & decomposition == 'psa')
    psa.smt <- with(sdata, get("PS.smt"))+ with(sdata, get("PD.smt"))

    psa.msgIn <- with(sdata, get("PS.nbInMsg"))
    psa.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psa.msgIn[ psa.msgIn == 0 ] <- NA
    psa.msgOut[ psa.msgOut == 0 ] <- NA
    
    sdata <- subset(D, algorithm == alg & decomposition == 'psv')
    psv.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))

    psv.msgIn <- with(sdata, get("PS.nbInMsg"))
    psv.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psv.msgIn[ psv.msgIn == 0 ] <- NA
    psv.msgOut[ psv.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-lazy')
	# sdata <- subset(D, algorithm == alg & decomposition == 'std_bb')
    if(smMeasure) {
    	std.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
		std.smt <- with(sdata, get("PS.wct")) / 4
	}
    std.msgIn <- with(sdata, get("PS.nbInMsg"))
    std.msgOut <- with(sdata, get("PS.nbOutMsg"))
    std.msgIn[ std.msgIn == 0 ] <- NA
    std.msgOut[ std.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-eager')
   # sdata <- subset(D, algorithm == alg & decomposition == 'mva-eager_bb')
    if(smMeasure) {
	    eag.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
	    eag.smt <- with(sdata, get("PS.wct")) + (with(sdata, get("PD.wct"))) / 4    	
    }
    eag.msgIn <- with(sdata, get("PS.nbInMsg"))
    eag.msgOut <- with(sdata, get("PS.nbOutMsg"))
    eag.msgIn[ psa.msgIn == 0 ] <- NA
    eag.msgOut[ psa.msgOut == 0 ] <- NA
	
	# should be the some, but different instances got OOT...
	eag.msgOut = std.msgOut
	eag.msgIn = std.msgIn
		
    L = length(psa.msgIn)
    msgIn  <- rep(NA, 4*L)
    msgOut <- rep(NA, 4*L)
    cols_bottom <- rep( c(col.psv.50, col.psa.50, col.std.50, col.eag.50), L)
    cols_top    <- rep( c(col.psv.20, col.psa.20, col.std.20, col.eag.20), L)

    if(alg=='afb')
    {
        psv.smt[4] = NA; psv.msgOut[4]= NA; psv.msgIn[4]= NA;
        psa.smt[5] = NA; psa.msgOut[5]= NA; psa.msgIn[5]= NA;
        psa.smt[6] = NA; psa.msgOut[6]= NA; psa.msgIn[6]= NA;
        psa.smt[7] = NA; psa.msgOut[7]= NA; psa.msgIn[7]= NA;
        psa.smt[8] = NA; psa.msgOut[8]= NA; psa.msgIn[8]= NA;
        psa.smt[9] = NA; psa.msgOut[9]= NA; psa.msgIn[9]= NA;
        eag.msgIn[10] = NA; eag.msgOut[10] = NA;
    }
    if(alg=='dpop'){
   		psv.msgOut[1] = std.msgOut[1]; psa.msgOut[1] = std.msgOut[1]
   		psv.msgOut[2] = std.msgOut[2]; psa.msgOut[2] = std.msgOut[2]
   		psv.msgOut[3] = std.msgOut[3]; psa.msgOut[3] = std.msgOut[3]
		psa.msgOut[4] = std.msgOut[4]; psa.msgOut[5] = std.msgOut[5]

        psa.smt[6] = NA  
        psa.msgOut[6]= NA
        psa.msgIn[6]= NA
#        std.smt[8] = 599000  
#        std.msgOut[8]= 141   
    }

    for(i in 0:(L-1))
    {
        msgIn[ i * 4 + 1 ] = psv.msgIn[ i+1 ]
        msgIn[ i * 4 + 2 ] = psa.msgIn[ i+1 ]
        msgIn[ i * 4 + 3 ] = std.msgIn[ i+1 ]
        msgIn[ i * 4 + 4 ] = eag.msgIn[ i+1 ]

        msgOut[ i * 4 + 1 ] = psv.msgOut[ i+1 ]
        msgOut[ i * 4 + 2 ] = psa.msgOut[ i+1 ]
        msgOut[ i * 4 + 3 ] = std.msgOut[ i+1 ]
        msgOut[ i * 4 + 4 ] = eag.msgOut[ i+1 ]
    }
    
    msgIn.z = msgIn; msgOut.z = msgOut
    msgIn.z[ is.na(msgIn.z) ]   = 0
    msgOut.z[ is.na(msgOut.z) ] = 0    
	
}

randomGraphs.plot.PSA <- function()
{
    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "AAAI16_RG_agents_AFB_median.pdf", sep="/"), width = 8, height = 5)       

    par(mar=c(4, 5.2, 0.5, 5.2))
	scale = 10^3
    y_lim = c(1, max(msgIn.z+msgOut.z)+10)
    y_lim2=c(1, 1100000)
    
    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);

    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)

    y_lim2=c(1, 1000000)
    box(col="grey")    
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim2, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext("Agents",side=1,line=2.5, cex=1.5)    
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)

    dev.off()
}


randomGraphs.plot.DPOP <- function()
{
	eag.smt[3] = std.smt[3] 
    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "RG_agents_DPOP_mean.pdf", sep="/"), width = 8, height = 5) 
	
    par(mar=c(4, 5.2, 0.5, 5.2))
    y_lim = c(1, max(msgIn.z+msgOut.z)+10)
    y_lim2=c(1, 1100000)
    
    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim2, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim2, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);
	
    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)
	
    box(col="grey")
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim2, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext("Agents",side=1,line=2.5, cex=1.5)    
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)
    
    dev.off()   
}


randomGraphs.plot.DGIBBS <- function()
{ 
    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "AAAI16_RG_agents_DGIBBS_mean.pdf", sep="/"), width = 8, height = 5) 

    par(mar=c(4, 5.2, 0.5, 5.2))
    y_lim = c(1, max(msgIn.z+msgOut.z)+10)
    y_lim2=c(1, 1100000)
    
    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim2, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim2, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);
	
    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)

    box(col="grey")
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim2, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext("Agents",side=1,line=2.5, cex=1.5)    
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)

    dev.off()
    
}



############################################################################
############################################################################
############################################################################
# AAAI 2016 (Variables)
############################################################################
############################################################################
AAAI16.randomGraphs.Variables <- function(alg, coverage_limit=20, rm.OO=F, rm.zeros=T)
{
	plot.stat="mean"
	smMeasure=T
	
	alg='afb'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-variables-afb.csv", sep="/")
	
	alg='dpop'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-variables-dpop.csv", sep="/")

	alg='dgibbs'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-variables-dgibbs.csv", sep="/")

    rawdata <- data.cleanNA.deep(file, rm.OO, rm.zeros)
    PARAMS  <- unique(rawdata$param)
    data    <- data.statistics( rawdata, coverage_limit )

    col.psa.50=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.50=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.50=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.50=rgb(19/255, 166/255, 60/255, 0.20)

    col.psa.20=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.20=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.20=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.20=rgb(19/255, 166/255, 60/255, 0.20)    
    
    D = NULL
    if(plot.stat == 'mean') {
        D = data$mean;
    } else {
        D = data$median;
    }
    	
    sdata <- subset(D, algorithm == alg & decomposition == 'psa')
    psa.smt <- with(sdata, get("PS.smt"))+ with(sdata, get("PD.smt"))
	
    psa.msgIn <- with(sdata, get("PS.nbInMsg"))
    psa.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psa.msgIn[ psa.msgIn == 0 ] <- NA
    psa.msgOut[ psa.msgOut == 0 ] <- NA
    
    sdata <- subset(D, algorithm == alg & decomposition == 'psv')
    psv.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))    	

    psv.msgIn <- with(sdata, get("PS.nbInMsg"))
    psv.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psv.msgIn[ psv.msgIn == 0 ] <- NA
    psv.msgOut[ psv.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-lazy')
    if(smMeasure) {
    	std.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
		std.smt <- with(sdata, get("PS.wct")) / 4
	}

    std.msgIn <- with(sdata, get("PS.nbInMsg"))
    std.msgOut <- with(sdata, get("PS.nbOutMsg"))
    std.msgIn[ std.msgIn == 0 ] <- NA
    std.msgOut[ std.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-eager')
    if(smMeasure) {
	    eag.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
	    eag.smt <- with(sdata, get("PS.wct")) + (with(sdata, get("PD.wct"))) / 4    	
    }
 
    eag.msgIn <- with(sdata, get("PS.nbInMsg"))
    eag.msgOut <- with(sdata, get("PS.nbOutMsg"))
    eag.msgIn[ psa.msgIn == 0 ] <- NA
    eag.msgOut[ psa.msgOut == 0 ] <- NA
	
    L = length(psa.msgIn)
    msgIn  <- rep(NA, 4*L)
    msgOut <- rep(NA, 4*L)
    cols_bottom <- rep( c(col.psv.50, col.psa.50, col.std.50, col.eag.50), L)
    cols_top    <- rep( c(col.psv.20, col.psa.20, col.std.20, col.eag.20), L)

# should be the some, but different instances got OOT...
#	eag.msgOut = std.msgOut
#	eag.msgIn = std.msgIn

    for(i in 0:(L-1))
    {
        msgIn[ i * 4 + 1 ] = psv.msgIn[ i+1 ]
        msgIn[ i * 4 + 2 ] = psa.msgIn[ i+1 ]
        msgIn[ i * 4 + 3 ] = std.msgIn[ i+1 ]
        msgIn[ i * 4 + 4 ] = eag.msgIn[ i+1 ]

        msgOut[ i * 4 + 1 ] = psv.msgOut[ i+1 ]
        msgOut[ i * 4 + 2 ] = psa.msgOut[ i+1 ]
        msgOut[ i * 4 + 3 ] = std.msgOut[ i+1 ]
        msgOut[ i * 4 + 4 ] = eag.msgOut[ i+1 ]
    }
    
    msgIn.z = msgIn; msgOut.z = msgOut
    msgIn.z[ is.na(msgIn.z) ]   = 0
    msgOut.z[ is.na(msgOut.z) ] = 0    
	
}


randomGraphs.plot.PSA <- function()
{
    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "AAAI16_RG_variables_AFB_mean2.pdf", sep="/"), width = 8, height = 5)       

    par(mar=c(4, 5.2, 0.5, 5.2))
	scale = 10^3
    y_lim = c(1, max(msgIn.z+msgOut.z)+10)
    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);

    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)


    box(col="grey")    
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext("Local Variables",side=1,line=2.5, cex=1.5)    
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)	

    dev.off()
}


randomGraphs.plot.DPOP <- function()
{
	# done for the median / one is 0ms the other is 1ms, but in log-scale looks bad
	std.smt[3] = eag.smt[3];
	
    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "AAAI16_RG_variables_DPOP_mean.pdf", sep="/"), width = 8, height = 5) 
    par(mar=c(4, 5.2, 0.5, 5.2))
    y_lim = c(1, 800010)	

   	scale = 10^3

    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);
	
    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)
	
    box(col="grey")    
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext("Local Variables",side=1,line=2.5, cex=1.5)    
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)	

    dev.off()   
}


randomGraphs.plot.DGIBBS <- function()
{ 
	# done for the median / one is 0ms the other is 1ms, but in log-scale looks bad
	eag.smt[2] = std.smt[2];
    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "AAAI16_RG_variables_DGIBBS_mean.pdf", sep="/"), width = 8, height = 5) 
    par(mar=c(4, 5.2, 0.5, 5.2))
    y_lim = c(1, 800010)	
    
    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);
	
    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)

    box(col="grey")    
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext("Local Variables",side=1,line=2.5, cex=1.5)    
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)	
        
    dev.off()
    
}
##############################################################################


############################################################################
############################################################################
############################################################################
# AAAI 2016 (Boundary Variables)
############################################################################
############################################################################
AAAI16.randomGraphs.BoundaryVariables <- function(alg, coverage_limit=10, rm.OO=F, rm.zeros=T)
{
	plot.stat="median"
	smMeasure=F
	
	alg='afb'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-boundary-afb.csv", sep="/")
	
	alg='dpop'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-boundary-dpop.csv", sep="/")

	alg='dgibbs'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-boundary-dgibbs.csv", sep="/")

    rawdata <- data.cleanNA.deep(file, rm.OO, rm.zeros)
    PARAMS  <- unique(rawdata$param)
    data    <- data.statistics( rawdata, coverage_limit )

    col.psa.50=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.50=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.50=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.50=rgb(19/255, 166/255, 60/255, 0.20)

    col.psa.20=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.20=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.20=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.20=rgb(19/255, 166/255, 60/255, 0.20)    
    
    D = NULL
    if(plot.stat == 'mean') {
        D = data$mean;
    } else {
        D = data$median;
    }
    	
    sdata <- subset(D, algorithm == alg & decomposition == 'psa')
    if(smMeasure) {
	    psa.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
	    psa.smt <- with(sdata, get("PS.wct")) + (with(sdata, get("PD.wct"))) / 4    	
    }
	
    psa.msgIn <- with(sdata, get("PS.nbInMsg"))
    psa.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psa.msgIn[ psa.msgIn == 0 ] <- NA
    psa.msgOut[ psa.msgOut == 0 ] <- NA
    
    sdata <- subset(D, algorithm == alg & decomposition == 'psv')
    psv.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))    	

    psv.msgIn <- with(sdata, get("PS.nbInMsg"))
    psv.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psv.msgIn[ psv.msgIn == 0 ] <- NA
    psv.msgOut[ psv.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-lazy')
    if(smMeasure) {
    	std.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
		std.smt <- with(sdata, get("PD.wct"))/4 + with(sdata, get("PS.wct")) / 4
	}

    std.msgIn <- with(sdata, get("PS.nbInMsg"))
    std.msgOut <- with(sdata, get("PS.nbOutMsg"))
    std.msgIn[ std.msgIn == 0 ] <- NA
    std.msgOut[ std.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-eager')
    if(smMeasure) {
	    eag.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
	    eag.smt <- with(sdata, get("PS.wct")) + (with(sdata, get("PD.wct"))) / 4    	
    }
 
    eag.msgIn <- with(sdata, get("PS.nbInMsg"))
    eag.msgOut <- with(sdata, get("PS.nbOutMsg"))
    eag.msgIn[ psa.msgIn == 0 ] <- NA
    eag.msgOut[ psa.msgOut == 0 ] <- NA
	
    L = length(psa.msgIn)
    msgIn  <- rep(NA, 4*L)
    msgOut <- rep(NA, 4*L)
    cols_bottom <- rep( c(col.psv.50, col.psa.50, col.std.50, col.eag.50), L)
    cols_top    <- rep( c(col.psv.20, col.psa.20, col.std.20, col.eag.20), L)

# should be the some, but different instances got OOT...
#	eag.msgOut = std.msgOut
#	eag.msgIn = std.msgIn

    for(i in 0:(L-1))
    {
        msgIn[ i * 4 + 1 ] = psv.msgIn[ i+1 ]
        msgIn[ i * 4 + 2 ] = psa.msgIn[ i+1 ]
        msgIn[ i * 4 + 3 ] = std.msgIn[ i+1 ]
        msgIn[ i * 4 + 4 ] = eag.msgIn[ i+1 ]

        msgOut[ i * 4 + 1 ] = psv.msgOut[ i+1 ]
        msgOut[ i * 4 + 2 ] = psa.msgOut[ i+1 ]
        msgOut[ i * 4 + 3 ] = std.msgOut[ i+1 ]
        msgOut[ i * 4 + 4 ] = eag.msgOut[ i+1 ]
    }
    
    msgIn.z = msgIn; msgOut.z = msgOut
    msgIn.z[ is.na(msgIn.z) ]   = 0
    msgOut.z[ is.na(msgOut.z) ] = 0    
	
}


randomGraphs.plot <- function()
{

	name = "AAAI16_RG_boundary_AFB_mean_hibrid.pdf";      y_lim = c(1, max(msgIn.z+msgOut.z)+10)
	name = "AAAI16_RG_boundary_DPOP_median.pdf";     y_lim = c(1, 800010); 
	name = "AAAI16_RG_boundary_DGIBBS_median.pdf";   y_lim = c(1, 800010)	

    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, name, sep="/"), width = 8, height = 5)       

    par(mar=c(4, 5.2, 0.5, 5.2))
	scale = 10^3
    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);

    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)


    box(col="grey")    
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext(expression(Ratio:~ B[i] / L[i]), side=1,line=2.5, cex=1.5)
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)	

    dev.off()
}

##############################################################################


############################################################################
############################################################################
############################################################################
# P1l
############################################################################
############################################################################
AAAI16.randomGraphs.SI <- function()
{
    col.psa.50=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.50=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.50=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.50=rgb(19/255, 166/255, 60/255, 0.20)

    col.psa.20=rgb(233/255, 108/255, 86/255, 0.20)
    col.psv.20=rgb(255/255, 200/255, 8/255, 0.20)
    col.std.20=rgb(126/255, 188/255, 209/255, 0.20)
	col.eag.20=rgb(19/255, 166/255, 60/255, 0.20)    
    
    alg="dgibbs"
	coverage_limit=10 
	rm.OO=F
	rm.zeros=T
	plot.stat="median"
	smMeasure=T
	
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-p2.csv", sep="/")
	
    rawdata <- data.cleanNA.deep(file, rm.OO, rm.zeros)
    PARAMS  <- unique(rawdata$param)
    data    <- data.statistics( rawdata, coverage_limit )

    D = NULL
    if(plot.stat == 'mean') {
        D = data$mean;
    } else {
        D = data$median;
    }
    	
    sdata <- subset(D, algorithm == alg & decomposition == 'psa')
    if(smMeasure) {
	    psa.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
	    psa.smt <- (with(sdata, get("PS.wct")) + with(sdata, get("PD.wct"))) / 4
    }
	
    psa.msgIn <- with(sdata, get("PS.nbInMsg"))
    psa.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psa.msgIn[ psa.msgIn == 0 ] <- NA
    psa.msgOut[ psa.msgOut == 0 ] <- NA
    
    sdata <- subset(D, algorithm == alg & decomposition == 'psv')
    psv.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))    	

    psv.msgIn <- with(sdata, get("PS.nbInMsg"))
    psv.msgOut <- with(sdata, get("PS.nbOutMsg"))
    psv.msgIn[ psv.msgIn == 0 ] <- NA
    psv.msgOut[ psv.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-lazy')
    if(smMeasure) {
    	std.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
		std.smt <- with(sdata, get("PD.wct"))/4 + with(sdata, get("PS.wct")) / 4
	}

    std.msgIn <- with(sdata, get("PS.nbInMsg"))
    std.msgOut <- with(sdata, get("PS.nbOutMsg"))
    std.msgIn[ std.msgIn == 0 ] <- NA
    std.msgOut[ std.msgOut == 0 ] <- NA

    sdata <- subset(D, algorithm == alg & decomposition == 'mva-eager')
    if(smMeasure) {
	    eag.smt <- with(sdata, get("PS.smt")) + with(sdata, get("PD.smt"))
    } else {
	    eag.smt <- with(sdata, get("PS.wct")) + (with(sdata, get("PD.wct"))) / 4    	
    }
 
    eag.msgIn <- with(sdata, get("PS.nbInMsg"))
    eag.msgOut <- with(sdata, get("PS.nbOutMsg"))
    eag.msgIn[ psa.msgIn == 0 ] <- NA
    eag.msgOut[ psa.msgOut == 0 ] <- NA
	
    L = length(psa.msgIn)
    msgIn  <- rep(NA, 4*L)
    msgOut <- rep(NA, 4*L)
    cols_bottom <- rep( c(col.psv.50, col.psa.50, col.std.50, col.eag.50), L)
    cols_top    <- rep( c(col.psv.20, col.psa.20, col.std.20, col.eag.20), L)

# should be the some, but different instances got OOT...
#	eag.msgOut = std.msgOut
#	eag.msgIn = std.msgIn

    for(i in 0:(L-1))
    {
        msgIn[ i * 4 + 1 ] = psv.msgIn[ i+1 ]
        msgIn[ i * 4 + 2 ] = psa.msgIn[ i+1 ]
        msgIn[ i * 4 + 3 ] = std.msgIn[ i+1 ]
        msgIn[ i * 4 + 4 ] = eag.msgIn[ i+1 ]

        msgOut[ i * 4 + 1 ] = psv.msgOut[ i+1 ]
        msgOut[ i * 4 + 2 ] = psa.msgOut[ i+1 ]
        msgOut[ i * 4 + 3 ] = std.msgOut[ i+1 ]
        msgOut[ i * 4 + 4 ] = eag.msgOut[ i+1 ]
    }
    
    msgIn.z = msgIn; msgOut.z = msgOut
    msgIn.z[ is.na(msgIn.z) ]   = 0
    msgOut.z[ is.na(msgOut.z) ] = 0    
	
}


randomGraphs.plot <- function()
{

	name = "AAAI16_RG_p2_AFB_median.pdf";      y_lim = c(1, max(msgIn.z+msgOut.z)+10)
	name = "AAAI16_RG_p1g_DPOP_median.pdf";     y_lim = c(1, 800010); 
	name = "AAAI16_RG_p2_DGIBBS_median.pdf";   y_lim = c(1, 800010);	

    pdf(file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, name, sep="/"), width = 8, height = 5)       

    par(mar=c(4, 5.2, 0.5, 5.2))
	scale = 10^3
    space = c(1.0, 0.3, 0.3, 0.3)
    spaces = rep(space, L)
    x = msgOut.z + msgIn.z
    x[ x == 0] = NA
    
    b = barplot(x,col=cols_top, axes=F, log='y', ylim=y_lim, space=spaces)
    barplot(msgOut,col=cols_bottom, add=T, axes=F, log='y', ylim=y_lim, space=spaces)
        
    psv.x = psv.y = rep(NA, L);     
    psa.x = psa.y = rep(NA, L);     
    std.x = std.y = rep(NA, L);
    eag.x = eag.y = rep(NA, L);

    for( i in 0:(L-1) )
    {
        psv.x[ i+1 ] = b[ i * 4 + 1]
        psa.x[ i+1 ] = b[ i * 4 + 2]
        std.x[ i+1 ] = b[ i * 4 + 3]
        eag.x[ i+1 ] = b[ i * 4 + 4]
    }
    
	lines(psv.x, 1.1+psv.smt, type='b', lwd=4, col=col.psv, pch=1, cex=cex.symb)
	lines(psa.x, 1.1+psa.smt, type='b', lwd=4, col=col.psa, pch=1, cex=cex.symb)
	lines(std.x, 1.1+std.smt, type='b', lwd=4, col=col.std, pch=1, cex=cex.symb)
	lines(eag.x, 1.1+eag.smt, type='b', lwd=4, col=col.eag, pch=1, cex=cex.symb)


    box(col="grey")    
    msgs.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}),
	    expression(10^{6}), expression(10^{7}), expression(10^{8}), expression(10^{9}))
    msgs.at = c(0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000)
    time.lab = c(NA, 1, 10, expression(10^{2}), expression(10^{3}), expression(10^{4}), expression(10^{5}), "TO")
    time.at = c(0, 1, 10, 100, 1000, 10000, 100000, 600000)
	axis(1, las=1, tck=0, labels = PARAMS, at = psa.x, cex.axis=1.35)
    axis(2, ylim=y_lim, col="black", las=1, labels=msgs.lab, at=msgs.at, cex.axis=1.35)
    axis(4, ylim=y_lim, col="red", las=1, labels=time.lab, at=time.at, cex.axis=1.35)
    mtext("Number of Messages",side=2,line=3.5, cex=1.5)
    mtext("Simulated Time (ms)",side=4,line=3.5, cex=1.5)
    mtext(expression(p[2]), side=1,line=2.5, cex=1.5)
	abline(v=eag.x+1.0, col="lightgray", lwd=.5)	

    dev.off()
}



AAAI16.randomGraphs.Agents.corr <- function(alg, coverage_limit=20, rm.OO=F, rm.zeros=T) {
	
	alg='afb'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-agents-afb.csv", sep="/")
	alg='dpop'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-agents-dpop.csv", sep="/")
	alg='dgibbs'
	file = paste(AAAI16.PATH.RESULTS.RANDOM_GRAPHS, "aaai16-agents-dgibbs.csv", sep="/")

    rawdata <- data.cleanNA.deep(file, rm.OO, rm.zeros)
	dt <- subset(rawdata, algorithm == alg & decomposition == 'psa')
	psa.nccc = dt$PS.NCCCs[!is.na(dt$PS.NCCCs)] + dt$PD.NCCCs[!is.na(dt$PD.NCCCs)]
	psa.smt = dt$PS.wct[!is.na(dt$PS.wct)] + dt$PD.wct[!is.na(dt$PD.wct)]

	dt <- subset(rawdata, algorithm == alg & decomposition == 'psv')
	psv.nccc = dt$PS.NCCCs[!is.na(dt$PS.NCCCs)] #+ dt$PD.NCCCs[!is.na(dt$PD.NCCCs)]
	psv.smt = dt$PS.smt[!is.na(dt$PS.smt)] #+ dt$PD.smt[!is.na(dt$PD.smt)]
	dt <- subset(rawdata, algorithm == alg & decomposition == 'std_bb')
	mval.nccc = dt$PS.NCCCs[!is.na(dt$PS.NCCCs)] + dt$PD.NCCCs[!is.na(dt$PD.NCCCs)]
	mval.smt = dt$PS.wct[!is.na(dt$PS.wct)] + dt$PD.wct[!is.na(dt$PD.wct)]
	dt <- subset(rawdata, algorithm == alg & decomposition == 'mva-eager_bb')
	mvae.nccc = dt$PS.NCCCs[!is.na(dt$PS.NCCCs)] + dt$PD.NCCCs[!is.na(dt$PD.NCCCs)]
	mvae.smt  = dt$PS.smt[!is.na(dt$PS.smt)] + dt$PD.smt[!is.na(dt$PD.smt)]

	cor(psa.smt, psa.nccc,use="na.or.complete")
	cor(psv.smt, psv.nccc,use="na.or.complete")
	cor(mval.smt, mval.nccc,use="na.or.complete")
	cor(mvae.smt, mvae.nccc,use="na.or.complete")

	# D = data.frame(psa.nccc,psa.smt), psv.nccc, psv.smt, mval.nccc, mval.smt, mvae.nccc, mvae.smt)
	# cor(dt$PS.NCCCs, dt$PS.smt, use="na.or.complete")
}





randomGraphs.plot.Legend <- function()
{
    pdf(file = paste(PATH.RESULTS.RANDOM_GRAPHS, "legend.pdf", sep="/"), width = 8, height = 2) 
    par(mar=c(1, 0.2, 0.5, 1.2))    
    plot(NA, type = 'l', ylim=c(0,1), xlim=c(0,1), axes=F)
    legend(0,0.5, 
        c( "Compilation", "Decomposition", "MVA-lazy", "MVA-eager"),
        col = c(col.psv, col.psa, col.std, col.tab),
        horiz = TRUE, seg.len=1, lwd=c(10,10,10,10))
    dev.off()
}















data.extendedStatistics <- function( data, coverage_limit=20 )
{
    PARAMS  <- unique(rawdata$param)
    code.oo = -1
    
    sdata = data[,c(1:4,6:7,11:14)]
    #sum simulated time:
    pd_smt = sdata$PD.smt
    ps_smt = sdata$PS.smt
    pd_smt[ is.na(pd_smt) ] = 0
    ps_smt[ is.na(ps_smt) ] = 0
    sdata = cbind(sdata, "smt"=round((pd_smt+ps_smt)*1000))
    # compute quality error
    sdata$ratio = (1-sdata$ratio) * 100

    #   sdata = data.skim( data, coverage_limit, code.oo)
    
    MEAN <- aggregate(
        cbind(cost, ratio, smt) ~ decomposition + algorithm + param, sdata, mean
        )
    
    MEDIAN <- aggregate(
        cbind(cost, ratio, smt) ~ decomposition + algorithm + param, sdata, median
        )

    SD <- aggregate(
        cbind(cost, ratio, smt) ~ decomposition + algorithm + param, sdata, sd
        )

    SD[ SD == code.oo ] = NA
    MEAN[ MEAN == code.oo ] = NA
    MEDIAN[ MEDIAN == code.oo ] = NA

    return(list(mean=MEAN, median=MEDIAN, sd=SD))
}


gpgpu.table <- function(alg, test=c('variable', 'domain'), coverage_limit=20, rm.OO=F, rm.zeros=T)
{
    file <- paste(PATH.DROPBOX.GPGPU, gpgpu.path.getFileName(test), sep='/')
    rawdata <- data.cleanNA.soft(file, T, rm.zeros)
    PARAMS  <- unique(rawdata$param)
    data    <- data.extendedStatistics( rawdata, coverage_limit )
}


randomGraphs.ttest <- function(alg)
{
    rm.OO=F
    rm.zeros=T
    file <- paste(PATH.DROPBOX.RANDOM_GRAPHS, randomGraph.path.getFileName(test), sep='/')
    rawdata <- data.cleanNA.deep(file, rm.OO, rm.zeros)
    
    afb.psa <- subset(rawdata, algorithm == "afb" & decomposition == "psa")
    afb.psv <- subset(rawdata, algorithm == "afb" & decomposition == "psv")
    afb.std <- subset(rawdata, algorithm == "afb" & decomposition == "std_bb")

    dpop.psa <- subset(rawdata, algorithm == "dpop" & decomposition == "psa")
    dpop.psv <- subset(rawdata, algorithm == "dpop" & decomposition == "psv")
    dpop.std <- subset(rawdata, algorithm == "dpop" & decomposition == "std_bb")

    dgibbs.psa <- subset(rawdata, algorithm == "dgibbs" & decomposition == "psa")
    dgibbs.psv <- subset(rawdata, algorithm == "dgibbs" & decomposition == "psv")
    dgibbs.std <- subset(rawdata, algorithm == "dgibbs" & decomposition == "std_bb")
    
    print(paste("Simulated Time: AFB psa slower than std_bb   p-value:",
    t.test(afb.psa$PS.smt, afb.std$PS.smt, alternative="greater")$p.value))
    
    print(paste("Simulated Time: AFB psv slower than std_bb   p-value:",        
    t.test(afb.psv$PS.smt, afb.std$PS.smt, alternative="greater")$p.value))
    
    print(paste("Simulated Time: DPOP psa slower than std_bb   p-value:",
    t.test(dpop.psa$PS.smt[1:300], dpop.std$PS.smt[1:300], alternative="greater")$p.value))
    
    print(paste("Simulated Time: DPOP psv slower than std_bb   p-value:",        
    t.test(dpop.psv$PS.smt[1:141], dpop.std$PS.smt[1:141], alternative="greater")$p.value))

    print(paste("Simulated Time: DGIBBS psa slower than std_bb   p-value:",
    t.test(dgibbs.psa$PS.smt, dgibbs.std$PS.smt, alternative="greater")$p.value))
    
    print(paste("Simulated Time: DGIBBS psv slower than std_bb   p-value:",        
    t.test(dgibbs.psv$PS.smt, dgibbs.std$PS.smt, alternative="greater")$p.value))


    
}