#include "Utilities/statistics.hh"
#include "Problem/dcop-model.hh"
#include "Problem/dcop-instance.hh"
#include "Problem/dcop-instance-factory.hh"
#include "Problem/IO/input-settings.hh"
#include "Problem/IO/input-problem.hh"

#include <iostream>
#include <string>

//#define VERBOSE

int main(int argc, char* argv[])
{
  InputProblem problem(argc, argv);
  InputSettings settings(argc, argv);

#ifdef VERBOSE
  std::cout << problem.dump() << std::endl;
  std::cout << settings.dump() << std::endl;
#endif
  
  Statistics::registerTimer("wallclock");
  Statistics::setTimer("wallclock");

  // This time includes also all intializations.
  DCOPmodel model(problem);

#ifdef VERBOSE
  std::cout << "Problem Decomposition: " << settings.preprocess() << "\n";
#endif
  g_dcop = DCOPinstanceFactory::create(model, settings);
  
  std::cout << settings.dump() << "\n";

#ifdef VERBOSE
  std::cout << "Solving\n";
#endif
  g_dcop->solve();

  Statistics::stopwatch("wallclock");
  // model.saveSolution(dcop_instance);
  
  std::cout << Statistics::dumpCSV() << std::endl;
  //std::cout << Statistics::dump() << std::endl;
  
  return 0;
}
