#include "Instances/Random/random-instance.hh"
#include "Graph/random-graph.hh"
#include "Graph/graph-utils.hh"
#include "Utilities/utils.hh"

using namespace InstanceGenerator;
using namespace std;


RandomInstance::RandomInstance
(int nb_agents, int nb_local_variables, int domain_size, int max_constr_arity,
 int max_nb_neighbors, int max_nb_boundary_variables, double p1_local_variables, 
 double p1_agents, double p2)
{
  p_max_constraint_arity = max_constr_arity;

  RandomGraph graph(nb_agents, p1_agents, max_nb_neighbors);

  addAgents( graph.nodes() );

  int nb_nodes = graph.nbNodes();
  for(int n = 0; n < nb_nodes; ++n)
  {
    RandomGraph subgraph(nb_local_variables, p1_local_variables);

    int last_node = graph.nbNodes();
    graph.join(subgraph, n, max_nb_boundary_variables);
    
    // Map new added Variables to agent
    p_map_vars_to_agents[ n ] = n;        // Map old variable to agent
    for (int i = last_node; i< graph.nbNodes(); ++i)
      p_map_vars_to_agents[ i ] = n;
  }

  addVariables(graph.nodes(), 0, domain_size-1);

  for (int k = max_constr_arity; k >= 3; k--)
  {
    vector< vector<int> > cliques = GraphUtils::cliques(graph, k);
    if(!cliques.empty())
      addRelation(k, p2, 0, domain_size-1);  

    for (vector<int> nodes : cliques)
    {
      // Save Constraint of arity k
      addConstraint(nodes, k);

      // Remove edges from graph (all pairs in nodes)
      do {
        int u = nodes[ 0 ], v = nodes[ 1 ];
        graph.eraseEdge( u, v );
      } while (Utils::next_combination
	       (nodes.begin(), nodes.begin() + 2, nodes.end()) );
    }
  }
  
  // Creates constraints for all the binary constraints left
  if( graph.nbEdges() > 0) {
    addRelation(2, p2, 0, domain_size-1);  

    std::vector<int> scope(2);
    for (int i=0; i<graph.nbNodes(); ++i)
      for (int j=0; j<i; ++j)
	  
    if (graph.edge(i, j)) {
	    scope[ 0 ] = i; scope[ 1 ] = j;
      addConstraint(scope, 2);
    }        
  }

}


RandomInstance::~RandomInstance()
{ }


void RandomInstance::addAgents(std::vector<int> nodes)
{
  for (int agent_id : nodes)
    Instance::save( Agent::ptr(new Agent("a_"+std::to_string(agent_id)) ) );    
}


void RandomInstance::addVariables(std::vector<int> nodes, int d_min, int d_max)
{
  Instance::save( Domain::ptr(new Domain("d", d_min, d_max) ));
  
  for (int var_id : nodes)
  {
    int agent_id = p_map_vars_to_agents[ var_id ];
    std::string agent_name = "a_"+std::to_string(agent_id);
    std::string var_name = "v_"+std::to_string(var_id);
    Instance::save( Variable::ptr(new Variable(var_name, "d", agent_name)) );
  }
}
  
  
void RandomInstance::addRelation(int arity, double p2, int d_min, int d_max)
{
  uniform_int_distribution<cost_t> U_cost(0, 10);
  uniform_int_distribution<int> U_values(d_min, d_max);
  
  unsigned seed =
    chrono::system_clock::now().time_since_epoch().count();
  std::default_random_engine rnd(seed);
  
  int nb_values = (p2 * std::pow((d_max - d_min + 1), arity));
  
  Relation::ptr rel( new Relation("r_"+std::to_string(arity), arity));
  std::set<std::vector<int> > tuples;
  std::vector<int> tuple(arity);
  
  while (tuples.size() < nb_values)
  {
    for (int i = 0; i < arity; ++i) 
      tuple[ i ] = U_values(rnd);
    tuples.insert( tuple );
  }

  for(std::vector<int> tuple : tuples) {
    rel->addTuple( std::make_pair(tuple, U_cost(rnd)) );    
  }
  
  Instance::save( rel );
}


void RandomInstance::addConstraint(std::vector<int> variables_id, int arity)
{
  std::vector<std::string> scope;
  for (int var_id : variables_id)
    scope.push_back("v_"+std::to_string(var_id));
  std::string rel = "r_"+std::to_string(arity);

  int c_id = Instance::p_constraints.size();
  Instance::save( Constraint::ptr(
    new Constraint("c_"+std::to_string(c_id), scope, rel)) );
}


