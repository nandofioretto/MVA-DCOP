#include <string>
#include <iostream>
#include <vector>

#include "Instances/instance-factory.hh"
#include "Instances/Random/random-instance.hh"
#include "Instances/SmartGrids/smartgrid-instance.hh"
#include "Instances/SmartGridsScheduling/smartgrid-scheduling-instance.hh"
#include "Instances/BusScheduling/bus-scheduling-instance.hh"
#include "IO/input.hh"
#include "Utilities/utils.hh"

using namespace InstanceGenerator;


Instance* InstanceFactory::create(int argc, char* argv[])
{
  Input::checkParams(argc, argv);

  for(int i = 0; i < argc; ++i )
  {
    if(!strcmp("-random", argv[ i ]))
    {
      int nb_agents = Utils::stringToInt(argv[ ++i ]);
      int nb_local_vars = Utils::stringToInt(argv[ ++i ]);
      int dom_size = Utils::stringToInt(argv[ ++i ]);
      int max_constr_arity = Utils::stringToInt(argv[ ++i ]);
      int max_nb_neigbors = Utils::stringToInt(argv[ ++i ]);
      int max_nb_boundary_vars = Utils::stringToInt(argv[ ++i ]);
      double p1_local_vars = Utils::stringToDouble(argv[ ++i ]);
      double p1_agents = Utils::stringToDouble(argv[ ++i ]);
      double p2 = Utils::stringToDouble(argv[ ++i ]);
      
      return new RandomInstance(nb_agents, nb_local_vars, dom_size, max_constr_arity,
				max_nb_neigbors, max_nb_boundary_vars, p1_local_vars, 
				p1_agents, p2);
    }        

    if(!strcmp("-smartgrid", argv[ i ]))
    {
      int nb_smart_houses = Utils::stringToInt(argv[ ++i ]);
      int nb_local_generators = Utils::stringToInt(argv[ ++i ]);
      int domain_generator = Utils::stringToInt(argv[ ++i ]);
      int max_nb_neighbors = Utils::stringToInt(argv[ ++i ]);
      int domain_transmission_lines = Utils::stringToInt(argv[ ++i ]);
      
      return new SmartGridInstance(nb_smart_houses, nb_local_generators, 
				   domain_generator, max_nb_neighbors, 
				   domain_transmission_lines);
    }

    if(!strcmp("-bus-scheduling", argv[ i ]))
    {
      int nb_divisions = Utils::stringToInt(argv[ ++i ]);
      int nb_time_slots = Utils::stringToInt(argv[ ++i ]);
      int max_nb_bus_time = Utils::stringToInt(argv[ ++i ]);
      int max_nb_neighbors = Utils::stringToInt(argv[ ++i ]);
      int nb_bus_to_exchange = Utils::stringToInt(argv[ ++i ]);
      
      return new BusSchedulingInstance(nb_divisions, nb_time_slots, 
				       max_nb_bus_time, max_nb_neighbors, nb_bus_to_exchange);
    }

    if(!strcmp("-smartgrid-scheduling", argv[ i ]))
    {
      int nb_smart_houses = Utils::stringToInt(argv[ ++i ]);
      int nb_time_slots = Utils::stringToInt(argv[ ++i ]);
      int max_power_gen = Utils::stringToInt(argv[ ++i ]);
      int battery_capacity = Utils::stringToInt(argv[ ++i ]);
      int max_nb_neighbors = Utils::stringToInt(argv[ ++i ]);
      int tl_limit = Utils::stringToInt(argv[ ++i ]);
      
      return new SmartGridSchedulingInstance(nb_smart_houses, nb_time_slots, 
					     max_power_gen, battery_capacity, max_nb_neighbors, tl_limit);
    }

  }
  return nullptr;

}
