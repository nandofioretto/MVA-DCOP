#include "Problem/dcop-pseudovariable.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Agents/agent-factory.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/codec.hh"
#include "SearchEngines/DepthFirstSearch/depth-first-search.hh"
#include "Utilities/statistics.hh"
#include "Problem/IO/input-settings.hh"

using namespace std;

//#define STATISTICS


DCOPpseudoVariable::DCOPpseudoVariable(DCOPmodel& model, 
  InputSettings& settings)
{
  // Create New Agents
  AgentFactory::resetCt();
  for (Agent* old_a : model.agents())
  {
    Agent* new_a = AgentFactory::create( old_a->name() );
    
#ifdef STATISTICS
    old_a->statistics().setStartTimer();
    Statistics::registerCounter("NCCCs@decomposition", new_a->id());
    Statistics::registerTimer("simulated@decomposition", old_a->id());
#endif
            
    InputSettings::solving_t private_solver = 
      (settings.singlePrivateSolver()) ? settings.privateSolver("*") 
      : settings.privateSolver(old_a->name());
    
    InputSettings::solving_t boundary_solver = settings.boundarySolver();

    new_a->setPrivateSolver(private_solver);
    new_a->setBoundarySolver(boundary_solver);

    p_agents[ new_a->id() ] = new_a;

    p_map_agents[ new_a->id() ] = old_a->id();    // curr model -> std model 
    p_invmap_agents[ old_a->id() ] = new_a->id(); // std. model -> curr model
    p_map_dcop_std_agents_id [ new_a->id() ] = old_a->id(); // NOT USED
    
#ifdef STATISTICS
    old_a->statistics().setSimulatedTime(old_a->statistics().stopwatch()); 
#endif
  }
  p_nb_agents = model.nbAgents();
  
  // Creates the new pseudo-variables, each of which aggregates the local 
  // variables of an agent. The domain is the cartesian product of all the 
  // domains of the local variables of interest.
  std::vector<Agent*> new_agents;
  for (auto& kv : p_agents) new_agents.push_back(kv.second);

  VariableFactory::resetCt();
  ConstraintFactory::resetCt();
  
  for (Agent* old_a : model.agents())
  {
#ifdef STATISTICS
    old_a->statistics().setStartTimer();
#endif

    // new domain bounds = product of all var domains.
    size_t new_dom_size = 1;
    string new_var_name;

    for (IntVariable* old_v : old_a->localVariables())
    {
      new_dom_size *= old_v->domain().size();
      new_var_name += old_v->name() + "_";
    }
#ifdef STATISTICS
    //old_a->statistics().incrUsedMemory(new_var->sizeBytes());
    // Upperbound to take account of the unary constraint being created as follow
    old_a->statistics().incrUsedMemory(2*new_dom_size*sizeof(int));
    old_a->checkOutOfLimits();
#endif

    Agent* new_a = p_agents[ p_invmap_agents[ old_a->id() ] ];

    IntVariable* new_var = VariableFactory::create(new_var_name, new_a, 0, new_dom_size-1);
    p_variables[ new_var->id() ] = new_var;
            
    shared_ptr<Codec> codec(new Codec(old_a->localVariables()));
    p_map_codec[ new_var->id() ] = codec;

    // Set up variables mapping std model <-> pseudo variables
    p_map_variables[ new_var->id() ] = old_a->localVariableIDs();
    
    for (IntVariable* v : old_a->localVariables()) {
      p_invmap_variables[ v->id() ] = new_var->id();
      p_map_dcop_var_names[ v->id() ] = v->name();
    } 
  
    // Merges all intra-agent-constraints into a unary constraint.
    DepthFirstSearch search(*old_a);
    search.initialize(old_a->localVariables(), old_a->intraAgentConstraints());
    vector<IntVariable*> c_scope{new_var};

    // Note: Updates the NCCCs in the old agent -- copied later at the end of this function.
    Constraint* c = ConstraintFactory::create("c_"+old_a->name(), c_scope, new_agents, search, *codec);
    
    p_constraints[ c->id() ] = c;
    
    // Increment the NCCC in the decomposition phase associated to the new Agent ID
#ifdef STATISTICS
    Statistics::increaseCounter("NCCCs@decomposition", p_invmap_agents[ old_a->id() ], old_a->statistics().NCCC() );
    // CHECK: In the function above when do you check the memory limits requi
    // rements: We could do this operation inside the ConstraintFactory::create
    // to be more accurate.
    old_a->statistics().setSimulatedTime(old_a->statistics().stopwatch()); 
    //old_a->statistics().incrUsedMemory(c->sizeBytes());  // ALREADY DONE before
#endif
  }
  
  p_nb_variables = model.nbAgents();
  p_nb_constraints = model.nbAgents();
  
  // Take all inter-agent constraints
  vector<oid_t> inter_agents_cons_id;
  for(Constraint* c :model.constraints()) 
    inter_agents_cons_id.push_back( c->id());

  for (Agent* old_a : model.agents())
    Utils::exclude_emplace(old_a->intraAgentConstraintIDs(), inter_agents_cons_id);
      
  vector<Constraint*> inter_agents_cons;
  for(Constraint* c :model.constraints())
    if(Utils::find(c->id(), inter_agents_cons_id)) 
      inter_agents_cons.push_back(c);

  // A LITTLE TRICKY and INEFFICIENT: SEARCH ALL VALUES (LINEAR SCAN).
  // For each external constraint:
  // (have arity = #owers in the constraint scope)
  // - for each allowed tuple:
  //    - for each agent, need to retrieve the variables in the constraints -- 
  //      ordered generate all allowed elements in the new variables.
  //    - merge all these vector in a cartesian product having fixed cost -- a
  //      new DFS.
  for (Constraint* old_c : inter_agents_cons)
  {
    // Activate timer of all agents owning the variables of the scope of old_c
#ifdef STATISTICS
    for (IntVariable* v : old_c->scope()) {
      Agent* old_a = model.agent( v->ownerId() );
      old_a->statistics().setStartTimer();
    }
#endif
    
   Constraint* new_c = 
     ConstraintFactory::create(old_c, p_invmap_agents, p_agents, p_variables, p_map_codec, new_agents, model);

    ++p_nb_constraints;
    p_constraints[ new_c->id() ] = new_c;
    
#ifdef STATISTICS
    for (IntVariable* v : old_c->scope()) 
    {
      Agent* old_a = model.agent( v->ownerId() );
      Statistics::increaseCounter("NCCCs@decomposition", p_invmap_agents[ old_a->id() ], old_a->statistics().NCCC() );
      old_a->statistics().setSimulatedTime(old_a->statistics().stopwatch());
      // old_a->statistics().incrUsedMemory(new_c->sizeBytes()); // ALREADY DONE IN CFACTORY
    }    

#ifdef VERBOSE_TIMEOUT
    for (IntVariable* v : old_c->scope()) { 
      Agent* old_a = model.agent( v->ownerId() );
      // This need to be sobstituited by an OBSERVER PATTERN
      old_a->checkOutOfLimits();
    }
#endif    
#endif
    
  }


  for (auto& kv : p_agents) 
  {
    Agent& new_agent = *(kv.second);
    new_agent.orderContextVariables();

    Agent& old_agent = *(model.agent(p_map_agents[new_agent.id()]));
#ifdef STATISTICS
    // Increases the NCCC of a quantity equal to those cheked in the old agents.
    new_agent.statistics().incrNCCCs(old_agent.statistics().NCCC());
    // Set the used memory of the old agent
    new_agent.statistics().incrUsedMemory(old_agent.statistics().usedMemory());
    // Set the simulated time used for each agent during the decomposition 
    // process.
    Statistics::registerTimer("simulated@decomposition", new_agent.id());
    size_t sim_time = (old_agent.statistics().simulatedTime() / 1000.00); 
    Statistics::copyTimer("simulated@decomposition", sim_time, new_agent.id());
#endif
  }
 
  p_optimization = model.optimization(); 

}


std::vector<std::pair<std::string,int> > DCOPpseudoVariable::decodeSolution()
{
  std::vector<std::pair<std::string, int> > res;
  for(auto& kv : p_solution)
  {
    oid_t pv_model_vid = kv.first;
    int value = kv.second;
    
    std::vector<int> dcop_values = 
      p_map_codec[ pv_model_vid ]->decode( value );

    std::vector<oid_t> std_vars = p_map_variables[ pv_model_vid ];
  
    for (int i=0; i<dcop_values.size(); ++i)
    {
      std::string vname = p_map_dcop_var_names[ std_vars[ i ] ];
      res.push_back( std::make_pair(vname, dcop_values[ i ] ));
    }
  }
  return res;
}
