#ifndef ULYSSES_PROBLEM__DCOP_H_
#define ULYSSES_PROBLEM__DCOP_H_

#include <string>

// The DCOP abstract class
class DCOP
{
public:
  
  DCOP() { }
  
  //virtual ~DCOP() = 0;
  
  // It imports the DCOP structures, parsing the file given as a parameter.
  virtual void import(std::string file) = 0;
  
};

#endif // ULYSSES_PROBLEM__DCOP_H_