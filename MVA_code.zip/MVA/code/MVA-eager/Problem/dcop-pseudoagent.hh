#ifndef ULYSSES_PROBLEM__DCOP_PSEUDO_AGENT_H_
#define ULYSSES_PROBLEM__DCOP_PSEUDO_AGENT_H_

#include <map>

#include "Problem/dcop-instance.hh"
#include "Problem/dcop-model.hh"

class InputSettings;

// The DCOP Pseudo Agent class:
// Given a DCOP instance, it produces a new, equivalent, DCOP where each
// agent owe exatly one variable.
class DCOPpseudoAgent : public DCOPinstance
{
public:
  
  DCOPpseudoAgent(DCOPmodel& model, InputSettings& settings);
  
  ~DCOPpseudoAgent();
  
  // It returns the DCOP solution
  virtual std::vector<std::pair<std::string,int> > decodeSolution()
  {
    std::vector<std::pair<std::string, int> > res;
    for(auto& kv : p_solution)
    {
      oid_t varid = p_map_variables[ kv.first ];
      std::string vname = p_map_dcop_var_names[ varid ];
      res.push_back( std::make_pair( vname, kv.second ));
    }
    return res;
  }


private:
  // For each agent ID of the DCOP processed with pseudo agents, it 
  // returns the corresponding, ordered list of agent.
  std::map<oid_t, std::vector<oid_t> > p_map_agents;

  // For each variable ID of the DCOP processed with pseudo agents, it 
  // returns the corresponding variable.
  std::map<oid_t, oid_t> p_map_variables;
  
  // map std variable id -> std variable name
  std::map<oid_t, std::string> p_map_dcop_var_names;
};

#endif // ULYSSES_PROBLEM__DCOP_PSEUDO_AGENT_H_
