#ifndef ULYSSES__PROBLEM__PSEUDOVARIABLE_CODEC_H_
#define ULYSSES__PROBLEM__PSEUDOVARIABLE_CODEC_H_

#include <vector>

#include "Kernel/globals.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Utilities/utils.hh"
#include "Problem/dcop-instance.hh"

class PseudoVariableCodec : public Codec
{
public:
  // It constructs the codec for the set of variables given as a parameter.
  // It itnitializes the auxiliary structures for fast value retrival.
  PseudoVariableCodec() { }

  void addDomain(IntDomain& dom)
  {
    // TODO
  }


  std::vector decodeValuesSubjectedTo( int idx, int val )
  {
    std::vector<int> res;
    for (int i=0; i<size_; ++i)
    {
      std::vector<int>& dec = decode(i);
      if (dec[ idx ] == val)
	res.push_back( i );
    }
    reutrn res;
  }


  size_t size() const
  {
    return size_;
  }
  
  // It encodes the sequence of value elements given as a parmater to a large 
  // number.
  // @note: the values given as a paramter correspond to the values of the 
  // variables domains (and not their translated positions)
  // Complexity: O(k) - wiht k = number of variables
  size_t encode(std::vector<int> values)
  {
    size_t pos = 0;
    for (int i=0; i<variables_.size(); ++i)
      pos += ( (values[ i ] - offsets_[ i ]) * psum_domsize_[ i ]);
    return pos;
  }


  // It decodes the code given as a parameter into a sequence of values
  // for the variables of the object.
  // @note: it returns the sequence of values of the variables domains 
  // (as opposed at their translated positions which is stored here)
  // Complexity: O(k) - wiht k = number of variables
  std::vector<int>& decode(size_t code)
  {
    for (int i=0; i<variables_.size(); ++i) {
      auxvalues_[ i ] = (int)( code / psum_domsize_[ i ] ) % domsize_[ i ];
      auxvalues_[ i ] += offsets_[ i ];
    }
    return auxvalues_;
  }

  // It returns the list of variables of the object.
  std::vector<oid_t>& variables()
  {
    return variables_;
  }

private:
  // The variables whose values are encoded/decoded.
  std::vector<oid_t> variables_;

  // The domain of the variables in the encoder.
  std::vector<size_t> domsize_;

  // The offsets necessary to translate each domain element to 0.
  // E.g., if a variables has domain [-2, 8] the associated offset 
  // will hold the value '2'.  
  std::vector<int> offsets_;
  
  // The vector of partial sums defined as:
  // psums_domsize_[ i ] = \sum_j={i+1}^n D[ j ]
  // where:
  //  n = number of variables in variables
  //  D[ j ] = the size of the j-th variable's domain
  std::vector<size_t> psum_domsize_;
  
  // The size of the cartesian product of the variables' domain.  
  size_t size_;

  // Auxiliary value combinations used to temporary save the values
  // while decoding. It avoids to allocate a new vector at each decoding.
  std::vector<int> auxvalues_;
};


#endif
