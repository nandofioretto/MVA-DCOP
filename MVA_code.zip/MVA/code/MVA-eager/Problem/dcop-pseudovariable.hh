#ifndef ULYSSES_PROBLEM__DCOP_PSEUDO_VARIABLE_H_
#define ULYSSES_PROBLEM__DCOP_PSEUDO_VARIABLE_H_

#include <unordered_map>
#include <vector>
#include <memory>

#include "Problem/dcop-instance.hh"
#include "Problem/dcop-model.hh"

class Codec;
class InputSettings;

// The DCOP Pseudo Variable problem encoding.
// Given a DCOP instance, it produces a new, equivalent, DCOP which aggregates  
// all variables within each agent. The resulting variable has a domain which is
// equivalent to the cartesian product of the domains of the original 
// variables. The intra-agent constraints are collapsed into a single unary
// constraint, which satisfies this encoding.
class DCOPpseudoVariable : public DCOPinstance
{
public:
  
  DCOPpseudoVariable(DCOPmodel& model, InputSettings& settings);
  
  ~DCOPpseudoVariable();
  
  // It returns the DCOP solution
  virtual std::vector<std::pair<std::string,int> > decodeSolution();

  
private:

  // It Maps an agent ID in the current DCOP instance into the corresponding
  // agent ID of the original model.
  std::unordered_map<oid_t, oid_t> p_map_agents;

  // It Maps an agent ID of the original model into the corresponding agent 
  // ID of the current DCOP instance.
  std::unordered_map<oid_t, oid_t> p_invmap_agents;

  // It Maps a variable ID in the current DCOP instance into the corresponding
  // list of variables ID of the original model.
  std::unordered_map<oid_t, std::vector<oid_t> > p_map_variables;

  // It Maps a variable ID of the original model into the corresponding variable 
  // ID of the current DCOP instance.
  std::unordered_map<oid_t, oid_t> p_invmap_variables;

  // map std variable id -> std variable name
  std::map<oid_t, std::string> p_map_dcop_var_names;

  // For each variable in the new problem, it associate a codec which is used to 
  // convert the values from the doamin of the varialbe in the new model to the
  // domains of the associated variables in the std model. 
  std::unordered_map<oid_t, std::shared_ptr<Codec> > p_map_codec;
  
};

#endif // ULYSSES_PROBLEM__DCOP_PSEUDO_VARIABLE_H_
