#include <unordered_map>
#include <utility>      // std::pair, std::make_pair
#include <algorithm>
#include <set>
#include <vector>
#include <string>

#include "Problem/dcop-standard-gpu.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Problem/IO/input-settings.hh"
#include "GPU/gpu_data_allocator.hh"
#include "Utilities/utils.hh"

using namespace std;

#define VERBOSE

DCOPstandardGPU::DCOPstandardGPU(DCOPmodel& model, InputSettings& settings)
{
  ASSERT(DCOPinfo::minimize(), "Only minimization problems allowed in the GPU version.");
  
  for (Agent* a : model.agents()) 
  {
    Statistics::registerTimer("simulated@decomposition", a->id());
    Statistics::setTimer("simulated@decomposition", a->id());
    
    p_agents[ a->id() ] = a;
    p_map_dcop_std_agents_id [ a->id() ] = a->id();
    
    // CHECK THE FOLLOWING:
    InputSettings::solving_t private_solver = 
      (settings.singlePrivateSolver()) ? settings.privateSolver("*") 
      : settings.privateSolver(a->name());
    
    InputSettings::solving_t boundary_solver = settings.boundarySolver();

    a->setPrivateSolver(private_solver);
    a->setBoundarySolver(boundary_solver);
    
    Statistics::stopwatch("simulated@decomposition", a->id());
  }
   
  p_nb_agents = model.nbAgents();

  // Map Variables
  for (IntVariable* v : model.variables()){
    p_variables[ v->id() ] = v;
    p_map_dcop_var_names[ v->id() ] = v->name();
  }
  p_nb_variables = model.nbVariables();
    
  // Map Constraints
  for (Constraint* c : model.constraints())
    p_constraints[ c->id() ] = c;
  p_nb_constraints = model.nbConstraints();
      
  for (auto& kv : p_agents) {
    kv.second->orderContextVariables();
  }
  
  p_optimization = model.optimization(); 

  int dom_size = 0;
  for (IntVariable* v : variables()){
    dom_size = max(dom_size, (int)(v->size()));
  }
    
    
  // GPU side starts here
  
  Statistics::stopwatch("wallclock");
  Statistics::stopwatch("wallclock@decomposition");
  
    GPU::initGlobalMemory(nbAgents(), nbVariables(), nbConstraints(), dom_size);
  
  for (IntVariable* v : variables())
    GPU::initVariable(v->id(), v->min(), v->max());
  
   for (Constraint* c : constraints())
  {    
    ExtSoftConstraint* esc = dynamic_cast<ExtSoftConstraint*>(c);
    int* values = new int [esc->arity()];
    std::vector<int> v_values;
    
    std::vector<int> domains_size;
    for( IntVariable* v : c->scope())
      domains_size.push_back( v->size() );
    
    cost_t cost;
    std::vector< std::pair<std::vector<int>, cost_t> > utils;
    esc->resetIterator();
    while( esc->next() ) {
      esc->getNext( values, cost );
      v_values.assign(values, values + esc->arity());      
      utils.push_back( std::make_pair(v_values, cost) );
    }
    
    GPU::initConstraint( esc->id(), esc->scopeIds(), domains_size, utils, esc->defaultCost());
    delete[] values;
  }
 
  // Why only one agent?
  for (Agent* a : agents()) {    
    std::vector<oid_t> v_boundary = a->boundaryVariableIDs();
    std::vector<oid_t> c_boundary = DCOPstandardGPU::involvingExclusively( v_boundary, a->id() );
    std::vector<oid_t> v_private = a->privateVariableIDs();
    std::vector<oid_t> c_private = Utils::exclude(c_boundary, a->intraAgentConstraintIDs());    
        
    GPU::initAgent(a->id(), v_boundary, c_boundary, v_private, c_private, p_nb_variables);    
    GPU::initUTILTable(a->id(), a->nbBoundaryVariables(), a->nbPrivateVariables(), dom_size);
  }
  Statistics::setTimer("wallclock");
  Statistics::setTimer("wallclock@decomposition"); 
}


DCOPstandardGPU::~DCOPstandardGPU()
{
  
}

std::vector<oid_t> DCOPstandardGPU::involvingAny(const std::vector<oid_t> vars)
{
  std::set<oid_t> constr;
  for (IntVariable* v : DCOPinstance::variables(vars))
    for (Constraint* c : v->constraints())
      constr.insert(c->id());
  return std::vector<oid_t>(constr.begin(), constr.end());
}


std::vector<oid_t> DCOPstandardGPU::involvingExclusively(const std::vector<oid_t> vars, oid_t aID)
{
  std::vector<oid_t> res;
  std::vector<IntVariable*> _vars = DCOPinstance::variables(vars);
  std::vector<oid_t> cons;
  bool insert;
  
  if (aID == -1) 
    cons = DCOPstandardGPU::involvingAny(vars);
  else
    cons = DCOPinstance::agent(aID).constraintIDs();

  for (oid_t cid : cons)
  {
    insert = true;
    Constraint& c = DCOPinstance::constraint(cid);
    for (oid_t vscope : c.scopeIds())
    {
      // scope var not in var set -- do not insert
      if (find(vars.begin(), vars.end(), vscope) == vars.end())
        { insert = false; break;}
    }
    if(insert) res.push_back(cid);
  }
  
  return res;
}
