#include <map>

#include "Problem/dcop-pseudoagent.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Agents/agent-factory.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Problem/IO/input-settings.hh"

using namespace std;

Agent* pFindAgent(vector<Agent*> agents, oid_t id)
{
  Agent* target = nullptr;
  for (Agent* a : agents)
    if (a->id() == id)
      {target = a; break;}
  
  ASSERT(target, "Error in Preprocessing pseudo agents: no agent associated to \
    id " << id << " could be found.");  

  return target;
}


DCOPpseudoAgent::DCOPpseudoAgent(DCOPmodel& model, InputSettings& settings)
{  
  AgentFactory::resetCt();
  VariableFactory::resetCt();
      
  // Create Agents and Variables from model.
  for (IntVariable* old_v : model.variables())
  {
    string old_vname  = old_v->name();
    // map back agent with this vowner id
    oid_t old_vowner_id = old_v->ownerId();
    Agent* old_vowner = pFindAgent(model.agents(), old_vowner_id);
    string aname = old_vowner->name();
        
    // Create new agent
    Agent* new_agent = AgentFactory::create( old_vname+"_pseudo_"+aname );
    new_agent->statistics().incrUsedMemory(old_v->sizeBytes());
    
    Statistics::registerTimer("simulated@decomposition", new_agent->id());
    Statistics::setTimer("simulated@decomposition", new_agent->id());
    
    InputSettings::solving_t private_solver = 
      (settings.singlePrivateSolver()) ? settings.privateSolver("*") 
      : settings.privateSolver(old_vowner->name());
     
    InputSettings::solving_t boundary_solver = settings.boundarySolver();

    new_agent->setPrivateSolver(private_solver);
    new_agent->setBoundarySolver(boundary_solver);
     
    p_agents[ new_agent->id() ] = new_agent;

    // map pseudo-agent ID with current std agents ID.
    // p_map_agents[ new_agent->id() ].push_back(old_vowner_id);
    p_map_dcop_std_agents_id [ new_agent->id() ] = old_vowner_id;

    // Create variable
    IntVariable* new_v = 
      VariableFactory::create( old_vname, new_agent, old_v->domain() );
    p_variables[ new_v->id() ] = new_v;

    // map original model variable ID with current instance variable ID.
    p_map_variables[ new_v->id() ] = old_v->id();
    p_map_dcop_var_names[ old_v->id() ] = old_v->name();
    
    Statistics::stopwatch("simulated@decomposition", new_agent->id());
  }
  
  p_nb_agents = model.nbVariables();
  p_nb_variables = model.nbVariables();  
  
  
  // Update the constraints, so to register the new scope in each constraint,
  // and to register the constraints in each new agent and variables.
  for (Constraint* c : model.constraints())
  {    
    Statistics::setTimer("simulated@decomposition");
    
    // For each variable in scope, find corresponding var and register new 
    // scope in constraint.
    vector<IntVariable*> vars(c->arity());
    for (int i=0; i<c->arity(); ++i)
    {
      for (auto& kv : p_map_variables)
        if (kv.second == c->variableIdAt(i))
          vars[ i ] = p_variables[ kv.first ];
    }
    c->updateScope(vars);

    // Registers this constraint in the agents owning the variables of the 
    // constraint scope.
    vector<Agent*> agents;
    for(auto& kv : p_agents) agents.push_back(kv.second);

    for (IntVariable* v : vars) {
      v->registerConstraint(*c);
      pFindAgent(agents, v->ownerId())->registerConstraint(c);
    }
    
    p_constraints[ c->id() ] = c;
    
    Statistics::stopwatch("simulated@decomposition");
  }
  p_nb_constraints = model.nbConstraints();

 
  for (auto& kv : p_agents) {
    kv.second->orderContextVariables();
  }
 
  p_optimization = model.optimization(); 
}


DCOPpseudoAgent::~DCOPpseudoAgent()
{
  
}
