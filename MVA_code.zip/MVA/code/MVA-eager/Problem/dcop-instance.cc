#include "Problem/dcop-instance.hh"
#include "Communication/scheduler.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Constraints/soft-consistency.hh"

DCOPinstance::DCOPinstance()
  : p_nb_agents(0), p_nb_variables(0), p_nb_constraints(0) 
  { }


void DCOPinstance::solve()
{
  for(auto& kv : p_agents)
    Scheduler::FIFOinsert(kv.second->id());
  Scheduler::run();
}


std::vector<std::pair<std::string,int> > DCOPinstance::solution()
{
  std::vector<std::pair<std::string, int> > res;
  for (auto& kv : p_solution)
    res.push_back(std::make_pair(p_variables[kv.first]->name(), kv.second));
  return res;
}


void DCOPinstance::computeSolutionCost()
{
  std::vector<oid_t> varsID;
  for(auto& kv : p_variables)
    varsID.push_back( kv.first );
  
  std::vector<oid_t> consID;
  for(auto& kv : p_constraints)
    consID.push_back( kv.first );
  
  std::vector<int> solution;
  for(oid_t vid : varsID)
    solution.push_back( p_solution[ vid ] );
  
  size_t ncccs = p_agents[0]->statistics().NCCC();

  SoftConsistency consistency(*p_agents[0]);
  consistency.initialize(varsID, consID);
  consistency.enforceConsistency( solution );
  setCost( consistency.cost() );
  
  p_agents[0]->statistics().setNCCC(ncccs);
}