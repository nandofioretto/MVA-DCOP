#ifndef ULYSSES_KERNEL__TYPES_H_
#define ULYSSES_KERNEL__TYPES_H_

typedef std::string msg_t;
// typedef unsigned oid_t;
// typedef int cost_t;
// typedef cost_t util_t;

#endif // ULYSSES_KERNEL__TYPES_H_