#include <map>

#include "Kernel/globals.hh"

constexpr int Constants::NaN;
constexpr oid_t Constants::nullid;
constexpr cost_t Constants::infinity;

cost_t Constants::worstvalue = 0;
cost_t Constants::bestvalue = 0;
DCOPinfo::optType DCOPinfo::optimization = DCOPinfo::kMinimize; // default

DCOPinstance* g_dcop = nullptr;

std::map< std::string, ConstraintCatalog::constrName > 
ConstraintCatalog::mapName_ = {
  {"XeqY", ConstraintCatalog::XeqY},
  {"int_EQ", ConstraintCatalog::XeqY}
};
