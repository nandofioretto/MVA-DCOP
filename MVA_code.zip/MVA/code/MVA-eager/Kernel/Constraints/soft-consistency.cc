#include <set>

#include "Kernel/globals.hh"
#include "Kernel/Constraints/soft-consistency.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Variables/variable-observer.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Problem/dcop-instance.hh"
#include "Utilities/utils.hh"
#include "Utilities/statistics.hh"
#include "Utilities/Statistics/local-statistics.hh"


using namespace std;

SoftConsistency::SoftConsistency(Agent& owner)
  : ConsistencyManager(owner), 
    curr_queue_size_(0), curr_cost_(0)
{ }

// This initializer it is used during the UTIL propagation pahse.
void SoftConsistency::initialize(vector<oid_t> variables,
				 vector<oid_t> constraints)
{  
  // All constraints which are not of type SOFT are discarded
  for (Constraint* c : g_dcop->constraints(constraints))
    if (c->type() == Constraint::kExtSoft) 
      constraint_queue_.push_back( dynamic_cast<ExtSoftConstraint*>(c) );
  
  // Initialize aux data structures for fast value retrival
  map_cscope_varidx2_.resize(constraint_queue_.size());
  for (int i = 0; i < constraint_queue_.size(); ++i)
  {
    ExtSoftConstraint* esc = constraint_queue_[ i ];
    int* key = new int[ esc->arity() ];
    curr_assignment_.push_back( key );

    map_cscope_varidx2_[ i ].resize( esc->arity() );
    for (int a = 0; a < esc->arity(); ++a) 
    {
      oid_t vid = esc->variableAt( a ).id();
      int idx = Utils::findIdx(variables, vid);
      ASSERT( idx >= 0, "Error in constructing aux map in SoftConsistency Manager");
      map_cscope_varidx2_[ i ][ a ] = idx;
    }

    curr_queue_map_.push_back( i ); 
    ++curr_queue_size_;
  }
}


void SoftConsistency::initialize(vector<Constraint*> constraints)
{
  // All constraints which are not of type SOFT are discarded
  for (Constraint* c : constraints)
    if (c->type() == Constraint::kExtSoft)
      constraint_queue_.push_back( dynamic_cast<ExtSoftConstraint*>(c) );
      
  // Retrieve the variables involved in the given constraints
  std::set<IntVariable*> _vset;
  for (ExtSoftConstraint* c : constraint_queue_)
    for (IntVariable* v : c->scope())
      _vset.insert( v );

  // popolate the array of variables
  for (IntVariable* v : _vset) variables_.push_back( v );

  // Initialize aux data structures for fast value retrival
  map_cscope_varidx_.resize(constraint_queue_.size());

  for (int i = 0; i < constraint_queue_.size(); ++i)
  {
    ExtSoftConstraint* esc = constraint_queue_[ i ];
    int* key = new int[ esc->arity() ];
    curr_assignment_.push_back( key );

    map_cscope_varidx_[ i ].resize( esc->arity() );
    for (int a = 0; a < esc->arity(); ++a) 
    {
      IntVariable& var = esc->variableAt( a );
      map_cscope_varidx_[ i ][ a ] =
	(std::find(variables_.begin(), variables_.end(), &var) );
      ASSERT( map_cscope_varidx_[ i ][ a ] != variables_.end(), 
	      "Error in constructing aux map in SoftConsistency Manager");
    }
    
    curr_queue_map_.push_back( i ); 
    ++curr_queue_size_;
  }
}


SoftConsistency::~SoftConsistency()
{
  for (int i=0; i<curr_assignment_.size(); ++i)
    delete[] curr_assignment_[ i ];
}

void SoftConsistency::flush() 
{ }


// @todo: check on backtrack
bool SoftConsistency::enforceConsistency()
{
  // owner().statistics().incrNCCCs();  
  curr_cost_ = 0;
  
  for (int i = 0; i < curr_queue_size_; ++i)
  {
    int c_idx = curr_queue_map_[ i ];
    ExtSoftConstraint* esc = constraint_queue_.at( c_idx );
    // Initializes the current value for the constraint esc

    for (int v=0; v<esc->arity(); ++v) {
      curr_assignment_[ c_idx ][ v ] = (*map_cscope_varidx_[ c_idx ][ v ])->value();
    }

    cost_t u = esc->getCost( curr_assignment_[ c_idx ] );
    owner().statistics().incrNCCCs();
    
    if (!Constants::isFinite( u )) {
      curr_cost_ = u;
      return false;
    }
    curr_cost_ += u;
  }
  return true;
}


// The values are listed in the same order of the variables given in the initializer
bool SoftConsistency::enforceConsistency(std::vector<int> values)
{
  // owner().statistics().incrNCCCs();  
  curr_cost_ = 0;
  for (int i=0; i<curr_queue_size_; ++i)
  {
    int c_idx = curr_queue_map_[ i ];
    ExtSoftConstraint* esc = constraint_queue_.at( c_idx );
    // Initializes the current value for the constraint esc
    for (int v=0; v<esc->arity(); ++v)
    {
      size_t idx = map_cscope_varidx2_[ c_idx ][ v ];
      curr_assignment_[ c_idx ][ v ] = values[ idx ];
    }
    
    cost_t u = esc->getCost( curr_assignment_[ c_idx ] );
    owner().statistics().incrNCCCs();
    
    if (!Constants::isFinite( u )){
      curr_cost_ = u;
      return false;
    }
    
    curr_cost_ += u;
  }
  return true;
}


std::string SoftConsistency::dump() const
{
  std::string result = "soft-consistency constr: (";
  for (ExtSoftConstraint* c : constraint_queue_)
    result +=  c->name() + ", ";
  result += ")";
  return result;
}
