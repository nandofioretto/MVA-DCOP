#include <string>
#include <sstream>
#include <rapidxml.hpp>

#include "Kernel/Agents/agent.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Constraints/int-hard-constraint.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint1.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint2.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint3.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint4.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint5.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint6.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint7.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint8.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint9.hh"
#include "Problem/dcop-model.hh"

#include "Kernel/codec.hh"
#include "SearchEngines/search-engine.hh"

#include "Utilities/utils.hh"

// All constraints of the catalog
#include "Kernel/Constraints/XeqY.hh"

using namespace rapidxml;
using namespace std;

// Initializes static members
int ConstraintFactory::p_constraints_ct = 0;


// Jul 5, ok
// It constructs and returns a new constraint.
Constraint* ConstraintFactory::create(xml_node<>* conXML, 
                                      xml_node<>* relsXML, 
                                      vector<Agent*> agents, 
                                      vector<IntVariable*> variables)
{
  string name = conXML->first_attribute("name")->value();
  string rel = conXML->first_attribute("reference")->value();
  
  // Retrieve the relation associated to this constraint:
  int size = atoi(relsXML->first_attribute("nbRelations")->value());
  ASSERT(size > 0, "No Relation associated to constraint " << name); 

  xml_node<>* relXML = relsXML->first_node("relation");
  while (rel.compare(relXML->first_attribute("name")->value()) != 0)
  {
    relXML = relXML->next_sibling();
    ASSERT(relXML, "No Relation associated to constraint " << name);
  }

  // Proces constraints according to their type.
  string semantics = relXML->first_attribute("semantics")->value();
  
  // Ext-Soft-Constraint
  if (semantics.compare("soft") == 0 or // back-compatibility with FRODO 2.11
      semantics.compare("hard") == 0 or // back-compatibility with FRODO 2.11
      semantics.compare("extensionalSoft") == 0 or
      semantics.compare("extensionalHard") == 0 )
  {
    ExtSoftConstraint* c = createExtSoftConstraint(conXML, relXML, variables);
    setProperties(c, name, agents);
    ++p_constraints_ct;
    return c;
  }
  else if (semantics.compare("intensionalHard") == 0)
  {
    IntHardConstraint* c = createIntHardConstraint(conXML, relXML, variables);
    setProperties(c, name, agents);
    ++p_constraints_ct;
    return c;
  }
  else if (semantics.compare("intensionalSoft") == 0)
  {
    ASSERT(false, "Int Soft Constraint processing Not implemented");
  }
  else
    ASSERT(false, "Error in the relation semantics: " << semantics); 

  return nullptr;
}


Constraint* ConstraintFactory::create(string c_name,
                                      vector<IntVariable*> c_scope,
                                      vector<Agent*> agents,
                                      SearchEngine& SE,
                                      Codec& codec)
{
  int arity = c_scope.size();
  ASSERT( arity == 1, "Error in creating constraint.");
  ExtSoftConstraint* c = 
    createExtSoftConstraint(arity, c_scope, 0, Constants::worstvalue);
  int* unary_value = new int[arity];
    
  while (!SE.isTerminated())
  {
    if (SE.nextSolution())
    {	
      Solution& sol = SE.getSolution();
      unary_value[ 0 ] = codec.encode(sol.values());
      c->setCost( unary_value, sol.cost());
    }
  }
  delete[] unary_value;
  
  setProperties(c, c_name, agents);
  ++p_constraints_ct;
  return c;
}


Constraint* ConstraintFactory::create(Constraint* old_c, 
  unordered_map<oid_t, oid_t> invmap_agents, 
  unordered_map<oid_t, Agent*> map_agents_id, 
  unordered_map<oid_t, IntVariable*> map_variables_id,
  unordered_map<oid_t, std::shared_ptr<Codec> >  map_codec,
  vector<Agent*> new_agents,
  DCOPmodel& model)
{
  vector<oid_t> new_scope_id;
  vector<IntVariable*> new_scope;
  vector<oid_t> old_scope_id = old_c->scopeIds();
  vector<IntVariable*> old_scope = old_c->scope();
  map<oid_t, std::vector<int> > new_scope_id_to_old_scope_idx;
  map<int, std::vector<int> > new_scope_to_old_scope_idx;
  map<int, int> old_scope_to_new_scope_idx;

  // Init auxiliary map new_scope_to_old_scope_idx.
  for (int i=0; i<old_scope.size(); ++i)
  {
    oid_t new_aid = invmap_agents[ old_scope[ i ]->ownerId() ];
    oid_t new_vid = map_agents_id[ new_aid ]->variableAt( 0 ).id();
    
    if (!Utils::find(new_vid, new_scope_id))
      new_scope_id.push_back( new_vid);
    
    new_scope_id_to_old_scope_idx[ new_vid ].push_back( i );
  }
  std::sort(new_scope_id.begin(), new_scope_id.end());      

  // Init auxiliary map old_scope_to_new_scope_idx.
  for (int i=0; i<new_scope_id.size(); ++i) 
  {
    int new_vid = new_scope_id[ i ];
    new_scope_to_old_scope_idx[ i ] = new_scope_id_to_old_scope_idx[ new_vid ];
    for( int old_idx : new_scope_to_old_scope_idx[ i ] ) {
      old_scope_to_new_scope_idx[ old_idx ] = i;       
    }
    new_scope.push_back( map_variables_id[ new_vid ] );
  }

  int new_arity = new_scope.size();
  int old_arity = old_c->arity();

  ExtSoftConstraint* old_esc = dynamic_cast<ExtSoftConstraint*>(old_c);

  cost_t def_cost = old_esc->defaultCost();

  ExtSoftConstraint* new_c = 
    createExtSoftConstraint(new_arity, new_scope, 0, def_cost);

  setProperties(new_c, old_c->name(), new_agents);
  

  int* old_values = new int[ old_arity ]; 
  int* new_values = new int[ new_arity ];
  
  cost_t cost;
  old_esc->resetIterator();
  while (old_esc->next())
  {
    old_esc->getNext(old_values, cost);
    
    // Increments the NCCCs in the new agent for each visit in the constraint
    for (IntVariable* v : old_esc->scope())
      map_agents_id[ invmap_agents[ v->ownerId() ] ]->statistics().incrNCCCs();
    
    // Each column of new values correspond to a value of the old scope
    vector< std::vector<int> > tmp_new_values(old_arity);
    for (int i=0; i<old_arity; ++i)
    {
      oid_t new_id = new_scope_id [ old_scope_to_new_scope_idx[ i ] ];
      // get all the values where the i-th variable of the original variable 
      // is fixed to be of value given.
      oid_t old_id = old_scope_id[ i ];
      tmp_new_values[ i ] = 
        map_codec[ new_id ]->encode_subject_to( old_id, old_values[ i ] );
    }
    
    // Intersect variables in the same agent 
    vector<vector<int> > tmp_new_values_pv(new_arity);
    for( int i=0; i<new_arity; ++i) 
    {
      int old_idx = new_scope_to_old_scope_idx[ i ][ 0 ];
      tmp_new_values_pv[ i ] = tmp_new_values[ old_idx ];
      for(int j=1; j<new_scope_to_old_scope_idx[ i ].size(); ++j) 
      {
        old_idx = new_scope_to_old_scope_idx[ i ][ j ];
        Utils::intersect_emplace(tmp_new_values_pv[ i ], tmp_new_values[ old_idx ] );
      }
    }

    // Cartesian Prodcut
    vector<vector<int> > cp;
    for (int i=0; i<new_arity; ++i)
      Utils::cartesian_product( cp, tmp_new_values_pv[ i ]);
    
#ifdef STATISTICS
    //old_a->statistics().incrUsedMemory(new_var->sizeBytes());
    // Upperbound to take account of the unary constraint being created as follow
    size_t size = 0;
    for(int i=0; i<cp.size(); ++i) 
      size += (cp[i].size() * sizeof(int));
    
    for (IntVariable* v : old_c->scope()) {
      Agent* old_a = model.agent( v->ownerId() );
      old_a->statistics().incrUsedMemory(size);
      old_a->checkOutOfLimits();
    }
#endif
    
    for(vector<int>& cp_row : cp)
    {
      ASSERT( cp_row.size() == new_arity, "ERROR.");
      std::copy(cp_row.begin(), cp_row.end(), new_values);

      // Increment the NCCCs for every request of constraint->cost()
      for (IntVariable* v : old_c->scope())
        map_agents_id[ invmap_agents[v->ownerId()] ]->statistics().incrNCCCs();
        
      new_c->setCost( new_values, cost );      
    }
    
  }//-end while
        
  ++p_constraints_ct;
    
  delete[] old_values;
  delete[] new_values;
  
  return new_c;
}


// Jul 5, ok
void ConstraintFactory::setProperties
  (Constraint* c, string name, vector<Agent*> agents)
{
  c->setId( p_constraints_ct );
  c->setName( name );

  // Registers this constraint in the agents owning the variables of the 
  // constraint scope.
  for (IntVariable* v : c->scope())
  {
    Agent* v_owner = nullptr;
    for (Agent* a : agents) if( a->id() == v->ownerId() ) { v_owner = a; }
      ASSERT(v_owner, "Error in finding variable owner\n");
      v_owner->registerConstraint( c );
  }
}


// Jul 5, ok
vector<IntVariable*> ConstraintFactory::getScope
  (xml_node<>* conXML, vector<IntVariable*> variables)
{
  int arity = atoi(conXML->first_attribute("arity")->value());
  
  // Read constraint scope
  string p_scope = conXML->first_attribute("scope")->value();
  vector<IntVariable*> scope(arity, nullptr);
  stringstream ss(p_scope); int c = 0; string var;
  while( c < arity ) 
  {
    ss >> var; 
    IntVariable* v_target = nullptr;
    for (IntVariable* v : variables) 
      if( v->name().compare(var) == 0 ) 
        v_target = v;
    ASSERT(v_target, "Error in retrieving scope of constraint\n");
     
    scope[ c++ ] = v_target;
  }
  return scope;
}



// Jul 5, ok
IntHardConstraint* ConstraintFactory::createIntHardConstraint
(xml_node<>* conXML, xml_node<>* relXML, std::vector<IntVariable*> variables)
{
  // Read Int Arguments
  vector<int> int_args; 
  if (conXML->first_attribute("nbIntArguments")) 
  {
    int nb_iargs = atoi(conXML->first_attribute("nbIntArguments")->value());
    if (nb_iargs > 0) 
    {
      int_args.resize( nb_iargs );
      
      string iargs = conXML->first_attribute("intArguments")->value();
      stringstream ss_ic( iargs );
      vector<int> int_args( nb_iargs ); 
      int i = 0;
      while (i < nb_iargs) { 
        ss_ic >> int_args[ i++ ]; 
      }
    }
  }
  
  // Read Real Arguments
  vector<double> real_args; 

  if (conXML->first_attribute("nbRealArguments"))
  {
    int nb_rargs = atoi(conXML->first_attribute("nbRealArguments")->value());
    if( nb_rargs > 0 ) 
    {
      real_args.resize( nb_rargs );
      
      string rargs = conXML->first_attribute("realArguments")->value();
      stringstream ss_rc( rargs );
      int i = 0;
      while (i < nb_rargs) { 
        ss_rc >> real_args[ i++ ]; 
      }
    }
  }
  
  vector<IntVariable*> scope = getScope( conXML, variables );

  // Deterine the type of constraint: 
  string constr_type = relXML->value();
  
  return createIntHardConstraint(constr_type, scope, int_args, real_args);   
}
 


// Jul 5, ok
IntHardConstraint* ConstraintFactory::createIntHardConstraint(string type, 
  vector<IntVariable*> scope, vector<int> iargs, vector<double> rargs)
{
  switch (ConstraintCatalog::get( type ))
  {
    case ConstraintCatalog::XeqY:
    return new XeqY(*scope[0], *scope[1]);
    default:
    return nullptr;
  }
}


// Jul 5, ok
ExtSoftConstraint* ConstraintFactory::createExtSoftConstraint
  ( int arity, vector<IntVariable*> scope, size_t nb_tuples, int def_cost )
{
  switch( arity )
  {
    case 1: return new ExtSoftConstraint1(scope, nb_tuples, def_cost);
    case 2: return new ExtSoftConstraint2(scope, nb_tuples, def_cost);
    case 3: return new ExtSoftConstraint3(scope, nb_tuples, def_cost);
    case 4: return new ExtSoftConstraint4(scope, nb_tuples, def_cost);
    case 5: return new ExtSoftConstraint5(scope, nb_tuples, def_cost);
    case 6: return new ExtSoftConstraint6(scope, nb_tuples, def_cost);
    case 7: return new ExtSoftConstraint7(scope, nb_tuples, def_cost);
    case 8: return new ExtSoftConstraint8(scope, nb_tuples, def_cost);
    case 9: return new ExtSoftConstraint9(scope, nb_tuples, def_cost);
    default:
    ASSERT(false, "Current version of Ulysses does not allow soft relation with arity > 9");
    break;
  }
  return nullptr;
}


// Jul 5, ok
ExtSoftConstraint* ConstraintFactory::createExtSoftConstraint
(xml_node<>* conXML, xml_node<>* relXML, std::vector<IntVariable*> variables)
{
  // Read Relation Properties
  string name = relXML->first_attribute("name")->value();
  int arity = atoi( relXML->first_attribute("arity")->value() );
  size_t nb_tuples = atoi( relXML->first_attribute("nbTuples")->value() );
  ASSERT( nb_tuples > 0, "Extensional Soft Constraint " << name << " is empty");

  vector<IntVariable*> scope = getScope( conXML, variables );
 
  // Get the default cost
  cost_t def_cost = Constants::worstvalue;

  if (relXML->first_attribute("defaultCost"))
  {
    string cost = relXML->first_attribute("defaultCost")->value();
    if (cost.compare("infinity") == 0 )
      def_cost = Constants::infinity;
    else if( cost.compare("-infinity") == 0 )
      def_cost = -Constants::infinity;
    else
      def_cost = atoi( cost.c_str() ); 
  }

  ExtSoftConstraint* con = 
    createExtSoftConstraint( arity, scope, nb_tuples, def_cost );

  string content = relXML->value(); 
  size_t lhs = 0, rhs = 0;

  // replace all the occurrences of 'infinity' with a 'INFTY'
  while (true)
  {
    rhs = content.find("infinity", lhs);
    if (rhs != string::npos) 
      content.replace( rhs, 8, to_string(Constants::infinity) );
    else break;
  };
 
  // replace all the occurrences of ':' with a '\b'
  // cost_t best_bound = Constants::worstvalue;
  // cost_t worst_bound = Constants::bestvalue;

  cost_t m_cost; bool multiple_cost;
  int* tuple = new int[ arity ];  
  int trim_s, trim_e;
  size_t count = 0;
  string str_tuples;
  lhs = 0;
  while (count < nb_tuples)
  {
    //multiple_cost = true;
    rhs = content.find(":", lhs);
    if (rhs < content.find("|", lhs)) 
    {
      if (rhs != string::npos) 
      {
        m_cost = atoi( content.substr(lhs,  rhs).c_str() );
	
        // Keep track of the best/worst bounds
        // best_bound = Utils::getBest(m_cost, best_bound);
        // worst_bound = Utils::getWorst(m_cost, worst_bound);
	
        lhs = rhs + 1;
      }
    }

    rhs = content.find("|", lhs);
    trim_s = lhs, trim_e = rhs;
    lhs = trim_e+1;
	
    if (trim_e == string::npos) trim_e = content.size();
    else while (content[ trim_e-1 ] == ' ') trim_e--;
    
    str_tuples = content.substr( trim_s, trim_e - trim_s );
    str_tuples = Utils::rtrim(str_tuples);
    stringstream ss( str_tuples );
	
    //int tmp;
    while( ss.good() )
    {
      for (int i = 0; i < arity; ++i) {
        // ss >> tmp;
        // tuple[ i ] = scope[ i ]->getDomain().get_pos( tmp );
        ss >> tuple[ i ];
      }
      con->setCost( tuple, m_cost );
      count++;
    }
  }

  // con->setBestCost(best_bound);
  // con->setWorstCost(worst_bound);
  
  delete[] tuple;  

  return con;
}

