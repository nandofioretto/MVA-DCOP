#include "Kernel/Constraints/int-hard-constraint.hh"
#include "Kernel/Constraints/constraint-state.hh"
#include "Kernel/Variables/int-variable.hh"

#include <vector>

IntHardConstraint::IntHardConstraint
(std::vector<IntVariable*> scope,
 std::vector<int> int_args, std::vector<double> real_args)
  : status_(kNone), int_arguments_(int_args), real_arguments_(real_args)
{ 
  type_ = kIntHard;
  scope_ = scope;
  for(IntVariable* v : scope) 
    scope_ids_.push_back(v->id());
}


// It changes the constraint status in the current store.
void IntHardConstraint::updateStatus(ConstraintStatus status)
{
  if(status_ != status)
   {
     notifySearchStack( new ConstraintState(*this) );
     status_ = status;
   }
}
