#include "Kernel/Constraints/XeqY.hh"
#include "Kernel/Domains/domain.hh"

#include <string>

XeqY::XeqY(IntVariable& x, IntVariable& y) 
  : x_(&x), y_(&y), IntHardConstraint( std::vector<IntVariable*>{ &x, &y} )
{
  // Register the constraint in its scope 
  for (IntVariable* v : scope_)
    v->registerConstraint( *this );
}


bool XeqY::consistency()
{
  Domain::EventType event;

  // This function also stores the changes into the search stack.
  event = x_->enforceInclusion(*y_);
  if (event == Domain::kFailed) return false;

  event = y_->enforceInclusion(*x_);
  if (event == Domain::kFailed) return false;

  if (isSatisfied()) 
    updateStatus(kSatisfied);
  // else if( Domain::changed(event) )
  //   updateStatus(event);
  
  return true;  
}


std::string XeqY::dump()
{
  return std::to_string(ObjectInfo::id()) + " : XeqY( " +
    x_->name() + ", " + y_->name() + " )";  
}
