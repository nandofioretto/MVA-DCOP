#ifndef ULYSSES_KERNEL_CONSTRAINTS_INTHARDCONSTRAINT_H_
#define ULYSSES_KERNEL_CONSTRAINTS_INTHARDCONSTRAINT_H_

#include "Kernel/globals.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Stores/restorable.hh"

class IntVariable;

// It defines the Abstract class for Intensional Hard Constraints.
class IntHardConstraint : public Constraint, public Restorable
{
public:

  enum ConstraintStatus{
    kNone,			// constraint has to be propagated
    kFixedPoint,		// No more changes possible at this AC iteration
    kSatisfied,			// The constraint is definetively satisfied
    kUnsatisfied		// The constraint is definetively unsatisfied
  };

  // Initializes the constraint status as kNone, sets the constraint type
  // and its scope as the one given as a parameter.
  IntHardConstraint(std::vector<IntVariable*> scope, 
		    std::vector<int> int_args = std::vector<int>(),
		    std::vector<double> real_args = std::vector<double>());
  
  virtual ~IntHardConstraint() { };

  // It is a (most probably incomplete) consistency function which removes the
  // values from variables domains. Only values which do not have any support
  // in a solution space are removed.
  virtual bool consistency() = 0; 
   
  // It imposes the constraint in the constraint store.
  // virtual void impose(/*Store store*/) const = 0;

  // It is executed after the constraint has failed. It allows to clean some 
  // data structures. 
  virtual void cleanAfterFailure() = 0;	

  // It changes the constraint status of the constraint after propagation.
  virtual void resetStatus() = 0;

  // It returns true if the constraint is satisfied.
  virtual bool isSatisfied() = 0;

  // It returns the number of integer arguemnts of the constraint.
  int nbIntArguments() const
  {
    return int_arguments_.size();
  }

  // It returns the number of real arguemnts of the constraint.
  int nbRealArguments() const
  {
    return real_arguments_.size();
  }

  // It returns the pos-th integer arguemnt of the constraint.
  int intArgument(int pos) const
  {
    ASSERT( pos < nbIntArguments(), "Requiring invalid integer argument");
    return int_arguments_[ pos ];
  }

  // It returns the pos-th real arguemnt of the constraint.
  int realArgument(int pos) const
  {
    ASSERT( pos < nbRealArguments(), "Requiring invalid real argument");
    return real_arguments_[ pos ];
  }

  // It returns the constraint status in the current store.
  ConstraintStatus status() const
  {
    return status_;
  }

  // It sets the constraint status in the current store.
  void setStatus(ConstraintStatus status)
  {
    status_ = status;
  }

  // It changes the constraint status in the current store.
  void updateStatus(ConstraintStatus status);

  // It returns a Summary Description.
  virtual std::string dump() = 0;


 protected:  
  // Avoids calls to copy constructor and assign operator.
  DISALLOW_COPY_AND_ASSIGN(IntHardConstraint);
 
  // A vector of integer coefficients
  std::vector<int> int_arguments_;

  // A vector of real coefficients
  std::vector<double> real_arguments_;

  // The constraint current status.
  // NOTE: The constraint stuse has to be restored during backtrack. 
  ConstraintStatus status_;

};


#endif  // ULYSSES_KERNEL_CONSTRAINTS_INTHARDCONSTRAINT_H_
