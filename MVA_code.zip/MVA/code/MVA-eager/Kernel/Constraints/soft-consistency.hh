#ifndef ULYSSES_KERNEL__CONSTRAINTS__SOFT_CONSISTENCY_H_
#define ULYSSES_KERNEL__CONSTRAINTS__SOFT_CONSISTENCY_H_

#include "Kernel/globals.hh"
#include "Kernel/Constraints/consistency-manager.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Stores/store.hh"

#include <vector>
class Agent;

class SoftConsistency : public ConsistencyManager
{
public:
  typedef std::unique_ptr<SoftConsistency> sptr;
  typedef std::unique_ptr<SoftConsistency> uptr;
  
  ///typedef Store<ExtSoftConstraint*> constraintStore;
  typedef std::vector<ExtSoftConstraint*> constraintStore;
  typedef  std::vector<IntVariable*>::const_iterator vit;

  SoftConsistency(Agent& owner);

  ~SoftConsistency();

  // It initializes the constraint store by loading all the (soft)
  // constraints involving the variables given as a parameter.
  // It also initializes the variable observer.
  //
  // @param variables The set of variables involved in the search of this agent,
  //        and any copy of the boundary variable of neighbouring agents, 
  //        depending on the DCOP protocol adopted.
  // @param constraints The set of constraints involving exclusiverly the 
  //        variables given as a parameter.
  virtual void initialize(std::vector<oid_t> variables,
			  std::vector<oid_t> constraints);

  virtual void initialize(std::vector<Constraint*> constraints);

  // It flushes the constraint and the variable queues and restores the 
  // constraint status information (e.g., fixpoint).
  virtual void flush();

  // It computes the cost for all constraints currently loaded in the constraint 
  // queue. 
  virtual bool enforceConsistency();

  bool enforceConsistency(std::vector<int> values);

  // It sets the constraint to check to those given as parameter, which 
  // represent the indexes of the constraints in the constraint_queue_.
  void setQueue(std::vector<int> c_indexes)
  {
    std::copy (c_indexes.begin() , c_indexes.end(), curr_queue_map_.begin() );
    curr_queue_size_ = c_indexes.size();
  }

  // It sets the constraint queue to the complete constraint queue.
  void setQueue()
  {
    for (int i = 0; i < constraint_queue_.size(); ++i)
      curr_queue_map_[ i ] = i;
    curr_queue_size_ = constraint_queue_.size();
  }

  // It returns the current cost computed via consistency enforcement.
  virtual cost_t cost() const
  {
    return curr_cost_;
  }

  virtual std::string dump() const;
  

protected:
  // The variables involved in this consistency manager
  std::vector<IntVariable*> variables_;
  
  // The collection of constraints observed by this consistency manager.
  constraintStore constraint_queue_;

  // The list of constraints to check, which are, by default, set to all 
  // those contained in the constraint_queue_.
  std::vector<int> curr_queue_map_;
  size_t curr_queue_size_;

  // the element in position [i][j] corresponds to the index of the variable
  // in the vector variables_ which is the j-th variable in the scope of the 
  // i-th constraint in the constraint_queue_.
  std::vector<std::vector<vit> > map_cscope_varidx_;

  std::vector<std::vector<size_t> > map_cscope_varidx2_;

  // The current value assignments, one for each constraint.
  // The i-th element of this vector is an array of value assignment corresponding
  // to the value assignemnts needed to compute the cost of constraint stored
  // at position i of the constraint_queue_
  std::vector< int* > curr_assignment_;

  // The current cost computed after enforcing consistency.
  cost_t curr_cost_;
};

#endif  // ULYSSES_KERNEL__CONSTRAINTS__SOFT_CONSISTENCY_H_
