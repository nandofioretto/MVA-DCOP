#include "Kernel/globals.hh"
#include "Kernel/Constraints/arc-consistency.hh"
#include "Kernel/Constraints/int-hard-constraint.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Variables/variable-observer.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Problem/dcop-instance.hh"
#include "Utilities/statistics.hh"
#include "Utilities/Statistics/local-statistics.hh"

#include <set>

using namespace std;

ArcConsistency::ArcConsistency(Agent& owner)
  : ConsistencyManager(owner)
{ }

// All the variables which can trigger a change in a domain or a domain copy 
// of another agent.
// All the constraints which involve exclusiverly the variables given as a 
// parameter.
void ArcConsistency::initialize(vector<oid_t> variables,
                                vector<oid_t> constraints)
{
  std::vector<Variable*> _variables;
  for (IntVariable* v : g_dcop->variables(variables))
    _variables.push_back( v );
  var_changed_observer_.initialize( _variables );
  std::vector<IntHardConstraint*> H;
  for (Constraint* c : g_dcop->constraints(constraints)) 
    H.push_back( dynamic_cast<IntHardConstraint*>(c) );
  constraint_queue_.initialize( H );
}


void ArcConsistency::initialize(vector<Constraint*> constraints)
{
  std::vector<IntHardConstraint*> H;
  for (Constraint* c : constraints)
    if (c->type() == Constraint::kIntHard)
      H.push_back( dynamic_cast<IntHardConstraint*>(c) );

  // Retrieve the variables involved in the given constraints
  std::set<IntVariable*> _vset;
  for (IntHardConstraint* c : H)
    for (IntVariable* v : c->scope()) _vset.insert( v );

  // popolate the array of variables
  std::vector<Variable*> variables;
  for (IntVariable* v : _vset) variables.push_back( v );

  var_changed_observer_.initialize( variables );
  constraint_queue_.initialize( H );
}


void ArcConsistency::flush() 
{
  // Reset Local constraint AC Fixpoints before returning
  for( int i=0; i<constraint_queue_.capacity(); ++i )
    constraint_queue_.at( i )->resetStatus();
  
  constraint_queue_.flush();
  var_changed_observer_.flush();
}


// @todo: check on backtrack
bool ArcConsistency::enforceConsistency()
{
  // Fill the constraint-store with the variable changed 
  var_changed_observer_.execute( enqueueConstraints, constraint_queue_ );
  
  // note: queue contains only constraints that have not reached fixpt yet 
  while( not constraint_queue_.isEmpty() )
  {
    while( not constraint_queue_.isEmpty() )
    {
      IntHardConstraint& hc = *constraint_queue_.ttop();
      owner().statistics().incrNCCCs();
      
      if( not hc.consistency() )
      { 
        hc.cleanAfterFailure();
        flush(); 
        return false; 
      }
    }

    // Fill the constraint-store with the variable changed 
    var_changed_observer_.execute( enqueueConstraints, constraint_queue_ );
  }
  
  flush(); 

  return true;
}

