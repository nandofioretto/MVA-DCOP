#ifndef ULYSSES_KERNEL__CONSTRAINTS__CONSTRAINT_FACTORY_H_
#define ULYSSES_KERNEL__CONSTRAINTS__CONSTRAINT_FACTORY_H_

#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Constraints/int-hard-constraint.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint1.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint2.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint3.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint4.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint5.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint6.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint7.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint8.hh"
#include "Kernel/Constraints/boosted/ext-soft-constraint9.hh"

#include <rapidxml.hpp>
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>

class Constraint;
class IntHardConstraint;
class ExtSoftConstraint;
class IntVariable;
class DCOPmodel;
class SearchEngine;
class Codec;

class ConstraintFactory
{
public:
  // It constructs and returns a new constraint.
  static Constraint* create(rapidxml::xml_node<>* conXML, 
                            rapidxml::xml_node<>* relsXML, 
                            std::vector<Agent*> agents,
                            std::vector<IntVariable*> variables);

  // The factory method used by the pseudo-variable preprocessing.
  // It creates a constraint by geneating all the feasible values with 
  // the search engine given as a parameter.
  static Constraint* create(std::string c_name,
                            std::vector<IntVariable*> c_scope,
                            std::vector<Agent*> agents,
                            SearchEngine& SE,
                            Codec& codec);

  // The factory method used by the pseudo-variable preprocessing
  // to convert an inter-agent constraint in the original model.
  static Constraint* create(Constraint* old_c, 
        std::unordered_map<oid_t, oid_t> invmap_agents, 
        std::unordered_map<oid_t, Agent*> map_agents_id,
        std::unordered_map<oid_t, IntVariable*> map_variables_id, 
        std::unordered_map<oid_t, std::shared_ptr<Codec> >  map_codec,
        std::vector<Agent*> new_agents,
        DCOPmodel& model);

  // It resets the constraints counter.
  static void resetCt() 
  { p_constraints_ct = 0; }


private:
  
  // The Constraints counter. It holds the ID of the next constraint to be
  // created.
  static int p_constraints_ct;

private:
  // It returns the scope of the constraint 
  static std::vector<IntVariable*> getScope
    (rapidxml::xml_node<>* conXML, std::vector<IntVariable*> variables);

  // It constructs an intensional hard constraint from the xml bit
  static IntHardConstraint* createIntHardConstraint
    (rapidxml::xml_node<>* conXML, rapidxml::xml_node<>* relXML, std::vector<IntVariable*> variables);

  // It construct the specialized intensional hard constraint given its type. 
  static IntHardConstraint* createIntHardConstraint
    (std::string type, std::vector<IntVariable*> scope, std::vector<int> iargs, std::vector<double> rargs);

  // It constructs an extensional hard constraint from the xml bit
  static ExtSoftConstraint* createExtSoftConstraint
    (rapidxml::xml_node<>* conXML, rapidxml::xml_node<>* relXML, std::vector<IntVariable*> variables);

  // It constructs the specialized extensional soft constraint given its arity. 
  static ExtSoftConstraint* createExtSoftConstraint
    (int arity, std::vector<IntVariable*> scope, size_t nb_tuples, int def_cost);

  // Sets common constraint properties and initializes mappings.
  static void setProperties(Constraint* c, std::string name, std::vector<Agent*> agents);
  
};


#endif // ULYSSES_KERNEL__CONSTRAINTS__CONSTRAINT_FACTORY_H_
