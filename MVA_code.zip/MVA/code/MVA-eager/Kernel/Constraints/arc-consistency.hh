#ifndef ULISSE_KERNEL_CONSTRAINTS_ARCCONSISTENCY_H_
#define ULISSE_KERNEL_CONSTRAINTS_ARCCONSISTENCY_H_

#include "Kernel/Constraints/consistency-manager.hh"
#include "Kernel/Constraints/int-hard-constraint.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Stores/store.hh"

#include <vector>

class Agent;

class ArcConsistency : public ConsistencyManager
{
public:
  typedef Store<IntHardConstraint*> constraintStore;

  ArcConsistency(Agent& owner);
  
  // It initializes the constraint store by loading all the (hard)
  // constraints involving the variables given as a parameter.
  // It also initializes the variable observer.
  //
  // @param variables The set of variables involved in the search of this agent,
  //        and any copy of the boundary variable of neighbouring agents, 
  //        depending on the DCOP protocol adopted.
  // @param constraints The set of constraints involving exclusiverly the 
  //        variables given as a parameter.
  // DEPRECATED
  void initialize(std::vector<oid_t> variables,
		  std::vector<oid_t> constraints);
  
  void initialize(std::vector<Constraint*> constraints);

  // It flushes the constraint and the variable queues and restores the 
  // constraint status information (e.g., fixpoint).
  void flush();

  // It implements the specific Consistency function. 
  // It also involve the calls to the propagators for the constraints currently 
  // loaded in the constraint queue. 
  bool enforceConsistency();

private:
  // It enqueues all the constraints whose scope involves the variable given as 
  // a paramenter. The constraint is added to the queue, only after considering
  // its current state (e.g., it is not added if it is already satisfied).
  //
  // @complexity: Linear to the number of constraints involving var.
  static void enqueueConstraints(Variable* var, constraintStore& S)
  {
    // check if to transform S into something like for the variables 
    // and remove S from this object 
    for (int i=0; i < var->nbConstraints(Constraint::kIntHard); ++i)
    {
      IntHardConstraint& hc = var->intHardConstraintAt( i ); 
      if( hc.status() != IntHardConstraint::kFixedPoint and
	  hc.status() != IntHardConstraint::kSatisfied )
	// This function checks whether the constraint should be controlled
	// by this queue or not.
        S.push( &hc );
    }
  }

private:
  // The collection of constraints observed by this AC manager.
  constraintStore constraint_queue_;
  
};

#endif  // ULISSE_KERNEL_CONSTRAINTS_ARCCONSISTENCY_H_
