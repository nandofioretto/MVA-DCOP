#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Kernel/Variables/int-variable.hh"

ExtSoftConstraint::ExtSoftConstraint
(std::vector<IntVariable*> scope, size_t nb_tuples, cost_t def_cost)
  : p_nb_tuples(nb_tuples), p_default_cost(def_cost),
    p_best_finite_cost(Constants::worstvalue),
    p_worst_finite_cost(Constants::bestvalue)
{
  // constraint parameters:
  type_ = kExtSoft;
  scope_ = scope;
  for(IntVariable* v : scope)
    scope_ids_.push_back(v->id());
}


// It returns a Summary Description.
std::string ExtSoftConstraint::dump()
{
  std::string result = std::to_string(ObjectInfo::id())
    + " (" + std::to_string(p_nb_tuples) + " / " 
    + std::to_string(p_default_cost) + ") : "
    + ObjectInfo::name() + "( ";  
  for( int i=0; i<arity(); i++ )
    result += scope_[ i ]->name() + ", ";
  result += ")";
  
  result +="\n:content:\n";
  resetIterator();
  int* vals = new int[ arity() ];
  int cost;
  while(next()){
    getNext(vals, cost);
    for(int i=0; i<arity(); ++i)
      result += std::to_string(vals[i]) + " ";
    result += "\t: " + std::to_string(cost) + "\n";
  }
  delete[] vals;
  
  return result;
}
