#include "Kernel/Constraints/constraint-state.hh"
#include "Kernel/Constraints/int-hard-constraint.hh"
//#include "Kernel/Constraints/ext-soft-constraint.hh"


ConstraintState::ConstraintState(IntHardConstraint& c)
  : ref_(&c), status_(c.status())
{ }


// ConstraintState::ConstraintState(const ExtSoftConstraint& c)
//   : ref_(dynamic_cast<Constraint*>(&c))
// { }

ConstraintState::ConstraintState(const ConstraintState& other)
  : ref_(other.ref_), status_(other.status_)
{ }


ConstraintState::~ConstraintState()
{ }
