#ifndef ULYSSES__KERNEL__STORES__CONSTRAINT_STATE_H_
#define ULYSSES__KERNEL__STORES__CONSTRAINT_STATE_H_

#include "Kernel/globals.hh"
#include "Kernel/Stores/state.hh"
#include "Kernel/Constraints/int-hard-constraint.hh"


// It is used to save the minimal representation for a constraints state.
// It implements a State, an object of the search stack.
class ConstraintState : public State
{
public:
  // It saves the state of an intensional hard constraint given as a parameter.
  ConstraintState(IntHardConstraint& c);

  // It saves the state of an extensional soft constraint given as a parameter.
  // ConstraintState(const ExtSoftConstraint& c);
  ConstraintState(const ConstraintState& other);

  virtual ~ConstraintState();

  // It restores the previous state of the constraint linked.
  virtual void restore()
  {
    ref_->setStatus(status_);
  }

private:
  // The reference to the constraint being stored.
  IntHardConstraint* ref_;
  // Only applies for int-hard constraints.
  IntHardConstraint::ConstraintStatus status_;
};


#endif // ULYSSES__KERNEL__STORES__CONSTRAINT_STATE_H_
