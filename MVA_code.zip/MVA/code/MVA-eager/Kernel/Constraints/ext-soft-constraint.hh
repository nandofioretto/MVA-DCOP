#ifndef ULYSSES_KERNEL__CONSTRAINTS__EXT_HARD_CONSTRAINT_H_
#define ULYSSES_KERNEL__CONSTRAINTS__EXT_HARD_CONSTRAINT_H_

#include "Kernel/globals.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Stores/restorable.hh"
#include "Utilities/utils.hh"

class IntVariable;

// It defines the Abstract class for Extensional Soft Constraints.
// TODO: The aim is to implement it as a TABLE CONSTRAINT
class ExtSoftConstraint : public Constraint, public Restorable 
{
 public:

  // It sets the constraint type, scope, number of tuples contained in 
  // the explicit relation and default cost.
  ExtSoftConstraint
  (std::vector<IntVariable*> scope, size_t nb_tuples, cost_t def_cost);

  virtual ~ExtSoftConstraint() { };
  
  // It sets the cost associated to the value assignemnt passed as a parameter.
  virtual void setCost( int* K, cost_t cost ) = 0;

  // It returns the cost associated to the value assignemnt passed as a 
  // parameter.
  virtual cost_t getCost( int* K ) = 0;

  // It is a (most probably incomplete) consistency function which removes the
  // values from variables domains. Only values which do not have any support
  // in a solution space are removed.
  virtual bool consistency() { return true; }
    
  // It is executed after the constraint has failed. It allows to clean some 
  // data structures. 
  virtual void cleanAfterFailure() { }	

  // It sets the next iterator to the point to the begin of the utilities array.
  virtual void resetIterator() = 0;
    
  // This is only good for HARD (SOFT) constraints and if the solution space is 
  // relatively sparse. It returns true if the iterator has not reach the last 
  // element of the domain.
  virtual bool next() const = 0;

  // Returns the values and cost of the next valid tuple 
  virtual void getNext(int* values, int& cost) = 0;

  // void setBestCost(cost_t best)
  // {
  //   p_best_finite_cost = best;
  // }
  //
  cost_t bestCost() const
  {
    return p_best_finite_cost;
  }
  //
  // void setWorstCost(cost_t worst)
  // {
  //   p_worst_finite_cost = worst;
  // }
  //
  cost_t worstCost() const
  {
    return p_worst_finite_cost;
  }

  // It returns a Summary Description.
  virtual std::string dump();
  
  virtual cost_t defaultCost() const
    { return p_default_cost; }

  virtual size_t sizeBytes() const
  {
    return p_nb_tuples * arity() * sizeof( size_t ); 
  }
  
protected:
  void p_updateBounds(cost_t cost)
  {
     p_best_finite_cost = Utils::getBest(p_best_finite_cost, cost);
     p_worst_finite_cost = Utils::getWorst(p_worst_finite_cost, cost);
  }

 protected:
  // It disallows the copy constructor and operator=
  DISALLOW_COPY_AND_ASSIGN(ExtSoftConstraint);
  
  // The number of value combinations listed in the relation.
  size_t p_nb_tuples;
  
  // Default cost, that is the cost associated to any value combination that is 
  // not explicitally listed in the relation.
  cost_t p_default_cost;

  // The best and worst finite costs of this constraint which is used as bounds 
  // in some searches. 
  cost_t p_best_finite_cost;
  cost_t p_worst_finite_cost;

};


#endif // ULYSSES_KERNEL__CONSTRAINTS__EXT_HARD_CONSTRAINT_H_ 
