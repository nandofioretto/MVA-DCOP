#ifndef ULYSSES_KERNEL__CONSTRAINTS__BOOSTED__EXT_SOFT_CONSTRAINT_5_H_
#define ULYSSES_KERNEL__CONSTRAINTS__BOOSTED__EXT_SOFT_CONSTRAINT_5_H_

#include "Kernel/globals.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Kernel/Variables/int-variable.hh"
#include <boost/functional/hash.hpp>

#include <vector>


class ExtSoftConstraint5 : public ExtSoftConstraint 
{
 public:
 
  ExtSoftConstraint5(std::vector<IntVariable*> scope, size_t nb_tuples, 
		     cost_t def)
    : ExtSoftConstraint( scope, nb_tuples, def )
  {
    // Register the constraint in its scope 
    for (IntVariable* v : scope_)
      v->registerConstraint( *this );
  }

  virtual void setCost( int* K, cost_t cost )
  {
    utilities_[ {K[0], K[1], K[2], K[3], K[4]} ] = cost;
    p_updateBounds(cost);
  }
    
  /**
   * Return the cost associated to the tuple.
   * K *must* have size 3.
   */
  virtual cost_t getCost ( int* K )
  {
    got_ = utilities_.find ({K[0], K[1], K[2], K[3], K[4]});
    if( got_ == utilities_.end() ) return p_default_cost;
    return utilities_[ {K[0], K[1], K[2], K[3], K[4]} ];
  }
  
  virtual void resetIterator()
  {
    next_ = utilities_.begin();
  }

  virtual bool next() const
  {
    return( next_ != utilities_.end() );
  }

  virtual void getNext(int* K, int& cost)
  {
    cost = next_->second;
    K[ 0 ] = next_->first.a;
    K[ 1 ] = next_->first.b;
    K[ 2 ] = next_->first.c;
    K[ 3 ] = next_->first.d;
    K[ 4 ] = next_->first.e;
    ++next_;
  }
 
 private:

  struct Key
  {
    int a; int b; int c;
    int d; int e;
    
    bool operator==(const Key &other) const
    { return (a == other.a && b == other.b && c == other.c &&
	      d == other.d && e == other.e); }
  };
  
  struct KeyHasher
  {
    std::size_t operator()(const Key& k) const
    {
      using boost::hash_value;
      using boost::hash_combine;
      std::size_t seed = 0;
      
      hash_combine(seed,hash_value(k.a));
      hash_combine(seed,hash_value(k.b));
      hash_combine(seed,hash_value(k.c));
      hash_combine(seed,hash_value(k.d));
      hash_combine(seed,hash_value(k.e));
      
      return seed;
    }
  };
  
  // The list of utilities
  std::unordered_map<Key,cost_t,KeyHasher> utilities_;
  std::unordered_map<Key,cost_t,KeyHasher>::const_iterator got_;
  std::unordered_map<Key,cost_t,KeyHasher>::const_iterator next_;

};


#endif // ULYSSES_KERNEL__CONSTRAINTS__BOOSTED__EXT_SOFT_CONSTRAINT_5_H_
