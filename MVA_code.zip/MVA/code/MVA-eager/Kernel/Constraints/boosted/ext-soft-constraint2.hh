#ifndef ULYSSES_KERNEL__CONSTRAINTS__BOOSTED__EXT_SOFT_CONSTRAINT_2_H_
#define ULYSSES_KERNEL__CONSTRAINTS__BOOSTED__EXT_SOFT_CONSTRAINT_2_H_

#include "Kernel/globals.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"
#include "Kernel/Variables/int-variable.hh"
#include <boost/functional/hash.hpp>

#include <vector>


class ExtSoftConstraint2 : public ExtSoftConstraint 
{
 public:
 
  ExtSoftConstraint2(std::vector<IntVariable*> scope, size_t nb_tuples, 
		     cost_t def)
    : ExtSoftConstraint( scope, nb_tuples, def )
  {
    // Register the constraint in its scope 
    for (IntVariable* v : scope_)
      v->registerConstraint( *this );
  }

  virtual void setCost( int* K, cost_t cost )
  {
    utilities_[ {K[0], K[1]} ] = cost;
    p_updateBounds(cost);    
  }
    
  /**
   * Return the cost associated to the tuple.
   * K *must* have size 2.
   */
  virtual cost_t getCost ( int* K )
  {
    got_ = utilities_.find ({K[0], K[1]});
    if( got_ == utilities_.end() ) return p_default_cost;

    return utilities_[ {K[0], K[1]} ];
  }
  
  virtual void resetIterator()
  {
    next_ = utilities_.begin();
  }

  virtual bool next() const
  {
    return( next_ != utilities_.end() );
  }

  virtual void getNext(int* K, int& cost)
  {
    cost = next_->second;
    K[ 0 ] = next_->first.a;
    K[ 1 ] = next_->first.b;
    ++next_;
  }

  virtual std::string dump() const
  {
    std::string result;
    for (auto& kv : utilities_)
      {
	result += std::to_string(kv.first.a) + " "
	  + std::to_string(kv.first.b) + ": "
	  + std::to_string(kv.second) + "\n";
      }
    return result;
  }

 private:

  struct Key
  {
    int a; int b;
    
    bool operator==(const Key &other) const
    { return (a == other.a && b == other.b); }
  };
  
  struct KeyHasher
  {
    std::size_t operator()(const Key& k) const
    {
      using boost::hash_value;
      using boost::hash_combine;
      std::size_t seed = 0;
      
      hash_combine(seed,hash_value(k.a));
      hash_combine(seed,hash_value(k.b));
      
      return seed;
    }
  };
  
  // The list of utilities_
  std::unordered_map<Key,cost_t,KeyHasher> utilities_;
  std::unordered_map<Key,cost_t,KeyHasher>::const_iterator got_;
  std::unordered_map<Key,cost_t,KeyHasher>::const_iterator next_;

};


#endif  // ULYSSES_KERNEL__CONSTRAINTS__BOOSTED__EXT_SOFT_CONSTRAINT_2_H_
