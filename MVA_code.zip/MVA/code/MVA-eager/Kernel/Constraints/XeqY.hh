/**
 *  XeqY.hh
 *  This file is part of Ulysses.
 *
 *  Ulysses is a Decentralized Constraint Optimization solver
 *	
 *  Copyright (C) 2014 Ferdinando Fioretto (ffiorett@cs.nmsu.edu)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *  
 *  Notwithstanding any other provision of this License, the copyright
 *  owners of this work supplement the terms of this License with terms
 *  prohibiting misrepresentation of the origin of this work and requiring
 *  that modified versions of this work be marked in reasonable ways as
 *  different from the original version. This supplement of the license
 *  terms is in accordance with Section 7 of GNU Affero General Public
 *  License version 3.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef ULYSSES_KERNEL_CONSTRAINTS_INTHARDCONSTRAINT_XEQY_H_
#define ULYSSES_KERNEL_CONSTRAINTS_INTHARDCONSTRAINT_XEQY_H_

#include "Kernel/globals.hh"
#include "Kernel/Constraints/int-hard-constraint.hh"
#include "Kernel/Variables/int-variable.hh"

#include <string>

// Constraint X != Y
// 
// The consistency function employes domain consistency.
class XeqY : public IntHardConstraint 
{
public:
  // It assignes the variables x and y
  XeqY(IntVariable& x, IntVariable& y);

  virtual ~XeqY() { }
  
  // It is a (most probably incomplete) consistency function which removes the
  // values from variables domains. Only values which do not have any support
  // in a solution space are removed.
  virtual bool consistency();

  // It imposes the constraint in the constraint store.
  // virtual void impose(/*Store store*/) const = 0;

  // It is executed after the constraint has failed. It allows to clean some 
  // data structures. 
  virtual void cleanAfterFailure() 
  {}	

  // It changes the constraint status of the constraint after propagation.
  // Reset the constraint status, if it reached a local fixed-point only.
  virtual void resetStatus()
  {
    if( status_ == kFixedPoint ) status_ = kNone;
  }

  // Check whether the constraint is satisfied
  virtual bool isSatisfied()
  {
    return (x_->isSingleton() and y_->isSingleton() and x_->min() == y_->min());
  }

  // It returns a Summary Description.
  virtual std::string dump();


 private:
  
  // The variables involved in the constraint.
  IntVariable* x_;
  IntVariable* y_;
};


#endif  // ULISSE_KERNEL_CONSTRAINTS_INTHARDCONSTRAINT_H_
