#ifndef ULISSE_KERNEL_CONSTRAINTS_CONSISTENCYMANAGER_H_
#define ULISSE_KERNEL_CONSTRAINTS_CONSISTENCYMANAGER_H_

#include "Kernel/Variables/variable-observer.hh"
#include <vector>

class Constraint;
class Variable;
class Agent;

// It defines the Abstract class for any consistency manager, e.g.,
// Arc Consistency, Soft Arc Consistency, Branch Consistency, etc.
class ConsistencyManager
{
public:
  ConsistencyManager(Agent& owner)
    : p_owner(&owner)
  { }
  
  virtual ~ConsistencyManager()
  { }
  
  // It initializes the constraint store by loading all the (hard/soft)
  // constraints involving the variables given as a parameter.
  virtual void initialize(std::vector<oid_t> variables,
			  std::vector<oid_t> constraints) = 0;

  // It initializes the constraint store by loading all the (hard/soft)
  // constraints involving the variables given as a parameter.
  virtual void initialize(std::vector<Constraint*> constraints) = 0;

  // It flushes the constraint and the variable queues and restores the 
  // constraint status information (e.g., fixpoint).
  virtual void flush() = 0;

  // It implements the specific Consistency function. 
  // It also involve the calls to the propagators for the constraints currently 
  // loaded in the constraint queue. 
  virtual bool enforceConsistency() = 0;
    
  // Returns the consistency manger's owner.
  Agent& owner() const 
  {
    return *p_owner; 
  }
  
  
protected:
  // The agent executing this consistency manager.
  // It is used to record Statistics infomation
  Agent* p_owner;
  
  // The queue of variable changed by the constraint propagation.
  // It is used to monitor the variables that can be possibly trigger other
  // constraint propagation phases.
  VariableObserver var_changed_observer_;
};

#endif  // ULISSE_KERNEL_CONSTRAINTS_CONSISTENCYMANAGER_H_
