#ifndef ULYSSES_KERNEL_STORES_STATE_H_
#define ULYSSES_KERNEL_STORES_STATE_H_

// The abstract class for a state object to be stored into a a search stack.
class State
{
public: 
  State() { }
  
  virtual ~State() { }

  virtual void restore() = 0;

};

#endif  // ULYSSES_KERNEL_STORES_STATE_H_
