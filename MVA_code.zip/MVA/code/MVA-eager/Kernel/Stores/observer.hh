#ifndef ULYSSES_KERNEL_OBSERVER_H_
#define ULYSSES_KERNEL_OBSERVER_H_

class Observer
{
public:
  virtual void update() = 0;
  virtual void flush() = 0;
};

#endif  // ULYSSES_KERNEL_OBSERVER_H_
