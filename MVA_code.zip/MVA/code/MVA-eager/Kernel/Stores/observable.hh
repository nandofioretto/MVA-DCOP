#ifndef ULYSSES_KERNEL_OBSERVABLE_H_
#define ULYSSES_KERNEL_OBSERVABLE_H_

class Observer;

// The Abstract class for an observable object.
class Observable
{
  // It register this object to the observer given as a parameter.
  virtual void registerObserver(Observer* ob) = 0;

  // It removest the observer given as a parameter from the observers list.
  virtual void removeObserver(Observer* ob) = 0;

  // It notifies the observers about some changes of this object 
  virtual void notifyObservers() = 0;

};


#endif  // ULYSSES_KERNEL_OBSERVABLE_H_
