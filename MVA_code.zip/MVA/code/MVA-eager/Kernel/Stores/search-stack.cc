#include "Kernel/Stores/search-stack.hh"
#include "Kernel/Stores/restorable.hh"
#include "Kernel/Variables/variable-state.hh"
#include "Kernel/Constraints/constraint-state.hh"


SearchStack::SearchStack()
{ 
  static oid_t kSearchStackCounter_ = 0;
  setId( kSearchStackCounter_++);
}


SearchStack::~SearchStack()
{ 
  clear();
}

// void SearchStack::initialize(std::vector<Restorable*> objs)
// {
//   for (auto& o : objs) 
//     o->registerSearchStack(this);
// }

void SearchStack::registerRestorable(Restorable* o)
{
  o->registerSearchStack(this);
}


void SearchStack::clear()
{
  while ( !memory_.empty() )
  {
    State* state = memory_.top();
    delete state;
    state = nullptr;
    memory_.pop();
  }
}


void SearchStack::restore(size_t continuation)
{
  while (memory_.size() > continuation)
  {
    State* state = memory_.top();
    state->restore();
    delete state;
    state = nullptr;
    memory_.pop();  
  }
}
