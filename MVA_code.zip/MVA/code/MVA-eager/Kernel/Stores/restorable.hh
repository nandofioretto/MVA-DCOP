#ifndef ULYSSES_KERNEL_STORES_RESTORABLE_H_
#define ULYSSES_KERNEL_STORES_RESTORABLE_H_

#include "Kernel/globals.hh"
#include "Kernel/Stores/state.hh"
#include "Kernel/Stores/search-stack.hh"

#include <unordered_map>

// The class for a restorable object.
class Restorable
{
public:

  // It initializes the search stack to null
  Restorable();

  // It register this object to the search stack given as a parameter.
  void registerSearchStack(SearchStack* ss)
  {
    //mapSearch_stack_[ ss->id() ] = ss;
    search_stack_ = ss;
  }

  // It notifies the search stack about some changes of this object, and it
  // memorizes the object state in it.
  void notifySearchStack(State* state)
  {
    search_stack_->save( state );
  }
  
  bool isRestorable() const
  {
    return search_stack_ != nullptr; 
  }
  
private:
  // The pointer to a search stack
  //std::unordered_map<oid_t, SearchStack*> mapSearch_stack_;

  SearchStack* search_stack_;

};

#endif  // ULYSSES_KERNEL_STORES_RESTORABLE_H_
