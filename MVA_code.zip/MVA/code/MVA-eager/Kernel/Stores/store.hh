#ifndef ULYSSES_KERNEL_STORE_H_
#define ULYSSES_KERNEL_STORE_H_

#include "Kernel/globals.hh"
#include <unordered_map>
#include <vector>
#include <algorithm>

template<typename T> 
class Store
{

public:
  
  // It constructs an empty store.
  Store()
    : size_(0), capacity_(0)
  { }

  ~Store() { }
  
  // It initializes a store with the elements given as a parameter.
  // The elements are initially loaded in the container but the not 
  // activated for execution.
  // 
  // @note: For elemets T, copy constructor and assignemnt operator 
  // are *required*
  void initialize(std::vector< T > elems)
  {
    capacity_ = elems.size();
    size_ = 0;

    container_.resize(capacity_);
    store_.resize(capacity_);
    in_store_.resize( capacity_, false );
    mapElem2Pos_.reserve( capacity_ );
    
    for (int i = 0; i < capacity_; ++i )
    {
      store_[ i ] = elems[ i ];
      container_[ i ] = elems[ i ];
    }
    
    for (int i = 0; i < capacity_; ++i ) 
    {
      mapElem2Pos_[ elems[ i ] ] = i;
    }
  }

  // It consumes an element from the store.
  // It does so by marking the correspoding position in the in_store_ bitmask.
  // 
  // @complexity: Constant
  void consume(T& elem)
  {
    in_store_[ mapElem2Pos_[ elem ] ] = false;
  }

  // It returns true if the element given as a parameter is loaded into the 
  // store, i.e., is listed as an active element.
  //
  // @complexity: Constant
  bool contains(T& elem)
  {
    return in_store_[ mapElem2Pos_[ elem ] ];
  }

  // It returns true if the element given as a parameter is controlled by 
  // this store (active or non active).
  //
  // @complexity: Constant
  bool controls(T& elem)
  {
    return( mapElem2Pos_.find( elem ) != mapElem2Pos_.end() );
  }

  // It pushes the element given as a parameter into the store.
  //
  // @complexity: Constant
  void push(T elem)
  {
    // check whether the element belongs to the store and 
    // it is not already in it
    if( controls( elem ) and (not contains( elem )) )
    {
      store_[ size_++ ] = elem;
      in_store_[ mapElem2Pos_[ elem ] ] = true;
    }
  }

  // It pops out the last element inserted in the store.
  //
  //@complexity: Constant.
  void pop()
  {
    in_store_[ mapElem2Pos_[ store_[ --size_ ] ] ] = false;
  }

  // It returns the last element of the store.
  //
  // @note: This function returns a *copy* of the object in the store. 
  // @complexity: Constant.
  T top() const
  {
    return store_[ size_-1 ];
  }


  // It removes the last element inserted from the store and returns it.
  //
  // This function is equivalent to:
  // pop()
  // top()
  //
  // @note: This function returns a *copy* of the object in the store. 
  // @complexity: Constant.
  T ttop( )
  {
    T id = top();
    pop();
    return id;
  }

  // It removes all the elements currently held in the store.
  // It does so by deactivating their state.
  //
  // @complexity: Linear in the store size.
  void flush()
  {
    std::fill(std::begin(in_store_), std::end(in_store_), false);
    size_ = 0;
    // while (size_ > 0)
    //   pop();
  }

  // It returns the actual store size, i.e., the number of active elements
  // held in the store. 
  size_t size() const
  {
    return size_;
  }

  // It returns true if the store is empty, i.e., it contains no active elements.
  bool isEmpty() const 
  {
    return (size_ == 0);
  }  

  // It returns the store capacity, i.e., the number of elements registered
  // into the store.
  size_t capacity() const
  {
    return capacity_;
  }
  
  // It returns the pos-th element of the store container.
  T& at( int pos ) 
  {
    return container_[ pos ]; 
  }

  // It returns the store content.
  std::vector< T >& storeContent()
  {
    return container_;
  }

  std::string dump() const
  {
    std::string result = "";
    // for (auto& e : container_)
    // {
    //   result += e.dump() + "\n";
    // }
    return result;
  }

private:
  DISALLOW_COPY_AND_ASSIGN( Store );

  // It contains all the elements that could be managed by this store. 
  std::vector< T > container_;
  
  // It contains the elements in order of which they will be extracted.
  std::vector< T > store_;
  
  // Marks the presence of each element in the vector store.
  std::vector< bool > in_store_;
  
  // The current store size (only active elements).
  size_t size_;
  
  // The actual store capacity.
  size_t capacity_;
  
  // key   = an element in the store
  // value = its position in the array "store"
  std::unordered_map<T, int> mapElem2Pos_;

};

#endif  // ULYSSES_KERNEL_STORE_H_
