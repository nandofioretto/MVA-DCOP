#ifndef ULYSSES_KERNEL_STORES_SEARCHSTACK_H_
#define ULYSSES_KERNEL_STORES_SEARCHSTACK_H_

#include "Kernel/globals.hh"
#include "Kernel/object-info.hh"
#include "Kernel/Stores/state.hh"

#include <stack>
#include <vector>

class Restorable;


// The search stack used by some search functions to implement
// backtrack or backjump.
class SearchStack : public ObjectInfo
{
public:
  SearchStack();

  ~SearchStack();

  // It register the search stack in the restorable object given as a paramter.
  void registerRestorable(Restorable* o);

  // It returns true if the search stack contains no elements.
  bool isEmpty() const
  {
    return memory_.empty();
  }

  // It returns the actual size of the search stack.
  size_t size() const
  {
    return memory_.size();
  }

  // It flushes all content from the search stack. 
  void clear();

  // It saves an object state into the search stack.
  void save(State* state)
  {
    memory_.push( state );
  }

  // It restores the states of the objects inserted in the search stack 
  // up to the "continuation" instant.
  void restore(size_t continuation);

 
private:
  // The search stack content.
  std::stack<State*> memory_;
};


#endif  // ULYSSES_KERNEL_STORES_SEARCHSTACK_H_
