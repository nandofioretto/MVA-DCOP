#include "Kernel/Stores/restorable.hh"
#include "Kernel/Stores/search-stack.hh"

Restorable::Restorable()
  : search_stack_(nullptr)
{ }
