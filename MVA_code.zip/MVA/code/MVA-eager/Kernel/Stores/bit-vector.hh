#ifndef ULYSSES_KERNEL__STORE__BIT_VECTOR_H_
#define ULYSSES_KERNEL__STORE__BIT_VECTOR_H_

#include <iostream>
#include <limits.h>

typedef int bit; // one bit, 0 or 1
typedef int word; // some bits
#ifndef WORD_BIT
#define WORD_BIT (sizeof(word)*CHAR_BIT)
#endif

class bit_vector 
{
protected:
  unsigned int dimension;
  word* words;
public:
  bit_vector(unsigned int dimension){
    this->dimension=dimension;
    this->words=new word[(this->dimension+WORD_BIT-1)/WORD_BIT];
  }
  virtual ~bit_vector(){
    delete [] this->words;
  }

  inline bit operator[](unsigned int index){
    return((index<this->dimension)
	   ?(1&(this->words[index/WORD_BIT]>>(index%WORD_BIT))):0);
  }
  
  inline bit set(unsigned int index,bit value){
    if(index<this->dimension){
      if(value==0){
	this->words[index/WORD_BIT]&=(~(1<<(index%WORD_BIT)));
      }else{
	this->words[index/WORD_BIT]|=(1<<(index%WORD_BIT)); }}
    return(value); }
  
  // so now filling the vector will be 256 times faster:
  void fill(bit value){
    word filler=(value==0)?(0):(~0);
    for(unsigned int i=0;i<(this->dimension+WORD_BIT-1)/WORD_BIT;i++){ 
      this->words[i]=filler; 
    }
  }
  
};
