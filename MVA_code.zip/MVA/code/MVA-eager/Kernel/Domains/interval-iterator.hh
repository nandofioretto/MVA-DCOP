#ifndef ULISSE_KERNEL_DOMAINS_INTERVALITERATOR_H_
#define ULISSE_KERNEL_DOMAINS_INTERVALITERATOR_H_

#include "Kernel/globals.hh"

class Interval;

// It defines an iterator over the elements of a domain.
class IntervalIterator
{
public:
  IntervalIterator() { }

  // It returns true if the iterator has not reach the last
  // element of the domain.
  virtual bool next() const = 0;
  
  // It returns the element currently pointed by the iterator
  // and it advances the iterator to the next element, if possible.
  virtual Interval& getAdvance() = 0;

  // It sets the current position of the iterator to its inital state. 
  virtual void resetIteration() = 0;

private:
  // It disables copy constructor and operator= functions.
  DISALLOW_COPY_AND_ASSIGN(IntervalIterator);

};

#endif // ULISSE_KERNEL_DOMAINS_INTERVALITERATOR_H_
