#include "Kernel/globals.hh"
#include "Kernel/Domains/interval-domain.hh"
#include "Kernel/Domains/int-domain.hh"

#include <string>
#include <vector>
#include <cmath>

IntervalDomain::IntervalDomain()
  : value_iterator_(nullptr)
{ 
  domain_type_ = IntDomain::kInterval;
}


IntervalDomain::IntervalDomain(int min, int max)
{
  ASSERT( min <= max, "Creating Instance of IntervalDomain with min: " << min 
	  << " > max: " << max);

  domain_type_ = IntDomain::kInterval;
  Interval I(min, max);
  intervals_.push_back( I );

  value_iterator_ = new IntervalValueIterator(this);
}


// Note: this is a protected copy constructor - it can only called 
// by this object.
// It copies the minimal information needed for the clone function. 
IntervalDomain::IntervalDomain(const IntervalDomain& other)
  : value_iterator_(nullptr)  
{
  domain_type_ = IntDomain::kInterval;
  intervals_ = other.intervals_;
}


IntervalDomain* IntervalDomain::clone() const
{
  return new IntervalDomain(*this);
}


void IntervalDomain::copy(IntDomain* other)
{
  ASSERT(other->type() == IntDomain::kInterval, 
	 "Trying to copy an incompatible domain type");

  intervals_.swap( (dynamic_cast<IntervalDomain*>(other))->intervals() );
}


IntervalDomain::~IntervalDomain()
{
  if (value_iterator_)
    delete value_iterator_;
}


// IntervalDomain::IntervalDomain(const IntervalDomain& other )
// {
//   intervals_ = other_.intervals;
// }


bool IntervalDomain::operator==(IntDomain& other)
{
  // Type: Interval Domain
  if (other.type() == IntDomain::kInterval) 
  {
    IntervalDomain& intervalDomain = dynamic_cast<IntervalDomain&>(other);
    bool equal = true;
    int i = 0;
    if (nbIntervals() == intervalDomain.nbIntervals()) 
    {
      while (equal && i < nbIntervals())
      {
	equal = intervals_[ i ] == intervalDomain.interval( i );
	i++;
      }
    } 
    else
      equal = false;
    
    return equal;
  }

  // Type: Bound Domain
  if (other.type() == IntDomain::kBound) 
  {   
    if (isEmpty() and other.isEmpty())
      return true;
    
    if (nbIntervals() != 1)
      return false;
			
    if (intervals_[ 0 ].min() == other.min() &&
	intervals_[ 0 ].max() == other.max())
      return true;
			
    return false;
  }

  // if (other.domainID() == SmallDenseDomainID) 
  // {
  //   // TODO CRUCIAL, create special code for SmallDenseDomain. 
  //   return ((SmallDenseDomain)other).eq(this);
  // }
		
  // Uses default dense and sparse assumptions to compute the function as
  // efficiently as possible.
  //if (other.isSparse()) 
  //{	
    bool equal = true;
    if (size() == other.size()) 
    {
      ValueIterator& vit = valueIterator();
      ValueIterator& other_vit = other.valueIterator();

      while (equal and vit.next()) 
	equal = ( vit.getAdvance() == other_vit.getAdvance() );
    } 
    else
      equal = false;
    
    return equal;
    //}
  // else
  // {
  //   bool equal = true;
  //   int i = 0;
  //   if (size() == other.size()) 
  //   {
  //     while (equal and i < nbIntervals()) 
  //     {
  // 	equal = (intervals_[ i ] == other.interval( i ));
  // 	i++;
  //     }
  //   }
  //   else
  //     equal = false;
  //   return equal;
  // }
		
}



std::string IntervalDomain::dump() const
{
  if( isEmpty() ) return "{}";

  std::string result="ID: ";
  if (!isSingleton()) 
  {
    result += "{";
    for (int i = 0; i < nbIntervals(); ++i) 
    {
      result += intervals_[ i ].dump();
      if (i + 1 < nbIntervals())
	result += ", ";
    }
    result += "}";
  } else
    result += intervals_[ 0 ].dump();
  return result;
}
