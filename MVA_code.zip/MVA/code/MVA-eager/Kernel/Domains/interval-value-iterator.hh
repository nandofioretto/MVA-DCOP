#ifndef ULISSE_KERNEL_DOMAIN_INTERVALVALUEITERATOR_H_
#define ULISSE_KERNEL_DOMAIN_INTERVALVALUEITERATOR_H_

#include "Kernel/globals.hh"
#include "Kernel/Domains/value-iterator.hh"

class Interval;
class IntervalDomain;

// It defines an iterator over the elements of a BoundDomain.
class IntervalValueIterator : public ValueIterator
{
public:
  
  IntervalValueIterator();

  // It construct and initializes the bound value iterator by setting minimum 
  // and maximum values of the domain given as a argumrnt. It sets the current 
  // position to default: the leftmost position of the interval. 
  IntervalValueIterator(const IntervalDomain* dom);

  // It initializes the bound value iterator with the minimum and maximum values
  // of the domain given as a argumrnt. It sets the current position to default:
  // i.e., the leftmost position of the interval.
  void initialize(const IntervalDomain& dom);

  // It returns true if the iterator has not reach the last
  // element of the domain.
  bool next() const;
  
  // It returns the element currently pointed by the iterator and it
  // advances the iterator to the next position.
  int getAdvance();

  // It signal that a change in the domain it enumerates has been
  // changed. The ValueIterator update its private data 
  // structures and if possible adapt the current iterator to
  // the closest (on the right) which is still in the domain.
  void signalDomainChanges();

  // It sets the current position of the iterator to its inital state. 
  void resetIteration();

  
private:
  // It disables copy constructor and operator= functions.
  DISALLOW_COPY_AND_ASSIGN(IntervalValueIterator);
  
  // The current value being pointed.
  int current_;

  // the current element being pointed: <interval, value>
  int current_interval_;  

  // The domain being pointed.
  const IntervalDomain* p_domain_;

};

#endif // ULISSE_KERNEL_DOMAIN_INTERVALVALUEITERATOR_H_
