#include "Kernel/Domains/interval.hh"

#include <limits>
#include <string>

using namespace std;

Interval::Interval() 
  : min_(std::numeric_limits<int>::min()),
    max_(std::numeric_limits<int>::max())
{ }


Interval::Interval(int min, int max) 
  : min_(min), max_(max)
{
  ASSERT((min <= max), "min value " << min 
	 << " is larger than max value " << max);
}


Interval::Interval(const Interval& other)
{
  min_ = other.min_;
  max_ = other.max_;
}


Interval& Interval::operator=(const Interval& other)
{
  if (this != &other)
  {
    min_ = other.min_;
    max_ = other.max_;
  }
  return *this;
}

std::string Interval::dump() const
{
  std::string result;
  result += std::to_string(min_);
  if (max_ != min_)
    result += ".." + std::to_string(max_);
  return result;
}
