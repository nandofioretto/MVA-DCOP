#ifndef ULISSE_KERNEL_DOMAINS_INTERVALDOMAIN_H_
#define ULISSE_KERNEL_DOMAINS_INTERVALDOMAIN_H_

#include "Kernel/globals.hh"
#include "Kernel/Domains/int-domain.hh"
#include "Kernel/Domains/interval.hh"
#include "Kernel/Domains/interval-value-iterator.hh"

#include <string>
#include <vector>

class ValueIterator;

// Defines an Integer Bound domain and the related operations on it.
// The BoundDomain is an implementation of the IntDomain object.
class IntervalDomain : public IntDomain
{
  public:
  // It creates an empty domain, which is a domain with 0 intervals.
  IntervalDomain();

  // It creates a domain with one interval [min..max].
  IntervalDomain(int min, int max);

  // It creates a copy of this object by cloning its state. Only the 
  // minimal information needed to reproduce this element is  copied. 
  // It is used to save and restore the domain state during backtrack. 
  virtual IntervalDomain* clone() const;
  
  // It copies the other domain passed as a parameter into this object.
  // The other domain is expected to contain only minimial information 
  // about the domain values.
  // It is used to restore the domain state during backtrack.
  virtual void copy(IntDomain* other);

  virtual ~IntervalDomain();

  // Returns true if the current domain is equal to the one given as a 
  // paramenter.
  virtual bool operator==(IntDomain& other);

  // It returns the idx-th element of the domain.
  virtual int operator[](int idx) const
  { 
    return elementAt(idx);
  }
  
  // It returns the idx-th element of the domain.
  virtual int elementAt(int idx) const
  {
    ASSERT( idx < size(), "The domain does not have so many elements");
    int k = 0;
    int currentRange = intervals_[ k ].max() - intervals_[ k ].min();

    while (idx > currentRange) 
    {
      idx -= currentRange + 1;
      ++k;
      if (k < size())
	currentRange = intervals_[ k ].max() - intervals_[ k ].min();
      else
	ASSERT( false, "Runtime Error: the domain does not have so many elements");
    }
    
    return intervals_[ k ].min() + idx;
  }

  // It returns the i-th interval of the domain.
  const Interval& interval( int i ) const
  {
    ASSERT( i >= nbIntervals(), "Requesting an interval index which does not exist");
    return intervals_[ i ];
  }

  // It returns the interval index associated to the interval containing
  // the value given as a parameter. 
  int intervalNbContaining(int value) const
  {
    for (int i = 0; i < nbIntervals(); ++i)
    {
      if (intervals_[ i ].min() > value)      continue;
      else if (intervals_[ i ].max() < value) continue;
      else return i;
    }
    return -1;
  }

  // It removes all elements.
  virtual void clear()
  { 
    intervals_.clear();
  }

  // It returns true if the domain is empty.
  virtual bool isEmpty() const
  { 
    return intervals_.empty();
  }

  // It returns true if the domain has only one element.
  virtual bool isSingleton() const
  {
    return (nbIntervals() == 1 and 
	    intervals_[ 0 ].min() == intervals_[ 0 ].max());
  }

  // It returns true if the domain has only one element, and 
  // if it is equal to the value given as a parameter.
  virtual bool isSingleton(int c) const 
  {
    return (nbIntervals() == 1 and 
	    intervals_[ 0 ].min() == c and intervals_[ 0 ].max() == c);
  }

  // It specifies wether the domain type is more suited to a sparse 
  // representation of values.
  virtual bool isSparse() const
  {
    return false; 
  }

  // It specifies if domain is a finite domain of numeric values (integers).
  virtual bool isNumeric() const 
  { 
    return true; 
  }
    
  // It returns the size of the domain.
  virtual size_t size() const 
  {
    int acc = 0;
    for (int i = 0; i < intervals_.size(); ++i)
      acc += (intervals_[ i ].max() - intervals_[ i ].min() + 1);
    return acc;
  }

  // It returns the previous value in the domain w.r.t. the given 'value'.
  // The next relation is intended as the lexicographic order.
  // If no value can be found then it returns the same value. 
  virtual int previousValue(int value) const
  {
    for (int i = nbIntervals() - 1; i >= 0; i--) {
      const Interval& I = intervals_[ i ];
      // the max of previous interval is the seeked value.
      if (I.min() >= value) continue;
      if (I.max() >= value and I.min() < value)
	return value - 1;
      // the value is equal 
      if (I.max() < value) return I.max();
    }
    return value;
  }

  // It returns the next value in the domain w.r.t. the given 'value'.
  // The next relation is intended as the lexicographic order.
  // If no value can be found then it returns the same value. 
  virtual int nextValue(int value) const
  {
    for (int i = 0; i < nbIntervals(); ++i) {
      const Interval& I = intervals_[ i ];
      if (I.max() > value)
      {
	if (value >= I.min() - 1)
	  return value + 1;
	else
	  return I.min();
      }
    }
    return value;
  }

  // It returns the value iterator of the domain values.
  // The value iterator iterates over the elements of this domain. It is
  // initialized so to point to the first element.
  virtual ValueIterator& valueIterator() 
  { 
    value_iterator_->resetIteration();
    return *value_iterator_;
  }

  // // It returns the interval iterator of the domain values.
  // // The interval iterator iterates over the intervals of this domain. It is
  // // initialized so to point to the first element.
  // IntervalIterator& intervalIterator()
  // { 
  //   // TODO, check a changed flag - update only if flag has changed.
  //   interval_iterator_.resetIteration();
  //   return interval_iterator_;
  // }

  // It returns the smaller domain value.
  virtual int min() const
  {
    return intervals_[ 0 ].min(); 
  }
  
  // It returns the largest domain value.
  virtual int max() const
  { 
    return intervals_.back().max(); 
  }

  // It checks whether the interval min..max belongs to current the domain.
  virtual bool contains(int min, int max) 
  { 
    for (int i = 0; i < intervals_.size(); ++i) {
      Interval& I = intervals_[ i ];
      if (I.max() >= max and min >= I.min())
	return true;
    }
    return false;
  }

  // It checks whether the value belongs to the domain.
  virtual bool contains(int value) const
  { 
    for (int i = 0; i < nbIntervals(); ++i) 
    {
      const Interval& I = intervals_[ i ];
      if (I.max() >= value and value >= I.min())
	return true;
    }
    return false;
  }

  // It returns the number of intervals of the given domain.
  size_t nbIntervals() const
  { 
     return intervals_.size();
  }
  
  // It returns the minimum element ot the i-th interval.
  // NOTE: The interval must exists.
  int minOfInterval(int i) const
  { 
    return intervals_[ i ].min();
  }

  // It returns the maximum element ot the i-th interval.
  // NOTE: The interval must exists.
  int maxOfInterval(int i) const
  {
    return intervals_[ i ].max();
  }

  // It removes the interval stored at position "int_pos".
  void remove(int int_pos)
  {
    intervals_.erase( intervals_.begin() + int_pos );
  }
  
  std::vector<Interval>& intervals()
  {
    return intervals_;
  }

  // It updates the domain by setting as new minimum value, the value
  // given as a parameter.
  virtual void setMin(int min)
  {
    ASSERT(false, "This function is not implemented!");
  }

  // It updates the domain by setting as new maximum value, the value
  // given as a parameter.
  virtual void setMax(int max)
  {
    ASSERT(false, "This function is not implemented!");
  }

  // It returns the domain description.
  virtual std::string dump() const;


protected:
  // Avoids calls to copy constructor and assign operator.
  DISALLOW_COPY_AND_ASSIGN(IntervalDomain);

  // The intervals describing the domain.
  std::vector< Interval > intervals_;
  
  // The bound interval iterator, to iterate through all the elements 
  // of the bound domain.
  IntervalValueIterator* value_iterator_;

};


#endif // ULISSE_KERNEL_DOMAINS_INTERVALDOMAIN_H_
