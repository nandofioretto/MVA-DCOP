#include "Kernel/globals.hh"
#include "Kernel/Domains/interval-value-iterator.hh"
#include "Kernel/Domains/interval-domain.hh"

IntervalValueIterator::IntervalValueIterator()
  : p_domain_(nullptr), current_( -1), current_interval_( 0 )
{ }


IntervalValueIterator::IntervalValueIterator(const IntervalDomain* dom)
  : p_domain_(dom), current_(dom->min() - 1), current_interval_( 0 )
{ }

 
void IntervalValueIterator::initialize(const IntervalDomain& dom)
{
  p_domain_ = &dom;
  current_ = dom.min() - 1;
  current_interval_ = 0;
}


bool IntervalValueIterator::next() const 
{
  return ( current_ < p_domain_->max() );
}  


int IntervalValueIterator::getAdvance() 
{ 
  ASSERT( current_ < p_domain_->max(), "iterator out of bounds");

  if (current_ < p_domain_->maxOfInterval( current_interval_ )) 
  {
    ++current_; 
  }
  else
  {
    if( current_interval_ < p_domain_->nbIntervals() )
    {
      ++current_interval_;
      current_ = p_domain_->minOfInterval( current_interval_ );
    }
  }
  return current_;
}


void IntervalValueIterator::signalDomainChanges() 
{
  current_interval_ = p_domain_->intervalNbContaining( current_ );
  if( current_interval_ == -1 )
  {
    for (int i= 0; i < p_domain_->nbIntervals(); ++i)
    {
      if (p_domain_->minOfInterval( i ) > current_) 
      {
	current_ = p_domain_->minOfInterval( i );
	current_interval_ = i;
	return;
      }
    }
  }
  
}


void IntervalValueIterator::resetIteration()
{
  current_ = p_domain_->min() - 1;
  current_interval_ = 0;
}
