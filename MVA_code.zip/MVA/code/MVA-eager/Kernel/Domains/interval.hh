#ifndef ULISSE_KERNEL_DOMAINS_INTERVAL_H_
#define ULISSE_KERNEL_DOMAINS_INTERVAL_H_

#include "Kernel/globals.hh"
#include <string>

// Defines an Integer domain and the related operations on it.
// The IntDomain is designed as an abstract object.
class Interval
{
public:

  // It creates the largest possible integer interval.
  Interval();
  
  // It creates an interval with a given minimum and maximal value.
  Interval(int min, int max);

  // It produces a new interval by copying the other one passed as a parameter.
  Interval(const Interval& other);

  // It returns true if this interval is equal to the other one passed as a 
  // parameter.
  Interval& operator=(const Interval& other);

  // It checks equality between intervals.
  bool operator==(const Interval& other)
  { return (min_ == other.min_ and max_ == other.max_); }

  // It returns the right bound of the interval (maximum value).
  int max() const
  { return max_; }

  // It returns the left range of the interval (minimum value).
  int min() const 
  { return min_; }

  void setMin(int min) 
  { min_ = min; }

  void setMax(int max) 
  { max_ = max; }

  // It checks if an intervals contains only one value (singleton).
  bool isSingleton() const
  { return (min_ == max_); }
  
  // It checks if an intervals contains only value c.
  bool isSingleton(int c) const
  { return (min_ == c and max_ == c); }

  // It returns a description of the interval content.
  std::string dump() const;


private:

  // The minimal value in the interval.
  int min_;

  // The maximal value in the interval.
  int max_;  
  
};


#endif // ULISSE_KERNEL_DOMAINS_INTERVAL_H_
