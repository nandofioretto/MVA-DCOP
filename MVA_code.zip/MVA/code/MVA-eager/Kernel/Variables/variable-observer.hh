#ifndef ULYSSES_KERNEL_VARIABLES_VARIABLEOBSERVER_H_
#define ULYSSES_KERNEL_VARIABLES_VARIABLEOBSERVER_H_

#include "Kernel/Stores/store.hh"
#include "Kernel/Stores/observer.hh"
#include <vector>

class Variable;

// This class observers and notify the variables that have been changed by the 
// propagation of some constraint.
class VariableObserver : public Observer
{

public:

  VariableObserver( );

  // It calles the initialize function 
  VariableObserver(std::vector<Variable*> vars);

  // It initializes a store of variables being observerd and register this
  // obbject in each of those variables.
  void initialize(std::vector<Variable*> vars);

  // It noitifies a change in a variable into the variable store.
  void update(Variable* var)
  {
    var_changed_.push(var);
  }
  
  // Uses a lambda function to perform an action over all the variables
  // observed as changed. 
  //
  // @param: action is a void function which takes in input a Variable*.
  // @param: S is an argument that should be passed to the function action
  //         togheter with the variable.
  //         It is used to update such arguemtn, for example a store.
  template<typename Func, typename T>
  void execute( Func action, T& S) //Store<IntHardConstraint*>& S)
  {
    while (not var_changed_.isEmpty())
      action( var_changed_.ttop(), S );
  }

  template<typename Func>
  void execute( Func action )
  {
    while (not var_changed_.isEmpty())
      action(var_changed_.ttop());
  }

  void update() { }

  // It removes all variable that have changed from the queue, leaving the 
  // queue empty.
  void flush()
  {
    var_changed_.flush();
  }

private:
  // The list of variables changed during propagation
  Store<Variable*> var_changed_;

};

#endif  // ULYSSES_KERNEL_VARIABLES_VARIABLEOBSERVER_H_
