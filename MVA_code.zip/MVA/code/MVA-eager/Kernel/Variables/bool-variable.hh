#ifndef ULISSE_KENERL_VARIABLES_BOOLVARIABLE_H_
#define ULISSE_KENERL_VARIABLES_BOOLVARIABLE_H_

#include "Kernel/globals.hh"
#include "Kernel/Variables/variable.hh"
#include "Kernel/Domains/bound-domain.hh"

#include <string>

// Defines a Boolean Variable and related operations on it.
class BoolVariable : public Variable
{
public:
  BoolVariable() { }
	
  // It creates a variable with a given name and standard BoundDomain. 
  // If the name is empty, then it is automatically generated.
  BoolVariable(std::string name="" );

  ~BoolVariable();

  // Initializes domain and store.
  void initialize(BoundDomain* dom);

  // It checks if the domains of this variable is equal to the domain of 
  // the variable given as a argument.
  virtual bool operator==(const BoolVariable& other) const
  {
    return *domain_ == other.domain();
  }

  // It returns the variable domain.
  BoundDomain& domain() const
  {
    return *domain_;
  }

  // It returns the size of the current domain.
  size_t size() 
  {
    return domain_->size();
  }

  // It checks if the domain is empty.
  bool isEmpty() const 
  {
    return domain_->isEmpty();
  }

  // It returns true if the domain contains only one value.
  bool isSingleton() const
  { 
    return domain_->isSingleton(); 
  }

  // It returns current number of constraints which are associated with
  // variable and are not yet satisfied.
  size_t nbNotSatConstraints() const
  {
    return 0;//domain_->nbNotSatConstraints();
  }

  // It returns all constraints which are associated with variable, even the
  // ones which are already satisfied.
  size_t nbConstraints() const 
  {
    return 0;//domain_->nbConstraints();
  }
	
  // It informs the variable that its variable has changed according to the 
  // specified event.
  //
  // @param event the type of the change (GROUND, BOUND, ANY).
  void domainHasChanged(Domain::EventType event) const
  {
    ASSERT ((event == Domain::kAny and not isSingleton()) or 
	    (event == Domain::kBoundChanged and not isSingleton()) or
	    (event == Domain::kSingleton and isSingleton()), 
	    "Wrong event generated");
    
    //store->addChanged(this, event, Integer.MIN_VALUE);
  }

  std::string dump() const; 

private:
  // The current domain.
  BoundDomain* domain_;
};


#endif  // ULISSE_KENERL_VARIABLES_INTVARIABLE_H_
