#include "Kernel/Variables/variable-state.hh"
#include "Kernel/Domains/int-domain.hh"

VariableState::VariableState(IntVariable& v)
  : ref_(&v), domain_(v.domain().clone())
{ }


VariableState::VariableState(const VariableState& other) 
  : ref_(other.ref_), domain_(other.domain_->clone())
{ }


VariableState::~VariableState()
{
  delete domain_; 
}
