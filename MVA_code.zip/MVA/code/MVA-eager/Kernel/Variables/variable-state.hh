#ifndef ULYSSES_KERNEL_STORES_VARIABLESTATE_H_
#define ULYSSES_KERNEL_STORES_VARIABLESTATE_H_

#include "Kernel/globals.hh"
#include "Kernel/Stores/state.hh"
#include "Kernel/Variables/int-variable.hh"

class IntDomain;

// It is used to save the minimal representation for a variable state.
// It implements a State, an object of the search stack.
class VariableState : public State
{
public:
  // It saves the state of a variable given as a parameter.
  VariableState(IntVariable& v);

  VariableState(const VariableState& other); 

  virtual ~VariableState();

  // It restores the previous state of the variable linked.
  virtual void restore()
  {
    ref_->restoreState(domain_);
  }

private: 
  // int weight_

  // The reference to the constraint being stored.
  IntVariable* ref_;

  // The variable domain copy.
  IntDomain* domain_;
};


#endif  // ULYSSES_KERNEL_STORES_VARIABLESTATE_H_
