#include "Kernel/Variables/variable-observer.hh"
#include "Kernel/Variables/variable.hh"
#include <vector>

VariableObserver::VariableObserver()
{ }

VariableObserver::VariableObserver(std::vector<Variable*> vars)
{
  initialize( vars );
}

void VariableObserver::initialize(std::vector<Variable*> vars)
{
  for (auto& v : vars)
    v->registerObserver(this);
  // Initializes the store of variables obeing observed
  var_changed_.initialize(vars);
}
