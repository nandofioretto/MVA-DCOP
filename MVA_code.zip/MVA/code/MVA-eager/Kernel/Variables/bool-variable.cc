#include "Kernel/Variables/bool-variable.hh"
#include "Kernel/Domains/bound-domain.hh"

BoolVariable::BoolVariable(std::string name)
{
  ASSERT( name.find(" ") != std::string::npos,
	  "Variable Name cannot contain spaces"); 

  if (name.empty())
    {
      std::string name = "var_bool-" + std::to_string( Variable::id() );
    }
  ObjectInfo::setName( name );
  initialize( new BoundDomain(0,1) );
}

BoolVariable::~BoolVariable()
{ 
}


void BoolVariable::initialize(BoundDomain* dom)
{
  ASSERT (dom->min() >= 0 && dom->min() <= dom->max() && dom->max() <= 1, 
	  "Boolean variable can only get value between 0..1");

  domain_ = dom; 
  // dom->searchConstraints = new ArrayList<Constraint>();
  // dom->modelConstraints = new Constraint[3][];
  // dom->modelConstraintsToEvaluate = new int[3];
  // dom->modelConstraintsToEvaluate[0] = 0;
  // dom->modelConstraintsToEvaluate[1] = 0;
  // dom->modelConstraintsToEvaluate[2] = 0;
}


std::string BoolVariable::dump() const
{
  std::string result = ObjectInfo::dump();
		
  if (domain_->isSingleton())
    result += " = ";
  else
    result += "::";
  		
  result += domain_->dump();
  return result;
}
