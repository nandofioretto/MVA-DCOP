#include "Algorithms/algorithm-factory.hh"
#include "Algorithms/algorithm.hh"
#include "Algorithms/DPOP/dpop.hh"
#include "Algorithms/AFB/afb.hh"
#include "Algorithms/DGIBBS/dgibbs.hh"
#include "Kernel/Agents/agent.hh"

#include <string>
#include <vector>

Algorithm* AlgorithmFactory::create
(Agent& a, std::string type, std::vector<std::string> params)
{
  if (type.compare("DPOP") == 0 or type.compare("dpop") == 0) {
    return new DPOP(a);
  }
  if (type.compare("AFB") == 0 or type.compare("afb") == 0) {
    return new AFB(a);
  }
  if (type.compare("DGIBBS") == 0 or type.compare("dgibbs") == 0) {
    return new DGIBBS(a, params);
  }

  return nullptr;
}
