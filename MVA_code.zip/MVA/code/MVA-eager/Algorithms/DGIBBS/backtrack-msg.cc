#include "Algorithms/DGIBBS/backtrack-msg.hh"
#include "Kernel/globals.hh"

using namespace DGibbs;

BacktrackMsg::BacktrackMsg()
  : p_delta(Constants::worstvalue), p_best_delta(Constants::worstvalue)
{ }


BacktrackMsg::~BacktrackMsg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
BacktrackMsg::BacktrackMsg(const BacktrackMsg& other)
  : Message(other)
{
  p_delta = other.p_delta;
  p_best_delta = other.p_best_delta;
}

bool BacktrackMsg::operator==(const BacktrackMsg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


BacktrackMsg* BacktrackMsg::clone()
{
  return new BacktrackMsg(*this);
}


std::string BacktrackMsg::dump() const
{
  std::string result = type() += Message::dump();

  result+="\n  Content: ";
  result+="\t delta: " + std::to_string(p_delta) +
          " best delta: " + std::to_string(p_best_delta);
  return result;

}
