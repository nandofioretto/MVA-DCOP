#ifndef ULYSSES_ALGORITHMS__DGIBBS__DGIBBS_H_
#define ULYSSES_ALGORITHMS__DGIBBS__DGIBBS_H_

#include <memory>

#include "Algorithms/algorithm.hh"
#include "Algorithms/DGIBBS/dgibbs-state.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"
#include "Communication/message-handler.hh"

class PseudoTreeConstruction;

// The Distributed Gibbs Algorithm.
class DGIBBS : public Algorithm 
{
public:  
  typedef std::unique_ptr<DGIBBS> uptr;
  typedef std::shared_ptr<DGIBBS> sptr;  

  // params[ 0 ] = max number of total iterations.
  DGIBBS(Agent& owner, std::vector<std::string> params);

  virtual ~DGIBBS();

  // It initializes the Distributed Gibbs algorithm [...]
  virtual void initialize();

  // It finalizes the Distributed Gibbs algorithm [...]
  virtual void finalize();

  // It returns true if the algorithm can be executed in this agent.
  virtual bool canRun();
  
  // It executes the Distributed Gibbs algorithm.
  virtual void run();

  // It stops the algorithm saving the current results and states if provided
  // by the algorithm itself.
  virtual void stop()
  { 
    finalize();
  }

  // It returns whether the algorithm has terminated its execution.
  virtual bool terminated() 
  { 
    return p_alg_terminated; 
  }
  
private:
  // MUST BE REMOVED AND ALG FIXED
  void p_activateValuePhaseTrick();
  // The Distributed Pseudo Tree construction Phase
  std::unique_ptr<PseudoTreeConstruction> p_pt_construction_phase;
  
  // The algorithm data content.
  DGibbs::DGibbsState::sptr p_state;

  // Use this in the algorithm base class.
  std::unordered_map<std::string, MessageHandler::status_t> p_map_status;
    
  // It marks whether the algorithm has terminated its execution.
  bool p_alg_terminated;
  
  bool p_trickdone;
};

#endif // ULYSSES_ALGORITHMS__DGIBBS__DGIBBS_H_
