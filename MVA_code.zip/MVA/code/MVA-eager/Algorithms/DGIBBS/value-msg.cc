#include "Algorithms/DGIBBS/value-msg.hh"
#include "Kernel/globals.hh"

using namespace DGibbs;

ValueMsg::ValueMsg()
  :p_curr_iteration(0), p_best_iteration(0), 
   p_delta(Constants::worstvalue), p_best_delta(Constants::worstvalue)
{ }


ValueMsg::~ValueMsg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
ValueMsg::ValueMsg(const ValueMsg& other)
  : Message(other)
{
  p_variables = other.p_variables;
  p_values = other.p_values;
  p_curr_iteration = other.p_curr_iteration;
  p_best_iteration = other.p_best_iteration;
  p_delta = other.p_delta;
  p_best_delta = other.p_best_delta;
}

bool ValueMsg::operator==(const ValueMsg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


ValueMsg* ValueMsg::clone()
{
  return new ValueMsg(*this);
}


std::string ValueMsg::dump() const
{
  std::string result = type() += Message::dump();

  result+="\n  Content: ";
  for (int i=0; i<p_variables.size(); ++i)
    result += std::to_string(p_variables[i]) + " (" 
           + std::to_string(p_values[i]) + ") ";
  result += "curr iter: " + std::to_string(p_curr_iteration)
         + " best iter: " + std::to_string(p_best_iteration) +
    "\t delta: " + std::to_string(p_delta) +
    " best delta: " + std::to_string(p_best_delta);
  return result;

}
