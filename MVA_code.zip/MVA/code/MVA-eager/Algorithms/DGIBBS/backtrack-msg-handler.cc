#include "Algorithms/DGIBBS/backtrack-msg-handler.hh"
#include "Algorithms/DGIBBS/backtrack-msg.hh"
#include "Algorithms/DGIBBS/value-msg.hh"
#include "Algorithms/DGIBBS/dgibbs-state.hh"
#include "Communication/scheduler.hh"
#include "Kernel/globals.hh"

//#include "Utilities/utils.hh"

using namespace DGibbs;

BacktrackMsgHandler::BacktrackMsgHandler(Agent& a, DGibbsState::sptr state) 
  : MessageHandler(a, "Backtrack"), p_precond(false)
{
  p_dgibbs_state = state;  
}


BacktrackMsgHandler::~BacktrackMsgHandler()
{ }


void BacktrackMsgHandler::initialize()
{ }


bool BacktrackMsgHandler::p_receivedAllMessages(int iter)
{
  // This is a fast check
  //return(p_received.size() == (p_owner_ordering->nbPseudoParents() + 1));
  // This is a slow check
  int count = 0;
  for(BacktrackMsg::sptr msg : p_received){
    if( p_owner_ordering->children().find( msg->senderID() )
      != p_owner_ordering->children().end()){
        count ++;
      }
  }
  return count == (p_owner_ordering->nbChildren());
}

void BacktrackMsgHandler::processIncoming(Message::sptr msg)
{
  int idx = storeReceivedMessage(msg);
  BacktrackMsg& vmsg = *p_received[ idx ];
  
  p_dgibbs_state->setDelta(vmsg.delta());
  p_dgibbs_state->setBestDelta(vmsg.bestDelta());
  
  if (p_receivedAllMessages(p_dgibbs_state->currIteration()))
  {
    cost_t delta_ch = 0;
    cost_t best_delta_ch = 0;
    int nb_ch = p_owner_ordering->nbChildren();
    for (BacktrackMsg::sptr recv : p_received)
    {
      delta_ch += recv->delta();
      best_delta_ch += recv->bestDelta();
    }
    delta_ch -= ((nb_ch - 1) * p_dgibbs_state->delta());
    best_delta_ch -= ((nb_ch - 1) * p_dgibbs_state->bestDelta());
    
    if (Utils::isBetter( best_delta_ch, p_dgibbs_state->bestDelta() ))
    {
      p_dgibbs_state->setBestDelta(best_delta_ch);
      p_dgibbs_state->setBestValuesCurr();
      p_dgibbs_state->setBestIteration();
    }
    
    if (p_owner_ordering->root())
    {
      cost_t delta = p_dgibbs_state->delta() - p_dgibbs_state->bestDelta();
      p_dgibbs_state->setDelta(delta);
      p_dgibbs_state->setBestDelta(0);
      p_dgibbs_state->incrCurrIteration();

      p_dgibbs_state->updateState(); // a.k.a., Sample();
      
      for (oid_t n_id : owner().neighboursID())
        p_sendValueMessage( n_id );
    }
    else{
      p_sendBacktrackMessage(p_owner_ordering->parentID());      
    }
      
    p_received.clear();
    // Check termination
    if(p_dgibbs_state->currIteration() >= p_dgibbs_state->maxNbIterations())
      p_status = MessageHandler::k_terminated;
  }
}


void BacktrackMsgHandler::p_sendBacktrackMessage(oid_t recv_id)
{
  BacktrackMsg::sptr msg (new BacktrackMsg);
  msg->setDelta(p_dgibbs_state->delta());
  msg->setBestDelta(p_dgibbs_state->bestDelta());
  
  msg->setSenderID(owner().id());
  msg->setReceiverID(recv_id);
  owner().openMailbox().send( msg );
  Scheduler::FIFOinsert(recv_id);
}


void BacktrackMsgHandler::p_sendValueMessage(oid_t recv_id)
{
  ValueMsg::sptr msg(new ValueMsg());
  msg->setVariables(owner().boundaryVariableIDs());
  msg->setValues(p_dgibbs_state->currBoundaryValues());
  msg->setCurrIteration(p_dgibbs_state->currIteration());
  msg->setBestIteration(p_dgibbs_state->bestIteration());
  msg->setDelta(p_dgibbs_state->delta());
  msg->setBestDelta(p_dgibbs_state->bestDelta());
  
  msg->setSenderID(owner().id());
  msg->setReceiverID(recv_id);
  owner().openMailbox().send( msg );
  Scheduler::FIFOinsert(recv_id);
}


void BacktrackMsgHandler::p_uponActivation()
{
  if (p_status == MessageHandler::k_none)
    p_status = MessageHandler::k_active;
}


void BacktrackMsgHandler::p_uponTermination()
{ 
  Scheduler::FIFOinsert(owner().id());
  p_status = k_terminated;
}