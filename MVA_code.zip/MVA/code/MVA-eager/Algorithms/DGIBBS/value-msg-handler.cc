#include "Algorithms/DGIBBS/value-msg-handler.hh"
#include "Algorithms/DGIBBS/value-msg.hh"
#include "Algorithms/DGIBBS/backtrack-msg.hh"
#include "Communication/scheduler.hh"

using namespace DGibbs;

ValueMsgHandler::ValueMsgHandler(Agent& a, DGibbsState::sptr state) 
  : MessageHandler(a, "Value"), p_precond(false)
{
  p_dgibbs_state = state;  
}


ValueMsgHandler::~ValueMsgHandler()
{ }


void ValueMsgHandler::initialize()
{ }


bool ValueMsgHandler::p_receivedAllMessages(int iter)
{
  // This is a fast check
  //return(p_received.size() == (p_owner_ordering->nbPseudoParents() + 1));
  // This is a slow check
  int count = 0;
  for(ValueMsg::sptr msg : p_received){
    if( p_owner_ordering->pseudoParents().find( msg->senderID() )
      != p_owner_ordering->pseudoParents().end()) {
        // ASSERT(msg->currIteration() == iter, "Something wrong here "
        //   << owner().name() <<" curr iteration: " << iter << " msg recv: " << msg->currIteration());
        count ++;//= (msg->currIteration() == iter);
      }
  }
  return count == (p_owner_ordering->nbPseudoParents());
}


void ValueMsgHandler::processIncoming(Message::sptr msg)
{
  int idx = storeReceivedMessage(msg);
  ValueMsg& vmsg = *p_received[ idx ];
  
  // Update current context with message variable values content.
  for (int i=0; i < vmsg.nbVariables(); ++i){
    if( Utils::find(vmsg.variable(i), owner().contextVariablesID()))
      p_dgibbs_state->setContext(vmsg.variable(i), vmsg.value(i) );
  }
  
  if (vmsg.senderID() == p_owner_ordering->parentID())
  {
    if (p_receivedAllMessages(p_dgibbs_state->currIteration()))
    {
      p_dgibbs_state->incrCurrIteration();
      if ( vmsg.bestIteration() == p_dgibbs_state->currIteration())
        p_dgibbs_state->setBestValuesCurr();
      else if (vmsg.bestIteration() == (p_dgibbs_state->currIteration()-1)
               && vmsg.currIteration() > p_dgibbs_state->bestIteration())
        p_dgibbs_state->setBestValuesPrev();
    
      p_dgibbs_state->setDelta( vmsg.delta() );
      p_dgibbs_state->setBestDelta( vmsg.bestDelta() );
      p_dgibbs_state->setBestIteration( vmsg.bestIteration() );

      p_dgibbs_state->updateState(); // a.k.a., sample()

      for (oid_t n_id : owner().neighboursID())
        p_sendValueMessage( n_id );
      
      if (p_owner_ordering->leaf())
        p_sendBacktrackMessage( p_owner_ordering->parentID() );
      
      p_received.clear();

      // Check termination
      if(p_dgibbs_state->currIteration() >= p_dgibbs_state->maxNbIterations())
        uponTermination();

    }
  }

}


void ValueMsgHandler::p_sendBacktrackMessage(oid_t recv_id)
{
  BacktrackMsg::sptr msg (new BacktrackMsg);
  msg->setDelta(p_dgibbs_state->delta());
  msg->setBestDelta(p_dgibbs_state->bestDelta());
  
  msg->setSenderID(owner().id());
  msg->setReceiverID(recv_id);
  owner().openMailbox().send( msg );
  Scheduler::FIFOinsert(recv_id);
}


void ValueMsgHandler::p_sendValueMessage(oid_t recv_id)
{
  ValueMsg::sptr msg(new ValueMsg());
  msg->setVariables(owner().boundaryVariableIDs());
  msg->setValues(p_dgibbs_state->currBoundaryValues());
  msg->setCurrIteration(p_dgibbs_state->currIteration());
  msg->setBestIteration(p_dgibbs_state->bestIteration());
  msg->setDelta(p_dgibbs_state->delta());
  msg->setBestDelta(p_dgibbs_state->bestDelta());
  
  msg->setSenderID(owner().id());
  msg->setReceiverID(recv_id);
  owner().openMailbox().send( msg );
  Scheduler::FIFOinsert(recv_id);
}


void ValueMsgHandler::uponActivation()
{
  if (p_status == MessageHandler::k_none)
  {
    p_status = MessageHandler::k_active;
    if(p_owner_ordering->root())
    {
      p_dgibbs_state->incrCurrIteration();
      p_dgibbs_state->updateState(); // a.k.a., sample()
      for (oid_t n_id : owner().neighboursID())
        p_sendValueMessage( n_id );
    }
  }
}


void ValueMsgHandler::uponTermination()
{ 
  Scheduler::FIFOinsert(owner().id());
  p_status = k_terminated;
}