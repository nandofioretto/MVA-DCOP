#include "Algorithms/DGIBBS/dgibbs-state.hh"
#include "Kernel/globals.hh"
#include "SearchEngines/search-engine.hh"
#include "SearchEngines/search-engine-factory.hh"
#include "Utilities/utils.hh"
#include "Utilities/constraint-utils.hh"

using namespace DGibbs;

DGibbsState::DGibbsState(Agent& owner, size_t max_nb_iteration)
  : p_prev_cost(0), p_curr_iteration(0), p_best_iteration(0), 
    p_delta(0), p_best_delta(0), 
    p_local_variables(owner.localVariableIDs()),
    p_nb_boundary_variables(owner.nbBoundaryVariables()),
    p_max_nb_iterations(max_nb_iteration)
{
  p_boundary_search = 
    SearchEngine::uptr(SearchEngineFactory::create
      (owner, owner.boundarySolver(), owner.boundarySolverParameters()));
    
  p_private_search =  
    SearchEngine::sptr(SearchEngineFactory::create
      (owner, owner.privateSolver(), owner.privateSolverParameters())); 

  p_curr_local_values.resize(owner.nbLocalVariables());
  p_prev_local_values.resize(owner.nbLocalVariables());
  p_best_local_values.resize(owner.nbLocalVariables());
  p_context.resize(owner.nbContextVariables());
  int i=0;
  for(oid_t vid : owner.contextVariablesID())
    p_context_idx[ vid ] = i++;
}


void DGibbsState::intialize(Agent& owner)
{
  reset(owner);

  // Initializes the boundary search engine
  std::vector<oid_t> v_boundary = owner.boundaryVariableIDs();
  std::vector<oid_t> v_context  = owner.contextVariablesID();
  std::vector<oid_t> c_boundary = 
    ConstraintUtils::involvingExclusively( v_boundary, owner.id() );
  std::vector<oid_t> c_context =  
    Utils::merge(c_boundary, owner.interAgentConstraintIDs());
  
  // std::cout << "Agent " << owner.name() << "\n";
  // std::cout << "boundary search: \n  scope " << Utils::dump(v_boundary)
  //   << "\n  constr:  " << Utils::dump(c_context)
  //   << "\n  context: " << Utils::dump(v_context) << "\n";
  
  p_boundary_search->initialize(v_boundary, c_context, v_context);
  p_boundary_search->setInitialAssignment(currBoundaryValues());  
  p_boundary_search->setAuxiliaryVarsAssignment(p_context);
  
  // std::cout << p_boundary_search->dump() << std::endl;
  
  // Initializes the private search engine
  std::vector<oid_t> v_private = owner.privateVariableIDs();
  std::vector<oid_t> c_private = 
    Utils::exclude(c_boundary, owner.intraAgentConstraintIDs());

  // std::cout << "private search: \n  scope " << Utils::dump(v_private)
  //   << "\n  constr:  " << Utils::dump(c_private)
  //   << "\n  context: " << Utils::dump(v_boundary) << "\n";
  // Set previous cost (pt1)
  p_boundary_search->nextSolution();
  Solution& bsol = p_boundary_search->getSolution();
     
  p_private_search->initialize(v_private, c_private, v_boundary);
  // std::cout << p_private_search->dump() << std::endl;  
  // Set previous cost (pt2)
  p_private_search->setAuxiliaryVarsAssignment(bsol.values());
  p_private_search->bestSolution();
  Solution& psol = p_private_search->getBestSolution();
  p_prev_cost = Utils::sum(bsol.cost(), psol.cost());
}


void DGibbsState::reset(Agent& owner)
{
  p_prev_cost = 0;//Constants::worstvalue;
  p_curr_iteration = 0;
  p_best_iteration = 0;
  p_delta = 0;//Constants::worstvalue;
  p_best_delta = 0;//Constants::worstvalue;
  
  // Initializes the local variables' values
  unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
  std::default_random_engine generator(seed);
  
  for(int i=0; i<owner.nbLocalVariables(); ++i) {
    IntVariable& v = owner.localVariableAt(i);
    std::uniform_int_distribution<int> U(v.min(), v.max());
    int val = U(generator);
    p_curr_local_values[ i ] = 
      p_prev_local_values[ i ] = 
        p_best_local_values[ i ] = val;    
  }
  
  // Initializes the context variables' values
  for(int i=0; i<owner.nbContextVariables(); ++i) 
  {
    IntVariable& v = owner.contextVariableAt(i);
    std::uniform_int_distribution<int> U(v.min(), v.max());
    p_context[ i ] = U(generator);
  } 
  
}


void DGibbsState::updateState()
{
  // std::cout << "UpdateState\n";
  // std::cout << dump() << std::endl;
  // std::getchar();

  p_prev_local_values = p_curr_local_values;
  
  p_boundary_search->setAuxiliaryVarsAssignment(p_context);
  p_boundary_search->nextSolution();
  Solution& boundary_sol = p_boundary_search->getSolution();
  // std::cout << "boundary sol: " << boundary_sol.dump() << "\n";
  
  p_private_search->setAuxiliaryVarsAssignment(boundary_sol.values());
  p_private_search->bestSolution();
  Solution& private_sol = p_private_search->getBestSolution();
  // std::cout << "private sol: " << private_sol.dump() << "\n";
  
  p_curr_local_values = 
    Utils::concat(boundary_sol.values(), private_sol.values());

  cost_t curr_cost = Utils::sum(boundary_sol.cost(), private_sol.cost());
  
  //ASSERT(Constants::isFinite(curr_cost), "DGibbs cannot handle infinity costs.");
  
  // Updates Delta: p_delta, curr_cost and prev_cost must be finite.
  cost_t cost_diff = DCOPinfo::maximize() ? 
    (curr_cost - p_prev_cost) : (p_prev_cost - curr_cost);
  p_delta = Utils::sum(p_delta, cost_diff);
  p_prev_cost = curr_cost;
  
  // printf("Delta: %d / Delta*: %d\n", p_delta, p_best_delta);
  
  if (Utils::isBetter(p_delta, p_best_delta))
  {
    p_best_delta = p_delta;
    p_best_local_values = p_curr_local_values;
    setBestIteration();
  }
  
  // std::cout << "------------------------------------------------\n";
  // std::cout << "curr local values: " << Utils::dump(p_curr_local_values) << "\n";
  // std::cout << "best local values: " << Utils::dump(p_best_local_values) << "\n";
  // std::cout << "------------------------------------------------\n";
  // getchar();
}


std::string DGibbsState::dump()
{
  std::string res="DGibbs state:\n";
  res+="\tlocal variables: " + Utils::dump(p_local_variables) + " context: ";
  for(auto& kv : p_context_idx) 
    res += "var_" + std::to_string(kv.first) + " (" + 
      std::to_string(p_context[kv.second]) + ") ";
  res+="\n";
  res+="\tcurr local values   : " + Utils::dump(p_curr_local_values) + "\n";
  res+="\tprev local values   : " + Utils::dump(p_prev_local_values) + "\n";
  res+="\tbest local values   : " + Utils::dump(p_best_local_values) + "\n";
  res+="\tprev cost: " + std::to_string(p_prev_cost) + "\n";
  res+="\titeration: curr: " + std::to_string(p_curr_iteration) 
     + "\tbest: " + std::to_string(p_best_iteration) + "\n";
  res+="\tdelta: curr: " + std::to_string(p_delta) 
     + "\tbest: " + std::to_string(p_best_delta) + "\n";
  return res;
}
