#include "Algorithms/DGIBBS/dgibbs.hh"
#include "Communication/mailbox.hh"
#include "Communication/message.hh"
#include "Communication/message-handler.hh"
//#include "Algorithms/PseudotreeConstruction/pseudotree-msg-handler.hh"
#include "Algorithms/Pseudo-Tree/pseudo-tree-construction.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"
#include "Algorithms/DGIBBS/value-msg-handler.hh"
#include "Algorithms/DGIBBS/backtrack-msg-handler.hh"

using namespace DGibbs;

DGIBBS::DGIBBS(Agent& owner, std::vector<std::string> params)
  : Algorithm(owner), p_alg_terminated(false), p_trickdone(false)
{ 
  size_t max_iter = Utils::stringToInt(params[0]);
  p_state = DGibbsState::sptr(new DGibbsState(owner, max_iter));

  // TEMP SOLUTION
  p_pt_construction_phase = 
    PseudoTreeConstruction::uptr(new PseudoTreeConstruction(owner));
}


DGIBBS::~DGIBBS()
{ }


void DGIBBS::initialize()
{
  p_state->intialize(owner());

  // PseudotreeMsgHandler::sptr pseudotree_mh(new PseudotreeMsgHandler(owner()));
  // -----------------------------------
  p_pt_construction_phase->initialize();
  // -----------------------------------
  ValueMsgHandler::sptr value_mh(new ValueMsgHandler(owner(), p_state));
  BacktrackMsgHandler::sptr backtrack_mh(new BacktrackMsgHandler(owner(), p_state));
  
  // PseudotreeMsgMailer::sptr pseudotree_mm(new PseudotreeMsgMailer(owner()));
  // ValueMsgMailer::sptr value_mm(new ValueMsgMailer(owner()));
  // BacktrackMsgMailer::sptr backtrack_mm(new BacktrackMsgMailer(owner()));
    
  //attachMailSystem("Pseudotree", pseudotree_mh);
  attachMailSystem("Value", value_mh);
  attachMailSystem("Backtrack", backtrack_mh);
    
  //pseudotree_mh->initialize();
  value_mh->initialize();
  backtrack_mh->initialize();
  
  p_map_status["Pseudotree"] = MessageHandler::k_none;
  p_map_status["Value"] = MessageHandler::k_none;
  p_map_status["Backtrack"] = MessageHandler::k_none;
}


void DGIBBS::finalize()
{
  if (p_alg_terminated)
    return;
  
  for (int i = 0; i < owner().nbLocalVariables(); ++i)
  {
    oid_t vid = p_state->localVariables()[ i ];
    int val = p_state->bestLocalValues()[ i ];
    g_dcop->setVarSolution(vid, val);
  }
  
  if (dynamic_cast<PseudoTreeOrdering&>(owner().ordering()).root())
    g_dcop->computeSolutionCost();
    
  //detachMailSystem("Pseudotree");
  detachMailSystem("Value");
  detachMailSystem("Backtrack");
  p_alg_terminated = true;
}


bool DGIBBS::canRun()
{
  //p_activateValuePhaseTrick();
  return (!p_alg_terminated && !owner().openMailbox().empty());
}

void DGIBBS::p_activateValuePhaseTrick()
{
  // Starts the Value message phase if the agent is Root 
  if(!p_trickdone && p_map_status["Pseudotree"] == MessageHandler::k_terminated)
  {
    Algorithm::handler("Value").prcessStatus(p_map_status);
    Algorithm::handler("Value").uponActivation(); 
    p_trickdone = true;
  } 
}


void DGIBBS::run()
{
  // std::cout << "\n--------------------------------------\n";
  // std::cout << "\nrunning Agent " << owner().name() << "\n";
  // std::cout << "\n--------------------------------------\n";
  
  if (p_pt_construction_phase->canRun())
    p_pt_construction_phase->run();
  if (p_pt_construction_phase->terminated()) {
    p_map_status["Pseudotree"] = MessageHandler::k_terminated;
    p_activateValuePhaseTrick();
  }
  else
    return;	  // pass the controlo to next agents in the scheduler
  
  if(!canRun()) { return;}
  
  Message::sptr msg = owner().openMailbox().readNext();
  MessageHandler& handler = Algorithm::handler(msg->type());  
  // It reads the stauts that it needs (if it does) and prepare the execution
  // of the algorithm accordingly.
  handler.prcessStatus(p_map_status);
  // If cannot run because need to wait all messages to come, then this
  // handler needs to store this meesage upon time being.
  handler.processIncoming(msg);
  p_map_status[ handler.signature() ] = handler.status(); 
      
  // The desired number of iterations has been reached
  if (p_state->currIteration() > p_state->maxNbIterations()){
    DGIBBS::finalize();
  }
}

