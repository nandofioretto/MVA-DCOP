#ifndef ULYSSES_ALGORITHMS__DGIBBS__DGIBBS_STATE_H_
#define ULYSSES_ALGORITHMS__DGIBBS__DGIBBS_STATE_H_

#include <memory>
#include <vector>
#include <unordered_map>
#include <string>

#include "Algorithms/algorithm-state.hh"
#include "SearchEngines/search-engine.hh"


namespace DGibbs
{
class DGibbsState : public AlgorithmState
{
public:
  typedef std::unique_ptr<DGibbsState> uptr;
  typedef std::shared_ptr<DGibbsState> sptr;
  
  DGibbsState(Agent& owner, size_t max_nb_iteration);
  
  //DGibbsState(const DGibbsState& other);
    
  // It initializes its private members.
  virtual void intialize(Agent& owner);
  
  // It resets the state to its standard state.
  virtual void reset(Agent& owner);
  
  // It performs the update action on this state.
  virtual void updateState();

  std::string dump();
  
  // Getters
  std::vector<oid_t>& localVariables()
    { return p_local_variables; }
  
  std::vector<int>& currLocalValues()
    { return p_curr_local_values; }

  std::vector<int>& prevLocalValues()
    { return p_prev_local_values; }

  std::vector<int>& bestLocalValues()
    { return p_best_local_values; }

  std::vector<int> currPrivateValues() const
  {
    int size = p_local_variables.size() - p_nb_boundary_variables;
    std::vector<int> res(size);
    for(int i=0; i<size; ++i)
      res[ i ] = p_curr_local_values[ p_nb_boundary_variables + i ];
    return res;
  }

  std::vector<int> prevPrivateValues() const
  {
    int size = p_local_variables.size() - p_nb_boundary_variables;
    std::vector<int> res(size);
    for(int i=0; i<size; ++i)
      res[ i ] = p_prev_local_values[ p_nb_boundary_variables + i ];
    return res;
  }
  
  std::vector<int> currBoundaryValues() const
  {
    std::vector<int> res(p_nb_boundary_variables);
    for(int i=0; i<p_nb_boundary_variables; ++i)
      res[ i ] = p_curr_local_values[ i ];
    return res;
  }

  std::vector<int> prevBoundaryValues() const
  {
    std::vector<int> res(p_nb_boundary_variables);
    for(int i=0; i<p_nb_boundary_variables; ++i)
      res[ i ] = p_prev_local_values[ i ];
    return res;
  }

  std::vector<int> context() const
    { return p_context; }

  int prevCost() const
    { return p_prev_cost; }
  
  size_t currIteration() const
    { return p_curr_iteration; }

  size_t bestIteration() const
    { return p_best_iteration; }
   
  size_t maxNbIterations() const
    { return p_max_nb_iterations; }
  
  cost_t delta() const
    { return p_delta; }

  cost_t bestDelta() const
    { return p_best_delta; }
     
  // Setters
  void setBestValuesCurr()
    { p_best_local_values = p_curr_local_values; }

  void setBestValuesPrev()
    { p_best_local_values = p_prev_local_values; }

  void setPrevCost(int new_cost) 
    { p_prev_cost = new_cost; }
  
  void incrCurrIteration()
    { ++p_curr_iteration; }
  
  void setBestIteration()
    { p_best_iteration = p_curr_iteration; }

  void setBestIteration(size_t iter)
    { p_best_iteration = iter; }
  
  void setDelta(cost_t new_delta)
    { p_delta = new_delta; }

  void setBestDelta(cost_t new_delta)
    { p_best_delta = new_delta; }

  void setContext(oid_t var, int val)
  {
    p_context[ p_context_idx[ var ] ] = val;
  }

private:
  // The number of boundary variables of the agent. It is used to retrieve
  // the values associated to the boundary variables, in the same order
  // as stored in Agent.
  int p_nb_boundary_variables;

  // The ID of the local variables in the agent. 
  std::vector<oid_t> p_local_variables;

  // The values for the local variables in the current iteration.
  // They are stored in the same order as that of p_local_variables.
  std::vector<int> p_curr_local_values;

  // The values for the local variables in the previous iteration.
  // They are stored in the same order as that of p_local_variables.
  std::vector<int> p_prev_local_values;

  // The values of the agent's local variables in the best iteration.
  std::vector<int> p_best_local_values;
    
  // The assumption on the values of the boundary variables of the 
  // neighbour agents.
  std::vector<int> p_context;

  // Maps variables ID to the corresponding index in "p_context"
  std::unordered_map<oid_t, int> p_context_idx;

  // It stores the cost associated to the values assigned to the local
  // variables in the previous iteration.
  cost_t p_prev_cost;
  
  // The counter for the current interation.
  size_t p_curr_iteration;
  
  // It stores the iteration of the best solution found so far.
  size_t p_best_iteration;
  
  // The maximum number of iterations to run during the D-Gibbs process.
  size_t p_max_nb_iterations;
  
  // The difference in solution quality between the current solution and the 
  // best solution found in the previous iteration.
  cost_t p_delta;

  // The difference in solution quality between the best solution found in the 
  // current iteration and the best soluiotn found so far up to the previous 
  // iteration.
  cost_t p_best_delta;
  
  // The search engine associated to the boundary variables.
  SearchEngine::sptr p_boundary_search;
  
  // The search engine associated to the private variables.
  SearchEngine::sptr p_private_search;
  
};
}
#endif // ULYSSES_ALGORITHMS__DGIBBS__DGIBBS_STATE_H_