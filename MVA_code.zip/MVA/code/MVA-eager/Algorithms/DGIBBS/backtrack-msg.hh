#ifndef ULYSSES_ALGORITHMS__DGIBBS__BACKTRACK_MESSAGE_H_
#define ULYSSES_ALGORITHMS__DGIBBS__BACKTRACK_MESSAGE_H_


#include <string>
#include <vector>

#include "Communication/message.hh"
#include "Kernel/codec.hh"
#include "Kernel/globals.hh"


// The BACKTRACK message of DGIBBS.
namespace DGibbs
{
class BacktrackMsg : public Message
{
public:
  typedef std::unique_ptr<BacktrackMsg> uptr;
  typedef std::shared_ptr<BacktrackMsg> sptr;

  BacktrackMsg();

  BacktrackMsg(const BacktrackMsg& other);
  
  virtual ~BacktrackMsg();

  // Check equality of two Backtrack messages. It only checks message source and
  // destination.
  bool operator==(const BacktrackMsg& other);

  // It creates a copy of this message. 
  virtual BacktrackMsg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "Backtrack";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;

  // Setters
  void setDelta(cost_t d)
    { p_delta = d; }
  
  void setBestDelta(cost_t d)
    { p_best_delta = d; }
  
  
  // Getters
  cost_t delta() const
    { return p_delta; }
  
  cost_t bestDelta() const
    { return p_best_delta; }
  

private:  
  // Solution difference.
  cost_t p_delta;
  
  // Best solution difference.
  cost_t p_best_delta;
};
}

#endif // ULYSSES_ALGORITHMS__DGIBBS__BACKTRACK_MESSAGE_H_