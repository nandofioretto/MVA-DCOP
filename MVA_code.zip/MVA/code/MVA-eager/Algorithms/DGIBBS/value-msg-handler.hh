#ifndef ULYSSES_ALGORITHMS__DGIBBS__VALUE_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__DGIBBS__VALUE_MSG_HANDLER_H_

#include <memory>
#include <string>
#include <vector>

#include "Communication/message-handler.hh"
#include "Algorithms/DGIBBS/value-msg.hh"
#include "Algorithms/DGIBBS/dgibbs-state.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"

namespace DGibbs
{
class ValueMsgHandler : public MessageHandler
{
public:
  typedef std::unique_ptr<ValueMsgHandler> uptr;
  typedef std::shared_ptr<ValueMsgHandler> sptr;
  
  ValueMsgHandler(Agent& a, DGibbsState::sptr state);
  
  virtual ~ValueMsgHandler();
  
  // It initializes the message handler [...]
  virtual void initialize();
  
  // It reads the stauts related to the Pseudotree handler, and signal the 
  // avalability to execute the algorithm.
  virtual void prcessStatus(std::unordered_map<std::string,status_t>& map)
  {
    if (p_precond) return;
    if (map["Pseudotree"] == MessageHandler::k_terminated)
    {
      p_owner_ordering = std::make_shared<PseudoTreeOrdering>(
          dynamic_cast<PseudoTreeOrdering&>(owner().ordering()));
      p_precond = true;      
    }
  }
  
  // It processes the incoming message, which must be of type recognized by 
  // the message handler.
  virtual void processIncoming(Message::sptr msg);

  // It decodes an incoming message into a message of type specific to that of
  // the derivred class.
  virtual ValueMsg* decodeMessage(Message::sptr msg)
  {
    ASSERT(msg->type().compare(signature()) == 0, "Error in decoding message.");
    return static_cast<ValueMsg*>(msg.get());  
  }
  
  // It stores the message just received for further processing.
  virtual int storeReceivedMessage(Message::sptr msg)
  { 
    p_received.emplace_back(std::make_shared<ValueMsg>(*decodeMessage(msg)));
    return (p_received.size() - 1);
  }
    
  // ::::::::::::::::::::::::::::::::::
  // DEPRECATED - to remove
  virtual void prepareOutgoing() {}
  virtual void processIncoming() {}
  virtual void send(oid_t dest_id) {}
  // ::::::::::::::::::::::::::::::::::
  
  void uponActivation();

  void uponTermination();
  
private:
  bool pCanRun()
  {
    return p_precond;
  }
  
  // It prepares and send a Value message to the agent with ID given as a 
  // parameter.
  void p_sendValueMessage(oid_t recv_id);
  
  // It prepares and send a Backtrack message to the agent with ID given as a 
  // parameter.
  void p_sendBacktrackMessage(oid_t recv_id);

  // Returns true if the handler has received all messages from all its 
  // pseudo-parents.
  bool p_receivedAllMessages(int iter);
  
private:
  std::vector<ValueMsg::sptr> p_received;
    
  // The precondition to run this message handler is that the pseudo-tree
  // construction has be terminated.
  bool p_precond;

  // The Dgibbs mutable state
  DGibbs::DGibbsState::sptr p_dgibbs_state;
  
  // The ordering associated to the agent running this handler.
  PseudoTreeOrdering::sptr p_owner_ordering;
};
}
#endif // ULYSSES_ALGORITHMS__DGIBBS__VALUE_MSG_HANDLER_H_