#ifndef ULYSSES_ALGORITHMS__DGIBBS__VALUE_MESSAGE_H_
#define ULYSSES_ALGORITHMS__DGIBBS__VALUE_MESSAGE_H_


#include <string>
#include <vector>

#include "Communication/message.hh"
#include "Kernel/codec.hh"
#include "Kernel/globals.hh"


// The VALUE message of basic DPOP.
// It collects the values associated to the DCOP solution detected
// during the UTIL propagation phase. 
namespace DGibbs
{
class ValueMsg : public Message
{
public:
  typedef std::unique_ptr<ValueMsg> uptr;
  typedef std::shared_ptr<ValueMsg> sptr;

  ValueMsg();

  ValueMsg(const ValueMsg& other);

  virtual ~ValueMsg();

  // Check equality of two Value messages. It only checks message source and
  // destination.
  bool operator==(const ValueMsg& other);

  // It creates a copy of this message. 
  virtual ValueMsg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "Value";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;

  // Setters
  void setVariables(std::vector<oid_t> variables)
    { p_variables = variables; }

  void setValues(std::vector<int> values)
    { p_values = values; }
  
  void setCurrIteration(int t)
    { p_curr_iteration = t; }

  void setBestIteration(int t)
    { p_best_iteration = t; }

  void setDelta(cost_t d)
    { p_delta = d; }
  
  void setBestDelta(cost_t d)
    { p_best_delta = d; }
  
  // Getters  
  size_t nbVariables() const
    { return p_variables.size(); }
  
  oid_t variable(int i) const
    { return p_variables[ i ]; }

  int value(int i) const
    { return p_values[ i ]; }
  
  size_t currIteration() const
    { return p_curr_iteration; }

  size_t bestIteration() const
    { return p_best_iteration; }

  cost_t delta() const
    { return p_delta; }
  
  cost_t bestDelta() const
    { return p_best_delta; }

private:
  // The boundary variables which are sent to the neighbouring agents
  std::vector<oid_t> p_variables;
  
  // The values associated to the boundary values.
  std::vector<int> p_values;

  // The current iteration of the D-Gibbs process, associated to the agent
  // sending this message.
  size_t p_curr_iteration;
  
  // The iteration associated to the best solution found by the agent
  // sending this message.
  size_t p_best_iteration;
  
  // Solution difference.
  cost_t p_delta;
  
  // Best solution difference.
  cost_t p_best_delta;
};
}

#endif // ULYSSES_ALGORITHMS__DGIBBS__VALUE_MESSAGE_H_