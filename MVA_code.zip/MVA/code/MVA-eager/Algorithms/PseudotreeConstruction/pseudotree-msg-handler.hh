#ifndef ULYSSES_ALGORITHMS__PSEUDOTREE_CONSTRUCTION__PSEUDO_TREE_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__PSEUDOTREE_CONSTRUCTION__PSEUDO_TREE_MSG_HANDLER_H_

#include <map>
#include <memory>
#include <vector>

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"
#include "Algorithms/PseudotreeConstruction/pseudotree-msg.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"

class Agent;
class Message;
class PseudotreeMsg;


// The message handler associated to messages of type: PSEUDO-TREE
class PseudotreeMsgHandler : public MessageHandler
{
public:
  typedef std::unique_ptr<PseudotreeMsgHandler> uptr;
  typedef std::shared_ptr<PseudotreeMsgHandler> sptr;  

  PseudotreeMsgHandler(Agent& a);

  virtual ~PseudotreeMsgHandler()
  { }

  // It initializes the message handler by pushing a message of type Pseudotree
  // into the mailbox of the elected root.
  virtual void initialize();
  
  // It reads the stauts that it needs (if it does) and prepare the execution
  // of the algorithm accordingly.
  virtual void prcessStatus(std::unordered_map<std::string,status_t>& map)
  { }
  
  // It saves the newer PSEUDO-TREE message found into the agent inbox
  // into the local p_received, and it process it:
  virtual void processIncoming(Message::sptr msg);

  // It decodes an incoming message into a message of type Pseudotree.
  // Type is already checked Already checked.
  virtual PseudotreeMsg* decodeMessage(Message::sptr msg)
  {
    ASSERT(msg->type().compare(signature()) == 0, "Error in decoding message.");
    return static_cast<PseudotreeMsg*>(msg.get());  
  }

  // It decodes an incoming message to a shared_ptr of msg type Pseudotree.
  virtual int storeReceivedMessage(Message::sptr msg)
  {
    // = with make_shared is as a std::move
    p_received = std::make_shared<PseudotreeMsg>(*decodeMessage(msg));
    return 0;
  }

  // It sends the outgoing message to the agent with id the one
  // given as a parameter.
  virtual void send(oid_t dest_id);
  
  
  /////////////////////////////////////
  // Deprecated pure virtual functions
  virtual void prepareOutgoing();        // should be move to private 
  virtual void processIncoming() {}
  /////////////////////////////////////
  
  
protected:
  // It sets the handler status to active.
  void p_uponActivation();

  // It saves the pseudo-tree node into the agent owning this handler, if the 
  // handler has terminated its execution, and sets the handler status to 
  // terminated.
  void p_uponTermination();
  
private:
  // The messages received but not yet processed
  PseudotreeMsg::sptr p_received;
  
  // The outgoing message
  PseudotreeMsg::sptr p_outgoing;

  // The tree node associated to the current construction
  PseudoTreeOrdering::sptr p_tree_node;

  // The Agent Id of the elected agent root.
  int p_elected_root;
  
  // The set of node visited so far during the Pseudo-tree exploration,
  // and updated with the set of node visited by the sending agent. 
  std::vector<oid_t> p_visited;

  // The list of nodes yet to explore together with the agent whom first 
  // discovered them.
  std::vector<std::pair<oid_t, oid_t> > p_queue;
};

#endif // ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_MSG_HANDLER_H_
