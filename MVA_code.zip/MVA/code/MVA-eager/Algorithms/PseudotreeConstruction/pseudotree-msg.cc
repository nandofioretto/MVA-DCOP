#include "Algorithms/PseudotreeConstruction/pseudotree-msg.hh"
#include "Utilities/utils.hh"

// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
PseudotreeMsg::PseudotreeMsg(const PseudotreeMsg& other)
  : Message(other)
{
  p_queue = other.p_queue;
  p_visited = other.p_visited;
}


PseudotreeMsg* PseudotreeMsg::clone()
{
  return new PseudotreeMsg(*this);
}


std::string PseudotreeMsg::dump() const
{
  std::string result = type() + Message::dump();
  result+="\t   queue: " + Utils::dump(p_queue);
  result += "\t visited: " + Utils::dump(p_visited);
  return result;
}
