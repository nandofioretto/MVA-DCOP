#include <algorithm>
#include <iostream>
#include <memory>

#include "Algorithms/PseudotreeConstruction/pseudotree-msg-handler.hh"
#include "Algorithms/PseudotreeConstruction/pseudotree-msg.hh"
#include "Communication/scheduler.hh"
#include "Communication/mailbox.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Utilities/utils.hh"

bool orderAscending(oid_t LHS, oid_t RHS) { return LHS < RHS; }
bool orderDescending(oid_t LHS, oid_t RHS) { return LHS > RHS; }


PseudotreeMsgHandler::PseudotreeMsgHandler(Agent& a) 
  : MessageHandler(a, "Pseudotree"), p_received(nullptr) 
{
  p_elected_root = 0;
  p_tree_node = 
    std::shared_ptr<PseudoTreeOrdering>(new PseudoTreeOrdering(owner()));
  p_outgoing = PseudotreeMsg::sptr(new PseudotreeMsg);

}


void PseudotreeMsgHandler::initialize()
{
  if(owner().id() == p_elected_root) 
  {
    Scheduler::clearQueue();
    p_outgoing->setSource(owner().id());
    send(owner().id());
  }
}


void PseudotreeMsgHandler::processIncoming(Message::sptr msg)
{  
  storeReceivedMessage( msg );
  p_uponActivation();

  // Mark current node as visited
  p_visited = p_received->visited();
  p_queue   = p_received->queue();
  p_visited.push_back( owner().id() );
  
  // Get node's parent and remove this node from the agent queue.
  oid_t parent_id = Constants::nullid;
  if (!p_queue.empty())
  {
    int idx = Utils::findIdxFirst( p_queue, owner().id() );
    parent_id = p_queue[ idx ].second;
    p_queue.erase( p_queue.begin() + idx );
  }

  std::vector<oid_t> neighbours = owner().neighbours();
  std::sort(neighbours.begin(), neighbours.end(), orderAscending);  

  p_tree_node->setParent( parent_id );
  
  for (oid_t n_id : neighbours)
  {
    if( n_id == parent_id ) continue; // skip parent

    if (!Utils::find(n_id, p_visited)) // not yet explored
    {
      if (!Utils::findFirst(p_queue, n_id)) {// not yet discovered by other nodes
        p_tree_node->addChild( n_id );
        p_queue.push_back( std::make_pair(n_id, owner().id()) );
      }
      else {
        p_tree_node->addPseudoChild( n_id );
      }
    }
    else // already explored
    {
      if (!Utils::findFirst(p_queue, n_id)){
        p_tree_node->addPseudoParent( n_id );
      }
      else
        ; // sibling or parent
    }
  }
  
  if (!p_queue.empty())
  {  
    oid_t dest_id = p_queue.front().first;
    // Prepare the outgoing message. Copy the queue and marked nodes.
    prepareOutgoing();  
    send( dest_id );
  }
  p_uponTermination();  
}


void PseudotreeMsgHandler::p_uponActivation()
{
  if (p_status == MessageHandler::k_none)
    p_status = MessageHandler::k_active;
}


void PseudotreeMsgHandler::p_uponTermination()
{
  owner().setOrdering(p_tree_node);
  p_tree_node.reset();		// the only owner is now the agent.
  Scheduler::FIFOinsert(owner().id());
  p_status = k_terminated;
}


void PseudotreeMsgHandler::prepareOutgoing()
{  
  p_outgoing->setSource(owner().id());
  p_outgoing->setQueue( p_queue );
  p_outgoing->setVisited( p_visited );
}

 
void PseudotreeMsgHandler::send(oid_t dest_id)
{
  ASSERT(dest_id != Constants::nullid, 
  "Trying to send a message with empty scheduler.");

  PseudotreeMsg::sptr to_send(p_outgoing->clone()); 
  to_send->setDestination(dest_id);
  owner().openMailbox().send(to_send);
  // Schedule next agent in a LIFO order
  Scheduler::LIFOinsert(to_send->destination());
}
