#ifndef ULYSSES_ALGORITHMS__PSEUDOTREE_CONSTRUCTION__PSEUDOTREE_MSG_H_
#define ULYSSES_ALGORITHMS__PSEUDOTREE_CONSTRUCTION__PSEUDOTREE_MSG_H_

#include <memory>
#include <string>
#include <vector>

#include "Kernel/globals.hh"
#include "Communication/message.hh"

class PseudotreeMsg : public Message
{
public:
  typedef std::unique_ptr<PseudotreeMsg> uptr;
  typedef std::shared_ptr<PseudotreeMsg> sptr;  
 
  PseudotreeMsg()
  { }
  
  virtual ~PseudotreeMsg()
  { }

  PseudotreeMsg(const PseudotreeMsg& other);
  
  // It creates a copy of this message. 
  virtual PseudotreeMsg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "Pseudotree";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  {
    p_queue.clear();
    p_visited.clear();
    setStamp(0);
  }

  // It returns a message description.
  virtual std::string dump() const;

  // It returns the set of agents to traverse. 
  std::vector<std::pair<oid_t,oid_t> >& queue()
  {
    return p_queue;
  }

  // It sets the set of agents to traverse to those given as parameter.
  void setQueue(std::vector<std::pair<oid_t,oid_t> > queue)
  {
    p_queue = queue;
  }

  // It returns the set of agents visited during tree traveral. 
  std::vector<oid_t>& visited()
  {
    return p_visited;
  }

  // It sets the set of agegent vistied to those given as parameter.
  void setVisited(std::vector<oid_t> visited)
  {
    p_visited = visited;
  }
    
private:
  // The set of agents still to traverse.
  std::vector<std::pair<oid_t,oid_t> > p_queue;

  // The set of agents already visited during the tree traversal.
  std::vector<oid_t> p_visited;
};

#endif // ULYSSES_ALGORITHMS__PSEUDOTREE_CONSTRUCTION__PSEUDOTREE_MSG_H_
