#include "Algorithms/DPOP/util-msg.hh"

using namespace std;

UtilMsg::UtilMsg()
{ }


UtilMsg::~UtilMsg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
UtilMsg::UtilMsg(const UtilMsg& other)
  : Message(other)
{
  p_variables = other.p_variables;
  p_utils  = other.p_utils;
  p_map_code2idx = other.p_map_code2idx;
  p_map_idx2code = other.p_map_idx2code;   
}

bool UtilMsg::operator==(const UtilMsg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


// Note: This action here, invalidate the further use of codec in the current
// object!
// This make sense in the current implementation, as the messages are cloned
// just befored being sent, then destroyed.
UtilMsg* UtilMsg::clone()
{  
  UtilMsg* msg = new UtilMsg(*this);
  msg->p_codec = std::move(this->p_codec);
  return msg;
}


string UtilMsg::dump() const
{
  string result = type() += Message::dump();

  result+="\n   variables: ";
  for (oid_t i : p_variables)
    result += to_string(i) + " ";
  result+="\n   utils: ";
  for (cost_t i : p_utils)
    result += to_string(i) + " ";

  return result;
}
