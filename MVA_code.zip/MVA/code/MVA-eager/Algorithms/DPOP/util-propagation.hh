#ifndef ULYSSES_ALGORITHMS__DPOP__UTIL_PROPAGATION_H_
#define ULYSSES_ALGORITHMS__DPOP__UTIL_PROPAGATION_H_

#include "Algorithms/algorithm.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"
#include "Kernel/Constraints/soft-consistency.hh"

#include <memory>

class Agent;
class UtilMsgHandler;
class SearchEngine;
class Codec;
class Solution;
class ValuePropagation;

typedef PseudoTreeOrdering PseudoNode;

// It implements the DPOP UTIL propagation phase for a given agent.
// It joins the UTIL tables received from its children in the UTIL messages
// and computes the UTIL table to send to its parent. 
class UtilPropagation : public Algorithm
{
public:
  typedef std::unique_ptr<UtilPropagation> uptr;
  typedef std::shared_ptr<UtilPropagation> sptr;

  typedef size_t code_t;
  typedef std::pair<code_t, cost_t> utilpair_t;
  friend class ValuePropagation;

  // Initializes the constraints which involve the variables in the sparator
  // of the agent running this algorithms.
  UtilPropagation(Agent& owner);

  virtual ~UtilPropagation();
  
  // It initializes the algorithm: it registers the UTIL message handler in the
  // agent inbox, and it construct the local space as comibnation of all the 
  // possible value assignments to the boundary variables, optimizing on the 
  // private variables. It will be used in the UTIL message construction.
  virtual void initialize();

 // It initializes the algorithm.
  virtual void finalize();

  // It returns true if the algorithm can be executed in this agent.
  virtual bool canRun();

  // It executes the algorithm. It construct the UTIL message and merges the
  // UTIL messages received from its children optimizing over the possible 
  // combinations of the boundary values.
  virtual void run();
  
  // It stops the algorithm saving the current results  and states if provided
  // by the algorithm itself.
  virtual void stop()
  { }

  // It returns whether the algorithm has terminated.
  virtual bool terminated()
  {
    return p_terminated;
  }

  // It returns true if the handler has downloaded all UTIL messages
  // received from each of the children of the pseudo-node associated with the
  // agent running this algorithm.
  virtual bool recvAllMessages();

  // Optimize the ancestor solution over the boundary variables and the
  // values of the UTIL messages received 
  virtual void optimize(Solution& v_ancestor_sol);


protected:
  // The message handler associated to this algorithm
  std::shared_ptr<UtilMsgHandler> p_msg_handler;
  
  // It signal wether the algorithm execution has terminated; 
  bool p_terminated;

  // The search engine used to generatze the best solution 
  // Boundary variable search engine
  std::unique_ptr<SearchEngine> p_v_boundary_search;
  
  // Provate variable search engine
  std::unique_ptr<SearchEngine> p_v_private_search;
  
  // External variable search engine
  std::unique_ptr<SearchEngine> p_v_ancestor_search;

  // The util vector which contains the util costs assiciated to each value 
  // value combination of the boundary variables of the agent running this 
  // algorithm.
  std::vector<utilpair_t> p_v_boundary_combo;
  
  // used to convert the list of private values to a code and viceversa.
  std::unique_ptr<Codec> p_v_boundary_codec;

  // The best value combination for the private variable. The i-th value 
  // of this vector is associated to the i-th combination of the boundry
  // variables in p_v_boundary_combo
  std::vector<code_t> p_best_v_private_combo;
  
  // used to convert the list of private values to a code and viceversa.
  std::unique_ptr<Codec> p_v_private_codec;

  // Map to be used for the VALUE phase: 
  // <ancestor tuple-code, index of boundary combo associated to it. 
  std::unordered_map<code_t, int> p_ancestorval2bcomboidx;
  
  // used to convert the list of private values to a code and viceversa.
  std::unique_ptr<Codec> p_v_ancestor_codec;

  // Checks the consistency of the constraints which involve the boundary 
  // variables of this agent with its parent and pseudo-parents.
  std::unique_ptr<SoftConsistency> p_ancestor_consistency;

  // Auxiliary DS used to store temporary values
  std::vector<int> p_ba_values;

  int p_idx_best_v_boundary;
};

#endif // ULYSSES_ALGORITHMS__DPOP__UTIL_PROPAGATION_H_

