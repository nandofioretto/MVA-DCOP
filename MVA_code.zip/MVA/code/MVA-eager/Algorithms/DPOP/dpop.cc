#include "Algorithms/DPOP/dpop.hh"
#ifdef USING_GPU
  #include "GPU/Algorithms/DPOP/gpu_util-propagation.hh"
#else
  #include "Algorithms/DPOP/util-propagation.hh"
#endif
#include "Algorithms/DPOP/value-propagation.hh"
#include "Algorithms/Pseudo-Tree/pseudo-tree-construction.hh"
#include "Algorithms/Pseudo-Tree/separator-set-construction.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Utilities/statistics.hh"
#include "Utilities/utils.hh"

using namespace std;

DPOP::DPOP(Agent& owner)
  : Algorithm(owner), p_terminated(false)
{
  p_pt_construction_phase = unique_ptr<PseudoTreeConstruction>
    (new PseudoTreeConstruction(owner));
  p_sep_construction_phase = unique_ptr<SeparatorSetConstruction>
    (new SeparatorSetConstruction(owner));
#ifdef USING_GPU
  p_util_propagation_phase = unique_ptr<UtilPropagation>
    (new GPUUtilPropagation(owner));
#else
  p_util_propagation_phase = unique_ptr<UtilPropagation>
    (new UtilPropagation(owner));
#endif
  p_value_propagation_phase = unique_ptr<ValuePropagation>
    (new ValuePropagation(owner));
}

DPOP::~DPOP()
{ }


void DPOP::initialize()
{ 
  p_pt_construction_phase->initialize();
  p_sep_construction_phase->initialize();
  p_util_propagation_phase->initialize();
  p_value_propagation_phase->initialize();
}


void DPOP::finalize()
{  
  if( !p_terminated ) {
    p_terminated = true;
    // std::cout << owner().ordering().dump() << std::endl;
  }  
  for(pair<oid_t,int> p : owner().solution())
    g_dcop->setVarSolution(p.first, p.second);
}


void DPOP::run()
{
 l_PseudoTreeConstructionPhase:
  if (p_pt_construction_phase->canRun()) {
    p_pt_construction_phase->run();
    return;
  }
  if (p_pt_construction_phase->terminated())
    goto l_SepConstructionPahse;
  return;	  // pass the controlo to next agents in the scheduler

 l_SepConstructionPahse:
  if (p_sep_construction_phase->canRun()){
    p_sep_construction_phase->run();
    return;
  }
  if (p_sep_construction_phase->terminated())
      goto l_UtilPhase;
  return;	  // pass the controlo to next agents in the scheduler

 l_UtilPhase:
  if (p_util_propagation_phase->canRun())
    p_util_propagation_phase->run();
  if (p_util_propagation_phase->terminated())
    goto l_ValuePhase;
  return;	  // pass the controlo to next agents in the scheduler
  
 l_ValuePhase:
  if (p_value_propagation_phase->canRun()) {
    p_value_propagation_phase->setUtil(p_util_propagation_phase.get());
    p_value_propagation_phase->run();
  }
  if (p_value_propagation_phase->terminated())
    finalize(); // print value assignment
  return;
}

void DPOP::stop()
{ }
