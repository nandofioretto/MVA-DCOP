#ifndef ULYSSES_ALGORITHMS__DPOP__UTIL_MSG_H_
#define ULYSSES_ALGORITHMS__DPOP__UTIL_MSG_H_

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "Communication/message.hh"
#include "Kernel/codec.hh"
#include "Kernel/globals.hh"


// The util message of basic DPOP.
// For each *valid* value combination of the boundary variables it stores the 
// utility value associated to such value combination and the the best value 
// combination of its private variables.
// 
// @note:
// The values are hence retrieved in the value propagation phase, either by a 
// search or by retrieving the values stored.
class UtilMsg : public Message
{
public:
  typedef std::unique_ptr<UtilMsg> uptr;
  typedef std::shared_ptr<UtilMsg> sptr;

  typedef size_t code_t; // The code associated to the tuple of values
  typedef int idx_t;	 // the index of the array UTILS
  
public:
  UtilMsg();

  virtual ~UtilMsg();

  // Check equality of two Util messages. It only checks message source and
  // destination.
  bool operator==(const UtilMsg& other);

  // It creates a copy of this message. 
  virtual UtilMsg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "UTIL";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;

  // It sets the UTIL variables as the list of those one given as parameter.
  void setVariables(std::vector<oid_t> variables)
  {
    p_variables = variables;
    p_codec = Codec::uptr( new Codec(variables) );
  }

  // It returns the list of the variables of the message UTIL.
  std::vector<oid_t>& variables()
  {
    return p_variables;
  }

  // It returns the i-th UTIL value.
  cost_t utilAt(size_t i) const
  {
    if (p_utils.empty())
      return Constants::worstvalue;
    
    ASSERT( i < p_utils.size(), "Invalid Read: trying to access to \
 the " << i << "-th UTIL table position of " << p_utils.size() );
    
    return p_utils[ i ];
  }

  // It returns the UTIL value, associated to the value combination given 
  // as a parameter
  // 
  // @return the UTIL value associated to the query, if it exists, or 
  //         +/- Constants::infinity otherwise.
  cost_t utilAt(std::vector<int> query)
  {
    size_t code = p_codec->encode(query);
    if (p_map_code2idx.find(code) == p_map_code2idx.end())
      return Constants::worstvalue;
    else 
      return p_utils[ p_map_code2idx[ code ] ];
  }

  // It saves the cost associated to the tuple of values given as a paramter 
  void saveUtil(std::vector<int> valtuple, cost_t cost)
  { 
    idx_t i = p_utils.size();
    code_t code = valtuple.empty() ? 0 : p_codec->encode( valtuple );
    p_map_idx2code[ i ] = code;
    p_map_code2idx[ code ] = i;
    p_utils.push_back( cost );
  }
  
  // It returns the number of utils in the UTIL vector.
  size_t nbUtils() const
  {
    return p_utils.size();
  }

  // It returns the number of variables in the UTIL vector.
  size_t nbVars() const
  {
    return p_variables.size();
  }
  
  
protected:  
  DISALLOW_COPY_AND_ASSIGN(UtilMsg);
    
private:
  // The set of variables associated with the table of Utilities.
  std::vector<oid_t> p_variables;

  // The util vector which contains the util costs assiciated to each valid 
  // value combination of the variables in p_variables.
  // The first element of the pair is a real number which encodes the
  // the values for the boundary variables (listed in the given ordering) 
  // associated to their cost, provided as the second element of the pair. 
  std::vector<cost_t> p_utils;

  // The codec for encoding and decoding the util messages.
  Codec::uptr p_codec;

  // Given the code for a tuple of values, it returns the index of the p_utils
  // vector where the corresponding cost is saved.
  std::unordered_map<code_t, idx_t> p_map_code2idx;
  // Viceversa.
  std::unordered_map<idx_t, code_t> p_map_idx2code;
};

#endif // ULYSSES_ALGORITHMS__DPOP__UTIL_MSG_H_
