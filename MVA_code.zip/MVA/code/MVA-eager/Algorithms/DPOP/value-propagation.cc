#include "Kernel/globals.hh"
#include "Utilities/utils.hh"
#include "Kernel/Agents/agent.hh"
#include "Communication/mailbox.hh"
#include "Communication/scheduler.hh"
#include "Algorithms/DPOP/value-propagation.hh"
#include "Algorithms/DPOP/value-msg-handler.hh"
#include "Algorithms/DPOP/util-msg-handler.hh"
#include "Algorithms/DPOP/util-msg.hh"
#include "Algorithms/DPOP/util-propagation.hh"

#include <vector>
#include <memory>
#include <algorithm>

using namespace std;

ValuePropagation::ValuePropagation(Agent& owner)
  : Algorithm(owner), p_terminated(false)
{
  p_msg_handler = ValueMsgHandler::sptr(new ValueMsgHandler(owner));
}


ValuePropagation::~ValuePropagation()
{ }


void ValuePropagation::initialize()
{
  Mailbox& MB = owner().openMailbox();
  attachMailSystem("VALUE", p_msg_handler);
}

void ValuePropagation::finalize()
{
  // detachMailSystem("VALUE");
  // Reschedule the agent running this algorithm to let the 
  // calling routine to continue.
  Scheduler::FIFOinsert(owner().id());
}


bool ValuePropagation::canRun()
{
  // We cannot initialize the handler at the begin because the pseudo-tree
  // construction may not have terminated.
  if (not p_msg_handler->initialized())
    p_msg_handler->initialize();

  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());
  return ( ! terminated() and
   	   (tree_node.isRoot() or recvAllMessages()));
}


bool ValuePropagation::recvAllMessages()
{
  if (!owner().openMailbox().isEmpty("VALUE")){
    p_msg_handler->processIncoming();
  }

  // Transparent rescheduling for sequential Hack:
  // Reschedule the agent running this algorithm to let the 
  // calling routine to continue.
  if(!p_msg_handler->recvAllMessages())
    Scheduler::FIFOinsert(owner().id());
  return (p_msg_handler->recvAllMessages());
}


void ValuePropagation::run()
{
  ValueMsgHandler &handler = *p_msg_handler;

  // If DCOP instance has no solution cannot retrieve values.
  if(!Constants::isFinite(g_dcop->cost())) {
    p_terminated = true;
    handler.send();
    return;
  }
   
  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());  
  if (tree_node.isRoot())
  {
    // Stores the relevant part of the agent's solution in the outgoing messages 
    handler.prepareOutgoing();
    handler.send();
  }
  else{    
    // Extract the variables/values of the agent's ancestor variables received in the
    // VALUE messages, and reorder them according to the order used by this agent 
    // UTIL propagation phase (see ancestor codec)
    std::vector<oid_t> _recv_vars = Utils::extractFirst( handler.assignmentReceived() );
    std::vector<int>   _recv_vals = Utils::extractSecond( handler.assignmentReceived() );    //

    // std::cout << "recv assignments: " << Utils::dump(handler.assignmentReceived()) << std::endl;

    std::vector<oid_t> _ordering = p_util->p_v_ancestor_codec->variables();
    // std::cout << "ordering ancestors: " << Utils::dump(p_util->p_v_ancestor_codec->variables()) << std::endl;

    std::vector<int> ordered_vals(_ordering.size()) ;
    for (int i=0; i < _ordering.size(); ++i) 
    {
      int idx = Utils::findIdx( _recv_vars, _ordering[ i ] );
      ASSERT(idx >= 0, "Error in Value propagation phase");
      ordered_vals[ i ] = _recv_vals[ idx ];
    }

    // Decode and save solution
    size_t code = p_util->p_v_ancestor_codec->encode( ordered_vals );
    int opt_b_idx = p_util->p_ancestorval2bcomboidx[ code ];    
    size_t opt_b_code = p_util->p_v_boundary_combo[ opt_b_idx ].first;
    size_t opt_p_code = p_util->p_best_v_private_combo[ opt_b_idx ];
    std::vector<int> opt_v_boundary = p_util->p_v_boundary_codec->decode(opt_b_code);
    std::vector<int> opt_v_private  = p_util->p_v_private_codec->decode(opt_p_code);

    std::vector<std::pair<oid_t, int> > sol =
      Utils::make_pairs(Utils::concat(owner().boundaryVariableIDs(), 
				                              owner().privateVariableIDs()),
                        Utils::concat(opt_v_boundary, opt_v_private));
    
    owner().saveSolution( sol );

    handler.prepareOutgoing();
    handler.send();
  }
  
  p_terminated = true;
}
