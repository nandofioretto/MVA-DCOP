#include "Algorithms/DPOP/value-msg.hh"

using namespace std;

ValueMsg::ValueMsg()
{ }


ValueMsg::~ValueMsg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
ValueMsg::ValueMsg(const ValueMsg& other)
  : Message(other)
{
  p_v_context = other.p_v_context;  
}

bool ValueMsg::operator==(const ValueMsg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


ValueMsg* ValueMsg::clone()
{
  return new ValueMsg(*this);
}

void ValueMsg::setVariables(vector<oid_t> variables)
{
  for (oid_t vid : variables) {
    p_v_context.push_back(make_pair(vid, 0));
    p_v_context[ p_v_context.size()-1 ].second = Constants::NaN;
  }
}


string ValueMsg::dump() const
{
  string result = type() += Message::dump();

  result+="\n  Content: ";
  for (pair<oid_t,int> p : p_v_context)
    result += to_string(p.first) + " (" + to_string(p.second) + ") ";
  return result;

}
