#ifndef ULYSSES_ALGORITHMS__DPOP__DPOP_H_
#define ULYSSES_ALGORITHMS__DPOP__DPOP_H_

#include "Algorithms/algorithm.hh"

#include <memory>

class PseudoTreeConstruction;
class SeparatorSetConstruction;
class UtilPropagation;
class ValuePropagation;

// The DPOP Algorithm.
class DPOP : public Algorithm 
{
public:
  
  DPOP(Agent& owner);

  virtual ~DPOP();

  // It initializes the algorithm.
  virtual void initialize();

 // It initializes the algorithm.
  virtual void finalize();

  // It returns true if the algorithm can be executed in this agent.
  virtual bool canRun()
  { 
    return true; 
  }

  // It executes the algorithm.
  virtual void run();

  // It stops the algorithm saving the current results  and states if provided
  // by the algorithm itself.
  virtual void stop();

  // It returns whether the algorithm has terminated.
  virtual bool terminated()
  { 
    return false;
  }


private:
  
  // It holds true if the algorithm is terminated for this agent
  bool p_terminated;
  
  // The Distributed Pseudo Tree construction Phase
  std::unique_ptr<PseudoTreeConstruction> p_pt_construction_phase;

  // The Distributed Separator Set construction Phase
  std::unique_ptr<SeparatorSetConstruction> p_sep_construction_phase;

  // The DPOP Util Propagation Phase
  std::unique_ptr<UtilPropagation> p_util_propagation_phase;

  // The DPOP Value Propagation Phase
  std::unique_ptr<ValuePropagation> p_value_propagation_phase;
};

#endif // ULYSSES_ALGORITHMS__DPOP__DPOP_H_
