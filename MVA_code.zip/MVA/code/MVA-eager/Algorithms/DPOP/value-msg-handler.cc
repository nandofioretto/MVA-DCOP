#include "Algorithms/DPOP/value-msg-handler.hh"
#include "Algorithms/DPOP/value-msg.hh"
#include "Algorithms/DPOP/util-msg-handler.hh"
#include "Algorithms/DPOP/util-msg.hh"
#include "Communication/scheduler.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Utilities/statistics.hh"
#include "Utilities/utils.hh"

using namespace std;

ValueMsgHandler::ValueMsgHandler(Agent& a)
  : MessageHandler(a), p_initialized(false), p_util(nullptr)
    { }


ValueMsgHandler::~ValueMsgHandler()
  { }


void ValueMsgHandler::initialize( )
{
  PseudoNode& node = dynamic_cast<PseudoNode&>(owner().ordering());
  for (oid_t cid : node.children())
  {
    ValueMsg::uptr msg(new ValueMsg);
    msg->setSource(owner().id());
    msg->setDestination( cid );
    p_outgoing.push_back( std::move(msg) );
  }
  p_initialized = true;
}


void ValueMsgHandler::processIncoming()
{
  if (owner().openMailbox().isEmpty("VALUE"))
    return;

  p_received = dynamic_pointer_cast<ValueMsg>(owner().openMailbox().readNext("VALUE"));  
  // save variables in the p_map_v_separator
  for (int i=0; i<p_received->size(); ++i)
  { 
    const std::pair<oid_t, int>& p = p_received->get( i );
    p_map_v_separator[ p.first ] = p.second;
  }
}

// Qui, 
// 1. comunica con util-handler e prendi le variabili in TEMP 
// 2  se la variabile e' boundary -> prendi il valore dalla soluzione
//    altrimenti il valore deve esser preso da uno dei messaggi incoming.
// 3. questa funzione e' chiamata quando tutti gli incoming sono stati 
//    collezionati, quindi tale variabile esiste.
void ValueMsgHandler::prepareOutgoing()
{  
  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());
  oid_t a_id = owner().id();
  for (int i=0; i<p_outgoing.size(); ++i) 
  {
    oid_t dest_id = p_outgoing[ i ]->destination();
    std::vector<oid_t> v_to_send;
    
    // Retreive the values from the util message received before 
    bool found = false;
    for (UtilMsg::sptr msg : p_util->received()) 
    {
      if (msg->source() == dest_id)
        { v_to_send = msg->variables(); found=true; break;}
    }
    ASSERT( found, "Error in preparing the outgoing VALUE messages"); 
    p_outgoing[ i ]->setVariables( v_to_send );

    // Get all value received from parent 
    std::vector<std::pair<oid_t, int> > v_context;

    if(p_received) {
      for(int i=0; i<p_received->size(); ++i)
      {
        if(not Utils::find(p_received->get( i ), v_context))
          v_context.push_back( p_received->get( i ) );
      }
    }

    std::vector<oid_t> v_boundary = owner().boundaryVariableIDs();
    std::vector<std::pair<oid_t, int> > owner_sol = owner().solution();

    for (oid_t vid : v_to_send)
    {
      int idx_in  = Utils::findIdxFirst(owner_sol, vid);
      int idx_out = Utils::findIdxFirst(v_context, vid);
      if (idx_in >= 0)
        p_outgoing[ i ]->setValue(vid, owner_sol[ idx_in ].second);
      else if (idx_out >= 0)
        p_outgoing[ i ]->setValue(vid, v_context[ idx_out ].second); 
      else
        ASSERT( false, "Error in preparing the outgoing VALUE messages"); 
    }
  }  
}


void ValueMsgHandler::send(oid_t dest_id)
{ 
  if (dest_id == Constants::nullid) 
  {
    // sends all outgoing messages
    for(int i=0; i<p_outgoing.size(); ++i) 
    {
      ValueMsg::sptr to_send(p_outgoing[ i ]->clone());
      owner().openMailbox().send(to_send);    
      Scheduler::FIFOinsert(to_send->destination());
    }
  }
}


bool ValueMsgHandler::recvAllMessages()
{
  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());
  return (tree_node.isRoot() or p_received);
}
