#ifndef ULYSSES_ALGORITHMS__DPOP__VALUE_MSG_H_
#define ULYSSES_ALGORITHMS__DPOP__VALUE_MSG_H_

#include <string>
#include <vector>

#include "Communication/message.hh"
#include "Kernel/codec.hh"
#include "Kernel/globals.hh"


// The VALUE message of basic DPOP.
// It collects the values associated to the DCOP solution detected
// during the UTIL propagation phase. 
class ValueMsg : public Message
{
public:
  typedef std::unique_ptr<ValueMsg> uptr;
  typedef std::shared_ptr<ValueMsg> sptr;

  ValueMsg();

  virtual ~ValueMsg();

  // Check equality of two Value messages. It only checks message source and
  // destination.
  bool operator==(const ValueMsg& other);

  // It creates a copy of this message. 
  virtual ValueMsg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "VALUE";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;

  void setVariables(std::vector<oid_t> variables);

  // It stores the best value (passed as parameter) associated to the 
  // agent's boundary variable given as a parameter.
  void setValue(oid_t varid, int value)
  {
    for(int i=0; i<p_v_context.size(); ++i)
      if (p_v_context[ i ].first == varid) {
        p_v_context[ i ].second = value;
        return;
      }
  }

  // It returns the list of the variables of the message UTIL.
  std::vector<std::pair<oid_t, int> >& content()
  {
    return p_v_context;
  }

  std::pair<oid_t, int> get(int i) const
  {
    return p_v_context[ i ]; 
  }

  size_t size()
  {
    return p_v_context.size();
  }


protected:
  DISALLOW_COPY_AND_ASSIGN(ValueMsg);


private:
  // The set of boundary variables and their associated values, which children
  // and pseudo children of this agent will use to select their best assignment
  std::vector<std::pair<oid_t, int> > p_v_context;
 
};

#endif // ULYSSES_ALGORITHMS__DPOP__VALUE_MSG_H_
