#ifndef ULYSSES_ALGORITHMS__PSEUDO_TREE__SEPARATOR_SET_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__PSEUDO_TREE__SEPARATOR_SET_MSG_HANDLER_H_

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"

#include <vector>
#include <memory>

class Agent;
class Message;
class SeparatorSetMsg;

// The message handler associated to messages of type: EPARATOR-SET
class SeparatorSetMsgHandler : public MessageHandler
{
public:
  typedef std::unique_ptr<SeparatorSetMsgHandler> uptr;
  typedef std::shared_ptr<SeparatorSetMsgHandler> sptr;  

  SeparatorSetMsgHandler(Agent& a);

  virtual ~SeparatorSetMsgHandler();
  
  // It downloads all the messages of type SEPARATOR-SET from the inbox of the
  // associated agent.
  virtual void processIncoming();

  // It prepare the outgoing message, based on the information 
  // collected from the received messages.
  // It merges the following two sets of messages: 'p_received' which is owned 
  // locally, and the set of all messages of type SEPARATOR-SET present into the 
  // owner inbox.
  virtual void prepareOutgoing();

  // It sends the outgoing message to the agent with id the one
  // given as a parameter.
  virtual void send(oid_t dest_id);

  // It returns the outgoing message
  SeparatorSetMsg& outgoing()
  {
    ASSERT( p_outgoing, "Outgoing message was not allocated");
    return *p_outgoing;
  }

  // It returns the next incoming message of type "PSEUDO-TREE"
  std::vector<std::shared_ptr<SeparatorSetMsg> >& received()
  {
    return p_received;
  }
  

private:
  // The messages received, and saved here as a store.
  std::vector<std::shared_ptr<SeparatorSetMsg> > p_received;
  
  // The outgoing message
  std::unique_ptr<SeparatorSetMsg> p_outgoing;

};

#endif // ULYSSES_ALGORITHMS__ORDERINGS__SEPARATOR_SET_MSG_HANDLER_H_
