#include "Algorithms/Pseudo-Tree/pseudo-tree-msg.hh"

using namespace std;

PseudoTreeMsg::PseudoTreeMsg()
{ }


PseudoTreeMsg::~PseudoTreeMsg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
PseudoTreeMsg::PseudoTreeMsg(const PseudoTreeMsg& other)
  : Message(other)
{
  p_ancestors = other.p_ancestors;  
}


PseudoTreeMsg* PseudoTreeMsg::clone()
{
  return new PseudoTreeMsg(*this);
}


string PseudoTreeMsg::dump() const
{
  string result = type() + Message::dump();
  result+="\t   ancestors: ";
  for (size_t i : p_ancestors)
    result += to_string(i) + " ";
  return result;
}
