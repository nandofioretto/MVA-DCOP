#include "Algorithms/Pseudo-Tree/separator-set-construction.hh"
#include "Algorithms/Pseudo-Tree/separator-set-msg.hh"
#include "Algorithms/Pseudo-Tree/separator-set-msg-handler.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Agents/agent-factory.hh"
#include "Communication/mailbox.hh"
#include "Communication/scheduler.hh"

#include <algorithm>
#include <memory>

using namespace std;

SeparatorSetConstruction::SeparatorSetConstruction(Agent& owner)
  : Algorithm(owner), p_terminated(false), p_msg_handler(nullptr)
{ 
  p_msg_handler = shared_ptr<SeparatorSetMsgHandler>
    (new SeparatorSetMsgHandler(owner));
}


SeparatorSetConstruction::~SeparatorSetConstruction() 
{ }


// It register messages and message handler
void SeparatorSetConstruction::initialize()
{  
  attachMailSystem("SEPARATOR-SET", p_msg_handler);
}


void SeparatorSetConstruction::finalize()
{
  detachMailSystem("SEPARATOR-SET");
  p_msg_handler.reset();

  // Sequential Hack:
  // Reschedule the agent running this algorithm to let the 
  // calling routine to continue.
  Scheduler::FIFOinsert(owner().id());
}


bool SeparatorSetConstruction::canRun()
{
  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());
  return ( ! terminated() and 
	   (tree_node.isLeaf() or recvAllMessages()));
}


bool SeparatorSetConstruction::recvAllMessages()
{
  // If received a messages containing a separator from each of its children, 
  SeparatorSetMsgHandler& handler = *p_msg_handler;

  if (!owner().openMailbox().isEmpty("SEPARATOR-SET"))
    handler.processIncoming();

  // Transparent rescheduling for sequential Hack:
  // Reschedule the agent running this algorithm to let the 
  // calling routine to continue.
  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());
  if (handler.received().size() < tree_node.nbChildren())
    Scheduler::FIFOinsert(owner().id());
    
  return (handler.received().size() == tree_node.nbChildren());
}


void SeparatorSetConstruction::run()
{
  SeparatorSetMsgHandler& handler = *p_msg_handler;

  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());

  // node: Separator set of all children already included in the node's
  // separator set.
  // Include the node's paratent and pseudo-parents (base-case)
  if (!tree_node.isRoot())
      tree_node.addSeparator(tree_node.parent());
  for (size_t pp : tree_node.pseudoParents())
    tree_node.addSeparator(pp);
  
  // Prepare the outgoing message
  handler.prepareOutgoing();
  
  if (!tree_node.isRoot())
    handler.send(tree_node.parent());
  
  // Necessary??
  for (shared_ptr<SeparatorSetMsg> r : handler.received())
    r.reset();

  p_terminated= true;
  finalize();
}
