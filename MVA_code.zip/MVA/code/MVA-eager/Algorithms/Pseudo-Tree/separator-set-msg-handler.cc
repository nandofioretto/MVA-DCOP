#include "Algorithms/Pseudo-Tree/separator-set-msg-handler.hh"
#include "Algorithms/Pseudo-Tree/separator-set-msg.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"
#include "Communication/message.hh"
#include "Communication/scheduler.hh"
#include "Communication/mailbox.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Utilities/utils.hh"

#include <iostream>
#include <memory>

using namespace std;

typedef PseudoTreeOrdering PseudoNode;

SeparatorSetMsgHandler::SeparatorSetMsgHandler(Agent& a) 
  : MessageHandler(a)
{
  p_outgoing = unique_ptr<SeparatorSetMsg>(new SeparatorSetMsg);
}


SeparatorSetMsgHandler::~SeparatorSetMsgHandler()
{ }


void SeparatorSetMsgHandler::processIncoming() 
{ 
  if (owner().openMailbox().isEmpty("SEPARATOR-SET"))
    return;
  
  PseudoNode& n = dynamic_cast<PseudoNode&>(owner().ordering());

  for (shared_ptr<Message> r : owner().openMailbox().readAll("SEPARATOR-SET"))
  {
    shared_ptr<SeparatorSetMsg> s =
      dynamic_pointer_cast<SeparatorSetMsg>(r);
    
    if (not Utils::find(s, p_received)) 
    {
      // Add separator set received from this children into separator 
      // set of this node.
      for (oid_t i : s->separator())
        n.addSeparator( i );

      p_received.push_back( std::move(s) );
     }
  }
}


void SeparatorSetMsgHandler::prepareOutgoing()
{ 
  p_outgoing->setSource(owner().id());

  PseudoNode& n = dynamic_cast<PseudoNode&>(owner().ordering());
  p_outgoing->setSeparator(n.separator());
}

 
void SeparatorSetMsgHandler::send(oid_t dest_id)
{
  ASSERT(dest_id != Constants::nullid, 
	 "Trying to send a message with empty scheduler.");

  // note: to be deleted at destination.
  shared_ptr<SeparatorSetMsg> to_send(p_outgoing->clone()); 
  to_send->setDestination(dest_id);
  
  // It also schedule the next agent.
  owner().openMailbox().send(to_send);

  // Schedule next agent in a FIFO order
  Scheduler::FIFOinsert(to_send->destination());
}
