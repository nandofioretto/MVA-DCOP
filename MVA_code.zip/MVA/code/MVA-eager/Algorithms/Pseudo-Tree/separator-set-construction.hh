#ifndef ULYSSES_ALGORITHMS__PSEUDO_TREE__SEPARATOR_SET_CONSTRUCTION_H_
#define ULYSSES_ALGORITHMS__PSEUDO_TREE__SEPARATOR_SET_CONSTRUCTION_H_

#include "Kernel/Agents/agent.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"
#include "Algorithms/Pseudo-Tree/separator-set-msg-handler.hh"

#include <memory>

typedef PseudoTreeOrdering PseudoNode;


// It implements the distributed separator set construction.
// Starting from the leaves of the pseudo-tree, each agent constructs
// its separator set as the union of: (a) separators received from its 
// children, and (b) its parent and pseudoparents, minus itself.
class SeparatorSetConstruction : public Algorithm
{
public:
  typedef std::unique_ptr<SeparatorSetConstruction> uptr;
  typedef std::shared_ptr<SeparatorSetConstruction> sptr;  
  
  // Initializes the flag p_terminated and the pseudo-tree node, whose 
  // separator set will be constructed by this algorithm.
  SeparatorSetConstruction(Agent& owner);

  virtual ~SeparatorSetConstruction();
  
 // It initializes the algorithm.
  virtual void initialize();

 // It initializes the algorithm.
  virtual void finalize();

  // It returns true if the algorithm can be executed in this agent:
  // Either the node associated to this agent is a leaf, or it has received
  // a message of type SEPARATOR-SET (that is, its children terminated this
  // phse).
  virtual bool canRun();

  // It executes the algorithm.
  virtual void run();

  // It stops the algorithm saving the current results  and states if provided
  // by the algorithm itself.
  virtual void stop()
  { }

  // It returns whether the algorithm has terminated.
  virtual bool terminated()
  {
    return p_terminated;
  }

  // It returns true if the handler has downloaded all SEPARATOR-SET messages
  // received from each of the children of the pseudo-node associated with the
  // agent running this algorithm.
  bool recvAllMessages();


private:
  // The message handler associated to this algorithm
  std::shared_ptr<SeparatorSetMsgHandler> p_msg_handler;
  
  // This flag is set to true when the agent associated to this 
  // node has built his separator set. 
  bool p_terminated;
};

#endif // ULYSSES_ALGORITHMS__PSEUDO_TREE__SEPARATOR_SET_CONSTRUCTION_H_

