#ifndef ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_MSG_H_
#define ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_MSG_H_

#include <string>
#include <set>

#include "Kernel/globals.hh"
#include "Communication/message.hh"

class PseudoTreeMsg : public Message
{
public:
  typedef std::unique_ptr<PseudoTreeMsg> uptr;
  typedef std::shared_ptr<PseudoTreeMsg> sptr;  
 
  PseudoTreeMsg();

  virtual ~PseudoTreeMsg();

  // It creates a copy of this message. 
  virtual PseudoTreeMsg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "PSEUDO-TREE";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  {
    p_ancestors.clear();
    setStamp(0);
  }

  // It returns a message description.
  virtual std::string dump() const;

  // It adds the ancestor id given as a parameter into the ancestors set.
  void addAncestor(size_t a_id)
  {
    p_ancestors.insert(a_id);
  }

  // It adds the ancestors id given as a parameter into the ancestors set.
  void addAncestor(std::set<size_t> a_ids)
  {
    p_ancestors.insert(a_ids.begin(), a_ids.end());
  }

  // It returns the set of ancestor's id. 
  std::set<size_t>& ancestors()
  {
    return p_ancestors;
  }
  
  
protected:
  DISALLOW_COPY_AND_ASSIGN(PseudoTreeMsg);
  
  
private:
  // The set of all agents traversed in the path to reach the current agent.
  std::set<size_t> p_ancestors;

};

#endif // ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_MSG_H_
