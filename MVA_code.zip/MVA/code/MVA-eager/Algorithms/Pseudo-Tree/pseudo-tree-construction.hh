#ifndef ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_CONSTRUCTION_H_
#define ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_CONSTRUCTION_H_

#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"
#include "Algorithms/Pseudo-Tree/pseudo-tree-msg-handler.hh"

#include "Problem/dcop-instance.hh"
#include <memory>

typedef PseudoTreeOrdering PseudoNode;


// It implements the distributed pseudo-tree construction.
class PseudoTreeConstruction : public Algorithm
{
public:
  typedef std::unique_ptr<PseudoTreeConstruction> uptr;
  typedef std::shared_ptr<PseudoTreeConstruction> sptr;  
  
  // Initializes the flag marked and the pseudo-tree node 
  // which this algorithm will construct within a pseudo-tree.
  PseudoTreeConstruction(Agent& owner);

  virtual ~PseudoTreeConstruction();
  
 // It initializes the algorithm.
  virtual void initialize();

 // It initializes the algorithm.
  virtual void finalize();

  // It returns true if the algorithm can be executed in this agent.
  virtual bool canRun();

  // It executes the algorithm.
  virtual void run();

  // It stops the algorithm saving the current results  and states if provided
  // by the algorithm itself.
  virtual void stop()
  { }

  // It returns whether the algorithm has terminated.
  virtual bool terminated()
  {
    // Handle special case of DCOP with 1 agent:
    if (g_dcop->nbAgents() == 1 and !p_visited)
      { return false; }

    return (p_recv_counter == owner().nbNeighbours());
  }


private:
  // The message handler associated to this algorithm
  std::shared_ptr<PseudoTreeMsgHandler> p_msg_handler;
  
  // The Agent Id of the elected agent root.
  int p_elected_root;

  // The tree node associated to the current construction
  std::shared_ptr<PseudoNode> p_tree_node;
  
  // This flag is set to true when the agent associated to this 
  // node has explored during the distributed DFS step. 
  bool p_visited;

  // It counts the number of messages received.
  int p_recv_counter;
};

#endif // ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_H_

