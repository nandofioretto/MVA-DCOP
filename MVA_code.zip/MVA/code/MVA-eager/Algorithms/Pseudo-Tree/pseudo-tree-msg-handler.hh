#ifndef ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_MSG_HANDLER_H_

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"

#include <memory>

class Agent;
class Message;
class PseudoTreeMsg;


// The message handler associated to messages of type: PSEUDO-TREE
class PseudoTreeMsgHandler : public MessageHandler
{
public:
  typedef std::unique_ptr<PseudoTreeMsgHandler> uptr;
  typedef std::shared_ptr<PseudoTreeMsgHandler> sptr;  

  PseudoTreeMsgHandler(Agent& a);

  virtual ~PseudoTreeMsgHandler();
  
  // It saves the newer PSEUDO-TREE message found into the agent inbox
  // into the local p_received, and it process it:
  virtual void processIncoming();

  // It prepare the outgoing message, based on the information 
  // collected from the last received message.
  virtual void prepareOutgoing();

  // It sends the outgoing message to the agent with id the one
  // given as a parameter.
  virtual void send(oid_t dest_id);

  // It returns the outgoing message
  PseudoTreeMsg& outgoing() const
  {
    ASSERT( p_outgoing, "Outgoing message was not allocated");
    return *p_outgoing;
  }

  // It returns the next incoming message of type "PSEUDO-TREE"
  PseudoTreeMsg& received() const
  {
    ASSERT( p_received, "Received message was not allocated");
    return *p_received;
  }
  

private:
  // The message received and processed.
  std::shared_ptr<PseudoTreeMsg> p_received;

  // The outgoing message
  std::unique_ptr<PseudoTreeMsg> p_outgoing;

};

#endif // ULYSSES_ALGORITHMS__PSEUDO_TREE__PSEUDO_TREE_MSG_HANDLER_H_
