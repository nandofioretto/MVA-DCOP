#include "Algorithms/Pseudo-Tree/pseudo-tree-construction.hh"
#include "Algorithms/Pseudo-Tree/pseudo-tree-msg.hh"
#include "Algorithms/Pseudo-Tree/pseudo-tree-msg-handler.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Agents/agent-factory.hh"
#include "Communication/mailbox.hh"
#include "Communication/scheduler.hh"

#include <algorithm>

using namespace std;

bool orderAsc(oid_t LHS, oid_t RHS) { return LHS > RHS; }
bool orderDesc(oid_t LHS, oid_t RHS) { return LHS < RHS; }

bool orderAscPSA(oid_t LHS, oid_t RHS) 
{ 
  return (g_dcop->stdModelAgentId(LHS) == g_dcop->stdModelAgentId(RHS) 
          && LHS > RHS);
}

bool orderDescPSA(oid_t LHS, oid_t RHS) 
{ 
  return (g_dcop->stdModelAgentId(LHS) != g_dcop->stdModelAgentId(RHS) 
          || LHS < RHS);
}


PseudoTreeConstruction::PseudoTreeConstruction(Agent& owner)
  : Algorithm(owner), p_visited(false), 
    p_recv_counter(0), p_elected_root(0)
{ 
  p_tree_node = shared_ptr<PseudoTreeOrdering>
    (new PseudoTreeOrdering(owner));
  p_msg_handler = shared_ptr<PseudoTreeMsgHandler>
    (new PseudoTreeMsgHandler(owner));
}


PseudoTreeConstruction::~PseudoTreeConstruction() 
{  }


// It register messages and message handler
void PseudoTreeConstruction::initialize()
{  
  attachMailSystem("PSEUDO-TREE", p_msg_handler);
}


void PseudoTreeConstruction::finalize()
{
  // Save the ordering created in this node 
  owner().setOrdering(p_tree_node);
  p_tree_node.reset();		// the only owner is now the agent.

  detachMailSystem("PSEUDO-TREE");
  p_msg_handler.reset();
  // Sequential Hack:
  // Reschedule the agent running this algorithm to let the 
  // calling routine to continue.
  Scheduler::FIFOinsert(owner().id());
}


bool PseudoTreeConstruction::canRun()
{
  return ( ! terminated() and 
	   (owner().id() == p_elected_root or
	    ! owner().openMailbox().isEmpty("PSEUDO-TREE")));
}


void PseudoTreeConstruction::run()
{
  PseudoTreeMsgHandler& handler = *p_msg_handler;

  // Receives the incoming message, if applicable
  handler.processIncoming();

  
  if (not p_visited)		// First visit to this node
  {
    oid_t parent_id = Constants::nullid;
    if(owner().id() != p_elected_root)
    {
      PseudoTreeMsg& recv = handler.received();
      p_recv_counter++;
      parent_id = recv.source();
    }

    // Prepare the outgoing message
    handler.prepareOutgoing(); 
    
    // Save parent and ancestor if this is not a root node
    if (parent_id != Constants::nullid)
    {
      PseudoTreeMsg& recv = handler.received();
      p_tree_node->setParent( parent_id );
      for (oid_t ancestor_id : recv.ancestors()){
	      p_tree_node->addAncestor( ancestor_id );        
      }
      recv.reset();
    }


    // use heuristic to order negibours:
    // Has the effect of pushing nodes into the scheduler, from the 
    // smaller to the bigger.
    std::vector<oid_t> N = owner().neighbours();
    std::sort(N.begin(), N.end(), orderDescPSA);

    // Save all neighbours, apart parent, as children,
    // and send the outgoing message to each one of those.
    for (oid_t dest_id : N)
    {
      if (dest_id != parent_id) {
        p_tree_node->addChild( dest_id );
      }
      handler.send( dest_id );
    }
    p_visited = true;
  }
  else	// Node already visited
  {
    // If already visited, update the relationship sets and return. 
    p_recv_counter++;
    PseudoTreeMsg& recv = handler.received();
    PseudoTreeMsg& sent = handler.outgoing();
    oid_t src_id = recv.source();

    // This node was reached by a descendand.
    // The src node is a pseudo-children of this node if its time-stamp is
    // greater than that of this node-1. As at the beginning it was set as a
    // children of this node, move it into the pseudo-children set.
    if (recv.stamp() > (sent.stamp()+1))
    {
      p_tree_node->removeChild( src_id );
      p_tree_node->addPseudoChild( src_id );
    }
    // The src node is a pseudo-parent of this node if its time-stamp is less 
    // than that of the current node. 
    else if ((recv.stamp()+1) < sent.stamp())
    {
      p_tree_node->removeChild( src_id );
      p_tree_node->addPseudoParent( src_id );
    }
    recv.reset();
  }

  if (terminated()) finalize();
}


