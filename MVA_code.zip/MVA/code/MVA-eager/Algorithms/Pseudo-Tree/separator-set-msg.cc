#include "Algorithms/Pseudo-Tree/separator-set-msg.hh"
#include "Kernel/Agents/agent-factory.hh"
#include "Kernel/Agents/agent.hh"

#include <iostream>
#include <string>

using namespace std;


SeparatorSetMsg::SeparatorSetMsg()
{ }


SeparatorSetMsg::~SeparatorSetMsg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
SeparatorSetMsg::SeparatorSetMsg(const SeparatorSetMsg& other)
  : Message(other)
{
  p_separator = other.p_separator;
}


bool SeparatorSetMsg::operator==(const SeparatorSetMsg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


SeparatorSetMsg* SeparatorSetMsg::clone()
{
  return new SeparatorSetMsg(*this);
}


string SeparatorSetMsg::dump() const
{
  string result = type() + Message::dump();
  result+="\t   sep: ";
  for (size_t i : p_separator)
    result += to_string(i) + " ";
  return result;
}
