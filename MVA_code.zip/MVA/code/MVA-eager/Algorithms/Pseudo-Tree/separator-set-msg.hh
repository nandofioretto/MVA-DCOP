#ifndef ULYSSES_ALGORITHMS__ORDERINGS__SEPARATOR_SET_MSG_H_
#define ULYSSES_ALGORITHMS__ORDERINGS__SEPARATOR_SET_MSG_H_

#include <set>
#include <string>

#include "Communication/message.hh"
#include "Kernel/globals.hh"

class SeparatorSetMsg : public Message
{
public:
  typedef std::unique_ptr<SeparatorSetMsg> uptr;
  typedef std::shared_ptr<SeparatorSetMsg> sptr;  
  
  SeparatorSetMsg();

  virtual ~SeparatorSetMsg();

  // It creates a copy of this message. 
  virtual SeparatorSetMsg* clone();

  // Check for equality of two messages.
  bool operator==(const SeparatorSetMsg& other);

  // It returns the message type.
  virtual std::string type() const
  {
    return "SEPARATOR-SET";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;

  // It adds the separators id given as a parameter into the separator set
  // carried by this message.
  void setSeparator(std::set<oid_t> a_ids)
  {
    p_separator = a_ids;
  }

  // It returns the set of agent's id in the separator set carried by this
  // message. 
  std::set<oid_t>& separator()
  {
    return p_separator;
  }
  
  
protected:
  DISALLOW_COPY_AND_ASSIGN(SeparatorSetMsg);
  
  
private:
  // The separator set of carried by this message
  std::set<oid_t> p_separator;

};

#endif // ULYSSES_ALGORITHMS__ORDERINGS__SEPARATOR_SET_MSG_H_
