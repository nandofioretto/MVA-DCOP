#include "Algorithms/Pseudo-Tree/pseudo-tree-msg-handler.hh"
#include "Algorithms/Pseudo-Tree/pseudo-tree-msg.hh"
#include "Communication/message.hh"
#include "Communication/scheduler.hh"
#include "Communication/mailbox.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"

#include <iostream>
#include <memory>

using namespace std;

PseudoTreeMsgHandler::PseudoTreeMsgHandler(Agent& a) 
  : MessageHandler(a), p_received(nullptr)
{ 
  p_outgoing = unique_ptr<PseudoTreeMsg>(new PseudoTreeMsg);
}


PseudoTreeMsgHandler::~PseudoTreeMsgHandler()
{ }


void PseudoTreeMsgHandler::processIncoming()
{
  if (owner().openMailbox().isEmpty("PSEUDO-TREE")) {
    p_received = nullptr;
  }
  else {
    p_received = std::move(dynamic_pointer_cast<PseudoTreeMsg>
			  (owner().openMailbox().readNext("PSEUDO-TREE")));
  }
}


void PseudoTreeMsgHandler::prepareOutgoing()
{  
  size_t stamp = (p_received) ? p_received->stamp() + 1 : 0;
  
  p_outgoing->setStamp(stamp);
  p_outgoing->setSource(owner().id());

  // Set ancestors
  p_outgoing->addAncestor(owner().id());
  if (p_received)
    p_outgoing->addAncestor(p_received->ancestors());
}

 
void PseudoTreeMsgHandler::send(oid_t dest_id)
{
  ASSERT(dest_id != Constants::nullid, 
	 "Trying to send a message with empty scheduler.");

  shared_ptr<PseudoTreeMsg> to_send(p_outgoing->clone()); 
  to_send->setDestination(dest_id);

  // It also schedule the next agent.
  owner().openMailbox().send(to_send);

  // Schedule next agent in a LIFO order
  Scheduler::LIFOinsert(to_send->destination());
}
