#include "Algorithms/AFB/fb_estimate-msg-handler.hh"
#include "Algorithms/AFB/time-stamp-cpa.hh"
#include "Communication/scheduler.hh"
#include "Kernel/Agents/agent.hh"
#include "Utilities/utils.hh"
#include "Utilities/statistics.hh"

#include <memory>
#include <vector>


FBESTIMATE_MsgHandler::FBESTIMATE_MsgHandler(Agent& a)
  : MessageHandler(a), p_estimate(0)
{ 
  // Create an outgoing message.
  p_outgoing = std::unique_ptr<FBESTIMATE_Msg>(new FBESTIMATE_Msg);
}

FBESTIMATE_MsgHandler::~FBESTIMATE_MsgHandler()
{ }


void FBESTIMATE_MsgHandler::initialize(std::shared_ptr<TimeStampCPA> ts)
{ 
  p_outgoing->setSource(owner().id());
  p_outgoing->timeStamp() = *ts;
  p_local_time_stamp = ts;
}


bool FBESTIMATE_MsgHandler::recvNewMsg()
{
  p_received = nullptr;
  while(!p_received)
  {
    processIncoming();
    if (!p_received) return false; // mailbox is empty

    // std::cout << p_received->dump() << "\n";
    // std::cout << "recv-t: " << p_received->timeStamp().dump() << " vs local-t: "
    //           << p_local_time_stamp->dump() << "\n";
    
    TimeStampCPA::cmp_t cmp = p_received->timeStamp().compare(*p_local_time_stamp);
   
    if (cmp == TimeStampCPA::kNewer) {
      p_local_time_stamp->assign(p_received->timeStamp());
      // std::cout <<"local time stamp updated: " << p_local_time_stamp->dump();
    }
    else if (cmp == TimeStampCPA::kOlder) {
      // std::cout <<"msg discarded\n";
      p_received = nullptr;      
    }
  }  
  return true;
}


void FBESTIMATE_MsgHandler::processIncoming()
{
  if (owner().openMailbox().isEmpty("FB_ESTIMATE"))
    p_received = nullptr;
  else 
    p_received = 
      std::dynamic_pointer_cast<FBESTIMATE_Msg>(owner().openMailbox().readNext("FB_ESTIMATE"));
}


  // It should never be called by the algorithm.
void FBESTIMATE_MsgHandler::send(oid_t dest_id)
{
  std::shared_ptr<FBESTIMATE_Msg> to_send(p_outgoing->clone());
  to_send->setDestination(dest_id);
  to_send->setEstimate( p_estimate );
  to_send->setTimeStamp(*p_local_time_stamp);

  owner().openMailbox().send(to_send);
  Scheduler::FIFOinsert(to_send->destination());
}
