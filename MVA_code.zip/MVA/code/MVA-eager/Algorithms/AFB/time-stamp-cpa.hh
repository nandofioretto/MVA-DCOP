#ifndef ULYSSES_ALGORITHMS__AFB__TIME_STAMP_CPA_H_
#define ULYSSES_ALGORITHMS__AFB__TIME_STAMP_CPA_H_

#include "Kernel/globals.hh"
#include "Utilities/utils.hh"
#include "Problem/dcop-instance.hh"

class TimeStampCPA
{
public:
  typedef std::unique_ptr<TimeStampCPA> uptr;
  typedef std::shared_ptr<TimeStampCPA> sptr;
  enum cmp_t{kOlder=-1, kEqual=0, kNewer=1};
    
  TimeStampCPA()
    : p_just_assigned(false)
  { }

  TimeStampCPA(size_t size) 
    : p_size(size), p_just_assigned(false)
  { p_cpa_counter.resize(g_dcop->nbAgents(), 0); }

  TimeStampCPA(const TimeStampCPA& other)
  {
    p_size = other.p_size;
    p_cpa_counter = other.p_cpa_counter;
  }

  ~TimeStampCPA()
  { }

  // It returns the i-th element of the cpa_counter, that is the assignment 
  // counter of the i-th agent in the linear ordering.
  size_t& operator[](int i)
  { return p_cpa_counter[ i ]; }

  size_t operator[](int i) const
  { return p_cpa_counter[ i ]; }

  // Returns a copy of the other timestamp given as a parameter.
  TimeStampCPA& operator=(const TimeStampCPA& other)
  {
    if(this != &other) {
      p_size = other.size();
      p_cpa_counter = other.p_cpa_counter;
    }
    return *this;
  }
 
  // It assigns the content of object given as a parameter up to the minimum 
  // size between this object and the other.
  // It does not update the current size.
  void assign(const TimeStampCPA& other)
  {
    for(int i=0; i<std::max(p_size, other.size()); ++i)
      p_cpa_counter[ i ] = other[ i ];
    p_just_assigned = true;
  }
  
  bool justAssigned() const
  { return p_just_assigned; }
 
  // Increments the i-th element of the time stamp.
  void incrAt(int i)
  { ++p_cpa_counter[ i ]; p_just_assigned = false; }
  
  // Sets to zero the i-th element of the time stamp. 
  void reset(int i)
  { p_cpa_counter[ i ] = 0; p_just_assigned = false; }

  // Sets to zero each (relevant) element of the cpa counter to 0.
  void reset()
  { std::fill_n(p_cpa_counter.begin(), p_size, 0); p_just_assigned = false; }
  
  // It returns the p_cpa_counter
  std::vector<size_t> CPAcounter() const
  { return p_cpa_counter; }

  // It compares the current time stamp with the one given as a parameter, by
  // performing a lex_compare between the two objects up to the smallest size.
  // @Return: -1 if the current time stamp is older than the other,
  //           1 if the current time stamp is newer than the other,
  //           0 if they are equal.
  cmp_t compare(const TimeStampCPA& other) const
  {
    for (int i = 0; i < std::min(p_size, other.size()); ++i) {
      if(other[ i ] > p_cpa_counter[ i ])
	      return kOlder;
      else if(other[ i ] < p_cpa_counter[ i ])
        return kNewer;
    }
    return kEqual;  
  }

  // Returns the cpa counter actual size.
  size_t size() const
  { return p_size; }


  std::string dump() const
  {
    std::string res = "[";
    for(int i=0; i<p_cpa_counter.size(); ++i) {
      res += std::to_string(p_cpa_counter[ i ]);
      if(i==(p_size-1)) res += "] ";
      else res += " ";
    }
    return res;
  }

private:
  // A counter 
  std::vector<size_t> p_cpa_counter;

  // It indicates the number of assignments made by the chain of agents
  // traversed so far. The timestamp need to be checked untill this point.
  size_t p_size;
  
  // Signal whether the timestamp has been just updated with an assign 
  // operation.
  bool p_just_assigned;
};

#endif // ULYSSES_ALGORITHMS__AFB__TIME_STAMP_CPA_H_
