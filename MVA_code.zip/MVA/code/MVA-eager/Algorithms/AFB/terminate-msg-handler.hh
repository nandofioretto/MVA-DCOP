#ifndef ULYSSES_ALGORITHMS__AFB__TERMINATE_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__AFB__TERMINATE_MSG_HANDLER_H_

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"
#include "Kernel/Agents/agent.hh"

#include <memory>

class TERMINATE_Msg;
class Agent;

class TERMINATE_MsgHandler : public MessageHandler
{
public: 
  typedef std::unique_ptr<TERMINATE_MsgHandler> uptr;
  typedef std::shared_ptr<TERMINATE_MsgHandler> sptr;
  
  TERMINATE_MsgHandler(Agent& a);

  ~TERMINATE_MsgHandler();

  // It prepare the outgoing message, which is the current solution found.
  virtual void prepareOutgoing()
  { 
    ASSERT(false, "Disallowed!"); 
  }

  // It process the message of type TERMINATE read from the inbox. 
  virtual void processIncoming();

  // Should not be called.
  virtual void send(oid_t dest_id)
  { 
    ASSERT(false, "Disallowed!"); 
  }

  // It broadcasts the outgoing message to all agents of the DCOP, except 
  // the one running this algorithm
  void broadcast();

  // Returns true if there is at least a new message of type CPA in the agent's 
  // mailbox.
  bool recvNewMsg() const
  {
    return !owner().openMailbox().isEmpty("TERMINATE");
  }
 
private:
  // The messages received, and saved here as a store.
  std::shared_ptr<TERMINATE_Msg> p_received;

  // The outgoing message
  std::unique_ptr<TERMINATE_Msg> p_outgoing;

};


#endif // ULYSSES_ALGORITHMS__AFB__TERMINATE_MSG_HANDLER_H_
