#include "Algorithms/AFB/fb_estimate-msg.hh"

FBESTIMATE_Msg::FBESTIMATE_Msg()
{ }


FBESTIMATE_Msg::~FBESTIMATE_Msg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
FBESTIMATE_Msg::FBESTIMATE_Msg(const FBESTIMATE_Msg& other)
  : Message(other)
{
  p_estimate = other.p_estimate;
  p_time_stamp = other.p_time_stamp;
}



bool FBESTIMATE_Msg::operator==(const FBESTIMATE_Msg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


FBESTIMATE_Msg* FBESTIMATE_Msg::clone()
{
  return new FBESTIMATE_Msg(*this);
}


std::string FBESTIMATE_Msg::dump() const
{
  std::string result = Message::dump();
  result += " | estimate: " + std::to_string(p_estimate) + "|";
  return result;
}
