#ifndef ULYSSES_ALGORITHMS__AFB__NEW_SOLUTION_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__AFB__NEW_SOLUTION_MSG_HANDLER_H_

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"
#include "Algorithms/AFB/new_solution-msg.hh"
#include <memory>

class Agent;
class Solution;

class NEWSOLUTION_MsgHandler : public MessageHandler
{
public: 
  typedef std::unique_ptr<NEWSOLUTION_MsgHandler> uptr;
  typedef std::shared_ptr<NEWSOLUTION_MsgHandler> sptr;
  
  NEWSOLUTION_MsgHandler(Agent& a);

  ~NEWSOLUTION_MsgHandler();

  // It prepare the outgoing message, which is the current solution found.
  virtual void prepareOutgoing()
  { 
    ASSERT(false, "Disallowed!"); 
  }

  // It process the message of type NEWSOLUTION read from the inbox. 
  // It saves the messages in a local storage to be process at needed.
  virtual void processIncoming();

  // Should not be called
  virtual void send(oid_t dest_id)
  { 
    ASSERT(false, "Disallowed!"); 
  }

  // It sets the pointers to the local CPA.
  virtual void initialize(std::shared_ptr<Solution> cpa);

  // It checks if there is at least a new message of type NEW_SOLUTION in
  // the agent's mailbox. If true, it saves it into the p_received store.
  bool recvNewMsg()
  {
    processIncoming();
    return (p_received != nullptr);
  }

  // It broadcasts the outgoing message to all agents of the DCOP, except 
  // the one running this algorithm
  void broadcast();

  // Saves the solution given as a parameter into the outgoing message. 
  void saveSolution(Solution& sol)
  {
    p_outgoing->saveSolution( sol );
  }

  Solution& solution()
  {
    return p_received->solution();
  }
  
private:
  // The messages received, and saved here as a store.
  std::shared_ptr<NEWSOLUTION_Msg> p_received;

  // The outgoing message
  std::unique_ptr<NEWSOLUTION_Msg> p_outgoing;

  // A pointer to CPA stored in the AFB object, which will be attached to the 
  // new otgoing messages.
  std::shared_ptr<Solution> p_local_CPA;
};


#endif // ULYSSES_ALGORITHMS__AFB__NEW_SOLUTION_MSG_HANDLER_H_
