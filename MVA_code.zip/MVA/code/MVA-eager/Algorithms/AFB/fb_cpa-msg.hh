#ifndef ULYSSES_ALGORITHMS__AFB__FB_CPA_MSG_H_
#define ULYSSES_ALGORITHMS__AFB__FB_CPA_MSG_H_

#include <string>
#include "Algorithms/AFB/cpa-msg.hh"

// The FB_CPA message of Asynchronous Forward-Bounding.
// It is a temporary CPA message which an agent a_i sends to agents a_j (j > i).
// It is used to collect the cost estimations of agent a_j with the
// new CPA.
class FBCPA_Msg : public CPA_Msg
{ 
public:
  typedef std::unique_ptr<FBCPA_Msg> uptr;
  typedef std::shared_ptr<FBCPA_Msg> sptr;
  
  FBCPA_Msg();

  virtual ~FBCPA_Msg();

  // Check equality of two messages.
  bool operator==(const FBCPA_Msg& other);

  // It creates a copy of this message. 
  virtual FBCPA_Msg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "FB_CPA";
  }

  // It resets the message content (without affecting the message header).
  virtual void reset()
  { }

protected:
  DISALLOW_COPY_AND_ASSIGN(FBCPA_Msg);
  
private:
};

#endif // ULYSSES_ALGORITHMS__AFB__FB_CPA_MSG_H_
