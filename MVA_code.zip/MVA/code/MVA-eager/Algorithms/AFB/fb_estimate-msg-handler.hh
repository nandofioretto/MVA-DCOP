#ifndef ULYSSES_ALGORITHMS__AFB__FB_ESTIMATE_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__AFB__FB_ESTIMATE_MSG_HANDLER_H_

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"
#include "Algorithms/AFB/fb_estimate-msg.hh"

#include <memory>
#include <vector>

class Agent;
class TimeStampCPA;

// The message handler associated to messages of type: FB_ESTIMATE 
class FBESTIMATE_MsgHandler : public MessageHandler
{
public:
  typedef std::unique_ptr<FBESTIMATE_MsgHandler> uptr;
  typedef std::shared_ptr<FBESTIMATE_MsgHandler> sptr;

  FBESTIMATE_MsgHandler(Agent& a);

  virtual ~FBESTIMATE_MsgHandler();
  
  // It downloads all the messages of type FB_ESTIMATE from the inbox of the
  // associated agent.
  virtual void processIncoming();

  // It prepare the outgoing message, based on the information 
  // collected from the received messages and the agent search.
  virtual void prepareOutgoing()
  { 
    ASSERT(false, "Disallowed!"); 
  }

  // It sets the estimate cost given as a paramter.
  void prepareOutgoing(cost_t estimate)
  {
    p_estimate = estimate; 
  }

  // It should never be called by the algorithm.
  virtual void send(oid_t dest_id);

  // It intializes the ESTIMATE variables, the internal data structures
  // used to compute the cost estimate, and sets the time stamp link.
  void initialize(std::shared_ptr<TimeStampCPA> ts);

  // It returns the cost estimate.
  cost_t recvEstimate() const
  {
    ASSERT(p_received, "No message in the inbox could be read.");
    return p_received->estimate();
    //return p_estimate;
  }
 
  // It checks if there is at least a new message of type FB_ESTIMATE in the 
  // agent's mailbox. If true, it saves it into the p_received store, and it 
  // updates the local time stamp. 
  bool recvNewMsg();


private:
  // The message received.
  std::shared_ptr<FBESTIMATE_Msg> p_received;

  // The outgoing message
  std::unique_ptr<FBESTIMATE_Msg> p_outgoing;

  // The cost estimate to be copied in the message to send.
  cost_t p_estimate;

  // A pointer to the local timestamp held by this agent.
  std::shared_ptr<TimeStampCPA> p_local_time_stamp;

};

#endif // ULYSSES_ALGORITHMS__AFB__FB_ESTIMATE_MSG_HANDLER_H_
