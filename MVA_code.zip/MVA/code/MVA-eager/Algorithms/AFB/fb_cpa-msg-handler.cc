#include "Algorithms/AFB/fb_cpa-msg-handler.hh"
#include "Algorithms/AFB/fb_cpa-msg.hh"
#include "Algorithms/AFB/time-stamp-cpa.hh"
#include "Algorithms/Orderings/linear-ordering.hh" 
#include "Communication/scheduler.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "SearchEngines/solution.hh"
#include "Utilities/statistics.hh"
#include "Utilities/utils.hh"
#include "Utilities/Statistics/local-statistics.hh"

#include <string>

using namespace std;

FBCPA_MsgHandler::FBCPA_MsgHandler(Agent& a)
  : MessageHandler(a), p_received(nullptr), p_outgoing(nullptr)
{ 
  p_outgoing = std::unique_ptr<FBCPA_Msg>(new FBCPA_Msg);
  p_query = new int[10];
}


FBCPA_MsgHandler::~FBCPA_MsgHandler()
{ 
  delete[] p_query;
}


void FBCPA_MsgHandler::initialize(std::shared_ptr<Solution> cpa, std::shared_ptr<TimeStampCPA> ts)
{
  p_local_CPA = cpa;
  p_local_time_stamp = ts;

  // Create an p_outgoing message.
  p_outgoing->setSource(owner().id());
  p_outgoing->timeStamp() = *ts;

  LinearOrdering& order = dynamic_cast<LinearOrdering&>(owner().ordering());

  // This bit is done only by the agents which can receive a FB_CPA message,
  // that is, all agents aj with j > 0.
  if(!order.head()) 
  {
    int nb_pred = order.position();
    // For each j=0...i-1, CPAvariables_[ j ] is the ordered list of variables' 
    // id carried by the CPA message. 
    std::vector<std::vector<oid_t> > CPA_variables( nb_pred );
    CPA_variables[ 0 ] = g_dcop->agent(0).localVariableIDs();
    for (oid_t j = 1; j < nb_pred; ++j)
    {
      Agent& aj = g_dcop->agent(j);
      CPA_variables[ j ] = 
        Utils::concat(CPA_variables[ j-1 ], aj.localVariableIDs());
    }

    // For each j < i, shared_constraints[ j ] contains the list
    // of constraints shared between all agents a_j, with j < i, and a_i.
    std::vector< std::vector<oid_t> > shared_constraints;

    // Initializes the shared_constraints
    shared_constraints.resize( nb_pred );
    shared_constraints[ 0 ] = 
      Utils::intersect(owner().interAgentConstraintIDs(),
    g_dcop->agent(0).interAgentConstraintIDs()); 
    // remove all constraints whose scope contains variables owned by 
    // some agent with id > ai:
    for (oid_t cid : shared_constraints[ 0 ])
    {
      for(oid_t vid : g_dcop->constraint(cid).scopeIds())
        if (g_dcop->variable(vid).ownerId() > owner().id())
          Utils::findAndRemove(cid, shared_constraints[ 0 ]);
    }
    
    // std::cout << owner().name() << ": shared constraints [0] :"
    // 	      << Utils::dump(shared_constraints[ 0 ]) << endl;

    for (oid_t j = 1; j < nb_pred; ++j)
    {
      Agent& aj = g_dcop->agent(j);
      shared_constraints[ j ] = 
        Utils::intersect( Utils::merge( shared_constraints[ j-1 ], aj.interAgentConstraintIDs() ),
      owner().interAgentConstraintIDs() );

      // remove all constraints whose scope contains variables owned by 
      // some agent with id > ai:
      for (oid_t cid : shared_constraints[ j ])
      {
        for(oid_t vid : g_dcop->constraint(cid).scopeIds())
          if (g_dcop->variable(vid).ownerId() > owner().id())
            Utils::findAndRemove(cid, shared_constraints[ j ]);
      }
      
      // std::cout << owner().name() <<  ": shared constraints [" << j << "] :"
      // 	      << Utils::dump(shared_constraints[ j ]) << '\n';
    }

    // Initializes the p_shared_constraints_unit
    p_shared_constraints_unit.resize(nb_pred); // tight lower bounds
    for (oid_t j=0; j < nb_pred; ++j)
    {
      Agent& aj = g_dcop->agent( j );

      for (oid_t cid : shared_constraints[ j ])
      {
        // std::cout << "checking constraint id " << cid << std::endl;
        // std::cout << "c" << cid << "_ scope: " << Utils::dump(ConstraintFactory::get(cid).scopeIds())
        // 	  << " \\ CPA vars: " << Utils::dump(CPA_variables[ j ]) << " = ";

        vector<oid_t> set = 
          Utils::exclude(CPA_variables[ j ], g_dcop->constraint(cid).scopeIds());

        // std::cout << Utils::dump(set) << std::endl;

        if (set.size() == 1 and 
          g_dcop->variable(set[0]).ownerId() == owner().id()) 
        {
          int scope_idx = Utils::findIdx(g_dcop->constraint(cid).scopeIds(), set[0]);
          p_shared_constraints_unit[ j ].push_back(std::make_pair(cid, scope_idx));
        }
      }

      // std::cout << owner().name() << "constraint_unit[" << j << "]: "
      // 		<< Utils::dump(p_shared_constraints_unit[ j ]) << std::endl;
    }

    // Compute the partial estimate: 
    // The lower bound for all the intra-agent constraints 
    cost_t int_lb = 0;
    for(oid_t cid : owner().intraAgentConstraintIDs())
    {
      ExtSoftConstraint* esc =
        dynamic_cast<ExtSoftConstraint*>(&(g_dcop->constraint(cid)));
      int_lb += esc->bestCost();
    }

    p_loose_lowerbounds.resize(nb_pred, int_lb);

    // For each receiver, the lower bound of all the constraints whose scope is 
    // not covered by the CPA --- not able to compute a tighter bound. 
    for (int j=0; j<nb_pred; ++j)
    {
      std::vector<oid_t> cons = Utils::extractFirst(p_shared_constraints_unit[ j ]);
      for(oid_t cid : Utils::exclude(cons, shared_constraints[ nb_pred-1 ]))
      {
        ExtSoftConstraint* esc =
          dynamic_cast<ExtSoftConstraint*>(&(g_dcop->constraint(cid)));
        p_loose_lowerbounds[ j ] += esc->bestCost();
      }
      // std::cout << "loose_lb[" << j << "]: " << p_loose_lowerbounds[ j ] <<std::endl;
    }


    // Initializes the lower bounds
#ifdef OPTIMIZE_LATER
    computeBounds();


    // Initializes the precom_estimate_:
    // The precom_estimate_ for a given agent variable, sums up the lower bounds
    // for all the constraints involving such variables and any other local 
    // variable or variables already assigned in the CPA.
    // 
    // The following allows to compute a tighter lower bound for the constraints 
    // involving the boundary variables of current agent, which participate in some
    // constraints involving such variable and exclusively variables owned by higher
    // precedence agents.
    // It considers only the *intra-agent* constraints. Namely, those sharing a 
    // boundary variable which include the above.
    // (a) For simplicity, only binary constraints are considered.
    // (b) The constraints are processed in order, so to avoid duplicate constraint 
    // costs, when for example boundary variables share constraints with ancestor 
    // agents, as well as among them.
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    // how about unary constraints?
    // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    precomp_estimate_.resize( p_shared_constraints_unit.size() );

    for (oid_t aj=0; aj < nb_pred; ++aj)
    {
      for (std::pair<oid_t, int> p : p_shared_constraints_unit[ aj ])
      {
        oid_t cid = p.first; 
        int vidx  = p.second;
        IntVariable& var = g_dcop->constraint(cid).variableAt( vidx );

        // Remove cid from constraint to check (b).
        Utils::findAndRemove(cid, constraint_to_check_);
	
        // Take all constraints in var:
        std::vector<oid_t> constr_of_var;
        for (int i = 0; i < var.nbConstraints(kExtSoft); ++i) 
        {
          ExtSoftConstraint& esc = var.extSoftConstraintAt(i);
          if(esc.arity() == 2) // (a)
            constr_of_var.push_back(var.extSoftConstraintAt(i));
        }
        Utils::intersect_emplace(constr_of_var, constraint_to_check_);
        Utils::intersect_emplace(constr_of_var, owner().intraAgentConstraintIDs());
      
        for (int val : var.domain().content())
        {
          cost_t partial_estimate = 0;
          for (oid_t id : constr_of_var)
            partial_estimate += p_lowerbound[ id ][ var.id() ][ val ];

          p_precomp_estimates[ aj ][ val ] = partial_estimate;
        }
      }
    }
#endif

  }// ai is not head
  
}



#ifdef OPTIMIZE_LATER
void FBCPA_MsgHandler::computeBounds()
{
  // An auxiliary vector storing the values to be checked in a constraint. 
  // It's size (10) is the current limit of the ext-soft constraint arity.
  int* tuple = new int[ 10 ];
  cost_t cost;

  // Scan all the constraints to check during the FB cost estimation, and
  // for each of these
  for (oid_t cid : p_constraints_to_check)
  {
    ExtSoftConstraint* esc =
      dynamic_cast<ExtSoftConstraint*>(&g_dcop->constraint(cid));

    // The local variables in the constraint scope:
    std::vector<oid_t> local_var_in_esc =
      Utils::intersect(esc->scopeIds(), owner().localVariableIDs());

    ASSERT(!local_var_in_esc.empty(), "Error in computing bounds");

    // For this particular constraint and for each value in the domain of the 
    // current variable, search the lower bound associated to 'esc' when the
    // current variable assumes a specific value.
    for (oid_t vid : local_var_in_esc)
    {
      IntVariable& var = g_dcop->variable(vid);

      for (int val : var.domain().content())
        p_lowerbound[ cid ][ vid ][ val ] = esc->worstCost();

      // The index of current variable in the constraint scope.
      int idx_var_in_esc = Utils::findIdx( esc->scopeIds(), vid );
      
      // Finds the lower bound for a given constraint, variable and value.
      esc->resetIterator();
      while (esc->next())
      {
        esc->getNext(tuple, cost);
        int val = tuple[ idx_var_in_esc ];
        p_lowerbound[ cid ][ vid ][ val ] = 
          Utils::bestBound(cost, p_lowerbound[ cid ][ vid ][ val ]);
      }
    }
  }
  delete[] tuple;
}
#endif


bool FBCPA_MsgHandler::recvNewMsg()
{
  p_received = nullptr;
  while(!p_received)
  {
    processIncoming();
    if (!p_received) return false; // mailbox is empty
    
    // std::cout << p_received->dump() << "\n";
    // std::cout << "recv-t: " << p_received->timeStamp().dump() << " vs local-t: "
    //           << p_local_time_stamp->dump() << "\n";
    
    TimeStampCPA::cmp_t cmp = p_received->timeStamp().compare(*p_local_time_stamp);
   
    if (cmp == TimeStampCPA::kNewer) {
      p_local_time_stamp->assign(p_received->timeStamp());
      // std::cout <<"local time stamp updated: " << p_local_time_stamp->dump();
    }
    else if (cmp == TimeStampCPA::kOlder) {
      // std::cout <<"msg discarded\n";
      p_received = nullptr;      
    }
  }
  return true;
}


void FBCPA_MsgHandler::processIncoming()
{
  if (owner().openMailbox().isEmpty("FB_CPA"))
    p_received = nullptr;
  else
    p_received = 
      dynamic_pointer_cast<FBCPA_Msg>(owner().openMailbox().readNext("FB_CPA"));
}


void FBCPA_MsgHandler::send(oid_t dest_id)
{
  shared_ptr<FBCPA_Msg> to_send(p_outgoing->clone());
  to_send->setDestination(dest_id);
  
  ASSERT( p_local_CPA, "No CPA was found when sending a CPA message");
  to_send->setPA( *p_local_CPA);
  to_send->setTimeStamp(*p_local_time_stamp);

  owner().openMailbox().send(to_send);
  Scheduler::FIFOinsert(to_send->destination());
}



cost_t FBCPA_MsgHandler::computeEstimate()
{
  ASSERT( p_received, "Error in computing FB Estimate - no FB_CPA message received");

  Solution& CPA = p_received->PA(); 
  oid_t aj = p_received->source();
  cost_t estimate = 0;

  for (std::pair<oid_t,int> p : p_shared_constraints_unit[ aj ])
  {
    ExtSoftConstraint* esc =
      dynamic_cast<ExtSoftConstraint*>(&g_dcop->constraint(p.first));

    int vidx = p.second;
    IntVariable& var = esc->variableAt(vidx);

    // Populate p_query from CPA
    for (oid_t i = 0; i < esc->arity(); ++i)
    {
      if( i == vidx) continue;
      
      //::::::::::::::::::::::::::::::::::::::::::
      // Note: this only works in the special condition in which all the agents
      // are processed in order of their id - all the variables are listed in 
      // order as their owner id.
      //::::::::::::::::::::::::::::::::::::::::::
      int idx =  esc->variableIdAt( i );
      p_query[ i ] = CPA[ idx ];
    }
    
    cost_t lb = Constants::worstvalue;
#ifdef OPTIMIZE_LATER
    int min_val = Constants::NaN;
#endif
    
    // get the lower bound on the constraint cost, s.t. scope(esc)|_vidx = v
    //for (int v = 0; v <= 2; ++v)
    for (int v = var.min(); v <= var.max(); ++v)
    {
      p_query[ vidx ] = v;

      cost_t cost = esc->getCost( p_query );
      
      // std::cout << "[" << p_query[0] << "," <<p_query[1]<< "] : " << cost << std::endl;    
      owner().statistics().incrNCCCs();

      if (Utils::isBetter(cost, lb))
      { 
        lb = cost; 
#ifdef OPTIMIZE_LATER
        min_val = v; 
#endif
      }
    }
    Utils::sum_emplace(estimate, lb);

#ifdef OPTIMIZE_LATER
    Utils::sum_emplace(estimate, p_precomp_estimates[ aj ][ min_val ]);    
#endif
  }
  Utils::sum_emplace(estimate, p_loose_lowerbounds[ aj ]);
   
  return estimate;
}
