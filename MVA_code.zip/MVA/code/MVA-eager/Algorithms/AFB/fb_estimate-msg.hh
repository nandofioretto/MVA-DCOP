#ifndef ULYSSES_ALGORITHMS__AFB__FB_ESTIMATE_MSG_H_
#define ULYSSES_ALGORITHMS__AFB__FB_ESTIMATE_MSG_H_

#include <string>

#include "Communication/message.hh"
#include "Algorithms/AFB/time-stamp-cpa.hh"


// The FB_ESTIMATE message of Asynchronous Forward-Bounding.
// The message which an agent a_i sends back to an agent a_j, (i > j)
// in response to a FB_CPA message, where it computes a local lower bound.
class FBESTIMATE_Msg : public Message
{
public:
  typedef std::unique_ptr<FBESTIMATE_Msg> uptr;
  typedef std::shared_ptr<FBESTIMATE_Msg> sptr;

  FBESTIMATE_Msg();

  virtual ~FBESTIMATE_Msg();

  // Check equality of two FB_ESTIMATE messages. It only checks message source and
  // destination.
  bool operator==(const FBESTIMATE_Msg& other);

  // It creates a copy of this message. 
  virtual FBESTIMATE_Msg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "FB_ESTIMATE";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;

  // It sets the estmiate cost as the one given as a parameter.
  void setEstimate(cost_t estimate)
  { 
    p_estimate = estimate; 
  }

  // It returns the cost estimate.
  cost_t estimate() const
  {
    return p_estimate;
  }

  // It sets the message time stamp as the one given as parameter.
  void setTimeStamp(TimeStampCPA& ts)
  {
    p_time_stamp.assign(ts);
  }

  // It returns the message time stamp.
  TimeStampCPA& timeStamp()
  {
    return p_time_stamp;
  }

protected:
  DISALLOW_COPY_AND_ASSIGN(FBESTIMATE_Msg);

private:
  // The current estimate (lower bound) of the cost incurred by the lowest
  // cost assignemnt to this agent's variables:
  // TO REVIEW THE PART BELOW:
  // sum of all f_{x_k} with x_k \in B_i
  // where f_{x_k} = min_v \in D_k (constr recv-agent, this agent) + H(v)
  cost_t p_estimate;

  // The vector of running assignment counters which were passed through all 
  // the agents a1...a{i}
  TimeStampCPA p_time_stamp;
};

#endif // ULYSSES_ALGORITHMS__AFB__FB_ESTIMATE_MSG_H_
