#include "Algorithms/AFB/terminate-msg.hh"

TERMINATE_Msg::TERMINATE_Msg()
{ }


TERMINATE_Msg::~TERMINATE_Msg()
{ }

TERMINATE_Msg::TERMINATE_Msg(const TERMINATE_Msg& other)
  : Message(other)
{ }


TERMINATE_Msg* TERMINATE_Msg::clone()
{
  return new TERMINATE_Msg(*this);
}


std::string TERMINATE_Msg::dump() const
{
  std::string result = Message::dump();
  return result;
}
