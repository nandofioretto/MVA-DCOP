#ifndef ULYSSES_ALGORITHMS__AFB__NEW_SOLUTION_MSG_H_
#define ULYSSES_ALGORITHMS__AFB__NEW_SOLUTION_MSG_H_

#include <string>

#include "Communication/message.hh"
#include "SearchEngines/solution.hh"



// The NEWSOLUTION message of Asynchronous Forward-Bounding.
// This message is broadcasted to every agent of the DCOP whenever a new 
// solution, with best bound has been found.
class NEWSOLUTION_Msg : public Message
{
public:
  typedef std::unique_ptr<NEWSOLUTION_Msg> uptr;
  typedef std::shared_ptr<NEWSOLUTION_Msg> sptr;
  
  NEWSOLUTION_Msg();

  virtual ~NEWSOLUTION_Msg();

  // Check equality of two Value messages. It only checks message source and
  // destination.
  bool operator==(const NEWSOLUTION_Msg& other);

  // It creates a copy of this message. 
  virtual NEWSOLUTION_Msg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "NEW-SOLUTION";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  void saveSolution(Solution& sol)
  {
    p_solution = sol;
  }

  Solution& solution()
  {
    return p_solution;
  }

  // It returns a message description.
  virtual std::string dump() const;


protected:
  DISALLOW_COPY_AND_ASSIGN(NEWSOLUTION_Msg);


private:
  // The current solution.
  Solution p_solution;
};

#endif // ULYSSES_ALGORITHMS__AFB__NEW_SOLUTION_MSG_H_
