#ifndef ULYSSES_ALGORITHMS__AFB__TERMINATE_MSG_H_
#define ULYSSES_ALGORITHMS__AFB__TERMINATE_MSG_H_

#include <string>

#include "Communication/message.hh"


// The TERMINATE message of Asynchronous Forward-Bounding.
// It signal that the algorithm has terminated.
class TERMINATE_Msg : public Message
{
public:
  typedef std::unique_ptr<TERMINATE_Msg> uptr;
  typedef std::shared_ptr<TERMINATE_Msg> sptr;
  
  TERMINATE_Msg();

   ~TERMINATE_Msg();

  // It creates a copy of this message. 
  virtual TERMINATE_Msg* clone();

  // It returns the message type.
  virtual std::string type() const
  {
    return "TERMINATE";
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;


protected:
  DISALLOW_COPY_AND_ASSIGN(TERMINATE_Msg);
};

#endif // ULYSSES_ALGORITHMS__AFB__TERMINATE_MSG_H_
