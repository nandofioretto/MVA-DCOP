#ifndef ULYSSES_ALGORITHMS__AFB__CPA_MSG_H_
#define ULYSSES_ALGORITHMS__AFB__CPA_MSG_H_

#include <string>
#include <vector>

#include "Communication/message.hh"
#include "Algorithms/AFB/time-stamp-cpa.hh"
#include "SearchEngines/solution.hh"

// The CPA message of Asynchronous Forward-Bounding.
// It is the is the current partial assignment, containing the assignments made 
// by agents a_1,...,a_i CPA message which agent a_i sends to agents a_j (j>i) 
class CPA_Msg : public Message
{
public:
  typedef std::unique_ptr<CPA_Msg> uptr;
  typedef std::shared_ptr<CPA_Msg> sptr;
  
  CPA_Msg();

  virtual ~CPA_Msg();

  // Check equality of two CPA messages. It only checks message source and
  // destination.
  bool operator==(const CPA_Msg& other);

  // It creates a copy of this message. 
  virtual CPA_Msg* clone();

  // It returns the message type.
  virtual std::string type() const
  { 
    return "CPA"; 
  }

  // It resets the message content (without affeting the message header).
  virtual void reset()
  { }

  // It returns a message description.
  virtual std::string dump() const;

  // It stores the relevant part of the CPA into the PA carried by this message.
  void setPA(const Solution& CPA)
  {
    p_PA = CPA;
  }

  // It returns the Partial Assignment stored in this message.
  Solution& PA()
  {
    return p_PA; 
  }

  // It sets the message time stamp as the one given as parameter.
  void setTimeStamp(TimeStampCPA& ts)
  {
    p_time_stamp.assign(ts);
  }

  // It returns the message time stamp.
  TimeStampCPA& timeStamp()
  {
    return p_time_stamp;
  }


protected:
  DISALLOW_COPY_AND_ASSIGN(CPA_Msg);

  // The current partial assignment, containing the assignments made by agents 
  // a_0,...,a_{i}. The vector has same size of the CPA for efficiency reasons.
  Solution p_PA;
   
  // The vector of running assignment counters which were passed through all 
  // the agents a1...a{i}
  TimeStampCPA p_time_stamp;
};

#endif // ULYSSES_ALGORITHMS__AFB__FB_CPA_MSG_H_
