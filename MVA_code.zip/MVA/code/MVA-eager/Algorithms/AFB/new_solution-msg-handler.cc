#include "Algorithms/AFB/new_solution-msg-handler.hh"
#include "Communication/scheduler.hh"
#include "Kernel/Agents/agent.hh"
#include "SearchEngines/solution.hh"
#include "Problem/dcop-instance.hh"
#include "Utilities/statistics.hh"


NEWSOLUTION_MsgHandler::NEWSOLUTION_MsgHandler(Agent& a)
  : MessageHandler(a), p_received(nullptr), p_outgoing(nullptr), 
    p_local_CPA(nullptr)
{
  p_outgoing = std::unique_ptr<NEWSOLUTION_Msg>(new NEWSOLUTION_Msg);
  p_outgoing->setSource(owner().id());
}

NEWSOLUTION_MsgHandler::~NEWSOLUTION_MsgHandler()
{ }


void NEWSOLUTION_MsgHandler::initialize(std::shared_ptr<Solution> cpa)
{
  p_local_CPA = cpa;
}


void NEWSOLUTION_MsgHandler::processIncoming()
{
  if (owner().openMailbox().isEmpty("NEW-SOLUTION")) 
    p_received = nullptr;
  else {
    p_received = std::move(std::dynamic_pointer_cast<NEWSOLUTION_Msg>
			  (owner().openMailbox().readNext("NEW-SOLUTION")));
    // std::cout << owner().name() << " NEWSOLUTION_MsgHandler::recv() "
    //         << p_received->dump() << std::endl;
  }
}


void NEWSOLUTION_MsgHandler::broadcast()
{
  for(Agent* a : g_dcop->agents())
  {
    if( a->id() == owner().id())
      continue;

    std::shared_ptr<NEWSOLUTION_Msg> to_send(p_outgoing->clone());
    to_send->setDestination(a->id());
    to_send->saveSolution(*p_local_CPA);

    // std::cout << owner().name() << " NEWSOLUTION_MsgHandler::broadcast() "
    //         << to_send->dump() << std::endl;
    owner().openMailbox().send(to_send);
    Scheduler::FIFOinsert(to_send->destination());
  }
 }
