#ifndef ULYSSES_ALGORITHMS__AFB__FB_CPA_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__AFB__FB_CPA_MSG_HANDLER_H_

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"
#include "Algorithms/AFB/fb_cpa-msg.hh"

#include <memory>
#include <vector>

class Agent;
class TimeStampCPA;
class Solution;

// The message handler associated to messages of type: FB_CPA
// When receiving an FB_CPA message it computes 
class FBCPA_MsgHandler : public MessageHandler
{
public:
  typedef std::unique_ptr<FBCPA_MsgHandler> uptr;
  typedef std::shared_ptr<FBCPA_MsgHandler> sptr;

  FBCPA_MsgHandler(Agent& a);

  virtual ~FBCPA_MsgHandler();
  
  // It downloads all the messages of type FB_CPA from the inbox of the
  // associated agent.
  virtual void processIncoming();

  // It prepare the p_outgoing message, based on the information 
  // collected from the received messages and the agent search.
  virtual void prepareOutgoing()
  { 
    ASSERT( false, "Should not be called");
  }

  // It should never be called by the algorithm.
  virtual void send(oid_t dest_id);

  // It returns the last FB_CPA message receoved.
  FBCPA_Msg& received()
  {
    ASSERT( p_received != nullptr, "No received message in this request");
    return *p_received;
  }

  // It intializes the CPA variables, and the internal data structures
  // used to compute the cost estimate; Sets the pointers to the local 
  // CPA and local time stamp.
  virtual void initialize(std::shared_ptr<Solution> cpa, 
			 std::shared_ptr<TimeStampCPA> ts);

  // It checks if there is at least a new message of type FB_CPA in the agent's 
  // mailbox. If true, it saves it into the p_received store, and it updates 
  // the local time stamp. 
  bool recvNewMsg();

  // Computes the cost estimate 
  cost_t computeEstimate();
 

private:
#ifdef OPTIMIZE_LATER
  // Computes the bounds to be used for the cost estimation. 
  void computeBounds(); // ok
#endif

  // The message received, and saved here as a store.
  // std::vector<std::shared_ptr<FBCPA_Msg> > p_received;
  /// Read one message at a time
  std::shared_ptr<FBCPA_Msg> p_received;

  // The p_outgoing message
  std::unique_ptr<FBCPA_Msg> p_outgoing;

  // A pointer to CPA stored in the AFB object, which will be attached to the new
  // otgoing messages.
  std::shared_ptr<Solution> p_local_CPA;

  // A pointer to the local timestamp held by this agent.
  std::shared_ptr<TimeStampCPA> p_local_time_stamp;

  // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
  // Auxiliary Data Structures used to compute the FB estimate
  // ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    
  // The list of constraints among the shared constraints, whose, at the 
  // moment of receiving the FB_CPA message are such that all variables in 
  // their scope, but one, are assigned (in the received CPA).
  // The non assigned variable is therefore owned by a_i.
  // This infomation is used to compute a tighter lower bound.
  std::vector<std::vector<std::pair<oid_t, int> > > p_shared_constraints_unit;

  // The sum of the lower bounds of all local constraints, and constraints 
  // with ancestor agents whose scope is not completely filled by the 
  // received CPA.  Each assocaited to one receiving agent.
  std::vector<cost_t> p_loose_lowerbounds;

#ifdef OPTIMIZE_LATER
  // The list of constraints that this agent uses to calculate the FB estimate.
  std::vector<oid_t> p_constraints_to_check;

  // Description here:
  // This is the set of all constraints whose bound can be tighten by setting a
  // value for a variable.   
  // p_precomp_estimates[ j ][ val ] = sum of best cost for all constraints in 
  // {c' : x \in scope(c) 
  //   \and c \in constr2check           // considering those removed iteratively in the process 
  //   \and c is binary
  //   \and c \in ai.intraAgentConstr}
  //
  // p_precomp_estimates[ j ] corresponds to p_shared_constraints_unit[ j ]
  std::vector<std::unordered_map<int, cost_t> > p_precomp_estimates;
  
  // p_lowerbound[ cid ][ vid ][ val ]:
  //   cid = constraint in p_constraints_to_check,
  //   vid = variable in scope of constraint associated to cid
  //   val = value in the domain of variable associated to vid
  std::unordered_map<oid_t, 
    std::unordered_map<oid_t, 
      std::unordered_map<int, cost_t> > > p_lowerbound;
#endif

  // An auxiliary array used to store the values to compute the cost of the 
  // constraints during the estimate computation.
  int* p_query;
};

#endif // ULYSSES_ALGORITHMS__AFB__FB_CPA_MSG_HANDLER_H_
