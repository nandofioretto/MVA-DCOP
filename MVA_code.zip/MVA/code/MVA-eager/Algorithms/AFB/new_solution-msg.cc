#include "Algorithms/AFB/new_solution-msg.hh"
#include "Problem/dcop-instance.hh"


NEWSOLUTION_Msg::NEWSOLUTION_Msg()
{
  p_solution.initialize( g_dcop->nbVariables() );
}


NEWSOLUTION_Msg::~NEWSOLUTION_Msg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
NEWSOLUTION_Msg::NEWSOLUTION_Msg(const NEWSOLUTION_Msg& other)
  : Message(other)
{
  p_solution = other.p_solution;  
}


bool NEWSOLUTION_Msg::operator==(const NEWSOLUTION_Msg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


NEWSOLUTION_Msg* NEWSOLUTION_Msg::clone()
{  
  return new NEWSOLUTION_Msg(*this); 
}


std::string NEWSOLUTION_Msg::dump() const
{
  std::string result = Message::dump();
  result += " | Solution: " + p_solution.dump() + "|";  
  return result;
}
