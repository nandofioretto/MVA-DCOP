#include <memory>
#include <vector>
#include <string>

#include "Algorithms/AFB/afb.hh"
#include "Algorithms/AFB/time-stamp-cpa.hh"
#include "Algorithms/AFB/cpa-msg-handler.hh"
#include "Algorithms/AFB/fb_cpa-msg-handler.hh"
#include "Algorithms/AFB/fb_estimate-msg-handler.hh"
#include "Algorithms/AFB/new_solution-msg-handler.hh"
#include "Algorithms/AFB/terminate-msg-handler.hh"
#include "Communication/mailbox.hh"
#include "Communication/scheduler.hh"
#include "Kernel/globals.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Constraints/soft-consistency.hh"
#include "SearchEngines/solution.hh"
#include "SearchEngines/search-engine-factory.hh"
#include "Utilities/utils.hh"
#include "Utilities/constraint-utils.hh"
#include "Utilities/statistics.hh"
//#include "Problem/dcop-instance.hh"

using namespace std;
//#define DBG

bool operator< (const Solution& lhs, const Solution& rhs) {
    if( lhs.size() < rhs.size() ) return true;
    if( lhs.size() > rhs.size() ) return false;
    // otherwise equal size
    for( int i=0; i<lhs.size(); i++) {
      if( lhs[ i ] < rhs[ i ] ) return true;
      if( lhs[ i ] > rhs[ i ] ) return false;
    }
      // otherwise equal size and equal values
    return false; // considered equal
}

AFB::AFB(Agent& owner)
  : Algorithm(owner), p_alg_started(false), p_alg_terminated(false), 
    p_running_assignment_counter(0), p_fb_estimates(0), 
    p_upperbound(Constants::worstvalue)
{
  ASSERT(DCOPinfo::minimize(), "Error: AFB is only defined for minimization \
    problems with all constraint costs are positive, and i've been lazy to \
    implement the dual!");

  shared_ptr<LinearOrdering> ordering(new LinearOrdering(owner));
  owner.setOrdering( ordering );
  p_LO = ordering;

  p_v_ancestor_consistency = SoftConsistency::uptr(new SoftConsistency(owner));

  p_cpa_msg_handler = 
    CPA_MsgHandler::uptr(new CPA_MsgHandler(owner));
  p_fb_cpa_msg_handler =
    FBCPA_MsgHandler::uptr(new FBCPA_MsgHandler(owner));
  p_fb_estimate_msg_handler = 
    FBESTIMATE_MsgHandler::uptr(new FBESTIMATE_MsgHandler(owner));
  p_new_solution_msg_handler = 
    NEWSOLUTION_MsgHandler::uptr(new NEWSOLUTION_MsgHandler(owner));
  p_terminate_msg_handler =
    TERMINATE_MsgHandler::uptr(new TERMINATE_MsgHandler(owner));
  
  p_v_boundary_search = 
    SearchEngine::uptr(SearchEngineFactory::create
      (owner, owner.boundarySolver(), owner.boundarySolverParameters()));
  
  p_v_private_search =  
    SearchEngine::uptr(SearchEngineFactory::create
      (owner, owner.privateSolver(), owner.privateSolverParameters()));

  p_time_stamp = TimeStampCPA::sptr(new TimeStampCPA(owner.id() + 1));
  p_CPA = Solution::sptr(new Solution());
}


AFB::~AFB()
{ }


void AFB::initialize()
{
  p_CPA->initialize( g_dcop->nbVariables() );
  p_best_CPA.initialize( g_dcop->nbVariables() );
  p_upperbound = Constants::worstvalue; 

  // Initializes the boundary variables search engine
  vector<oid_t> v_boundary = owner().boundaryVariableIDs();
  // Select the constraints which involve exclusively boundary variables.
  vector<oid_t> c_boundary = 
    ConstraintUtils::involvingExclusively( v_boundary, owner().id() );
  p_v_boundary_search->initialize(v_boundary, c_boundary);

#ifdef DBG
   // cout << "Boundary search: variables: " << Utils::dump(v_boundary)
   //       << " - constraints: " << Utils::dump(c_boundary) << '\n';
#endif

  vector<oid_t> v_private = owner().privateVariableIDs();
  // The intra-agent constraints, excluding those involving exclusively the 
  // agent boundary variables.
  vector<oid_t> c_private = 
    Utils::exclude(c_boundary, owner().intraAgentConstraintIDs());
  
  // Initializes the private variables search engine (last paramter are the 
  // auxiliary variables, adopted only in some type of search, as Gibbs).
  p_v_private_search->initialize(v_private, c_private, v_boundary);

  
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  /// Construct MVA-Table (only for the eager version)
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  p_v_boundary_search->reset();
  while (p_v_boundary_search->nextSolution()) {
    Solution& v_boundary_sol = p_v_boundary_search->getSolution();
    
    p_v_private_search->setAuxiliaryVarsAssignment( v_boundary_sol.values() );
    if(not p_v_private_search->bestSolution())  {
      Solution empty; empty.setCost(Constants::worstvalue);
      _mva_table[ v_boundary_sol ] = empty;

      /// added to solve TAB problem
      p_v_private_search->unsetAuxiliaryVarsAssignment();  
      continue;
    }
    
    Solution& v_private_sol  = p_v_private_search->getBestSolution();
    _mva_table[ v_boundary_sol ] = v_private_sol;
    /// added to solve TAB problem
    p_v_private_search->unsetAuxiliaryVarsAssignment();  

  }
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  p_v_boundary_search->reset();
  p_v_private_search->reset();
     

#ifdef DBG
  // cout << "Private search: variables: " << Utils::dump(v_private)
  //      << " - constraints: " << Utils::dump(c_private) << '\n';
#endif

  // Initializes the soft consistency manager for the list of the inter-agent 
  // constraints to be checkd after each boundary assignment: it includes the 
  // constraints whose scope include variable v_k's owned by a_j with j <= i.
  vector<oid_t> ancestor_constraints_ = owner().interAgentConstraintIDs();
  for( oid_t aid : owner().neighbours() ) { 
    if( aid > owner().id() )
      Utils::exclude_emplace( g_dcop->agent(aid).interAgentConstraintIDs(),
			      ancestor_constraints_ );
  }
  p_v_ancestors = ConstraintUtils::extractScope(ancestor_constraints_);
  Utils::exclude_emplace(v_boundary, p_v_ancestors);

  sort(p_v_ancestors.begin(), p_v_ancestors.end());
  p_v_ancestor_consistency->initialize( Utils::concat(p_v_ancestors, v_boundary),
				      ancestor_constraints_ );

#ifdef DBG
  // cout << "Ancestor consistency: variables: "
  //      << Utils::dump(Utils::concat(p_v_ancestors, v_boundary))
  //      << " - constraints: " << Utils::dump(ancestor_constraints_) << '\n';
#endif

  p_val_ancestor_consistency.resize( p_v_ancestors.size() + v_boundary.size() );

  // Computes the lower bound for each value of the agent's boundary variables.
  p_lowerbounds.resize(owner().nbBoundaryVariables());
  p_computeBounds();

#ifdef DBG
  // int bidx = 0;
  // for (oid_t bvid : owner().boundaryVariableIDs()) {
  //   IntVariable& bvar = g_dcop->variable(bvid);
  //   for (int val : bvar.domain().content()) {
  //     cout << bvar.name() << " - " << val << ": "
  //     << p_lowerbounds[ bidx ][ val ] << "\n";
  //   }
  //   bidx++;
  // }
  // getchar();
#endif

  // Initializes the message handlers
  p_cpa_msg_handler->initialize(p_CPA, p_time_stamp);
  p_fb_cpa_msg_handler->initialize(p_CPA, p_time_stamp);
  p_fb_estimate_msg_handler->initialize(p_time_stamp);
  p_new_solution_msg_handler->initialize(p_CPA);
  
#ifdef DBG
  // getchar();
#endif
}


void AFB::finalize()
{
  if( !p_alg_terminated )
    p_alg_terminated = true;

  if(owner().id() == 0) 
  {
    for (int vid=0; vid < p_best_CPA.size(); ++vid)
      g_dcop->setVarSolution(vid, p_best_CPA[ vid ]);
    g_dcop->setCost( p_best_CPA.cost() );
  }
}


bool AFB::canRun()
{
  if(p_alg_terminated) return false;
  return p_alg_started ? (owner().openMailbox().size() > 0) : p_LO->head();
}


void AFB::run()
{  
#ifdef DBG
  // std::cout << "----------------------------------------\n"
  //           << "        "  << owner().name()        << "\n"
  //           << "----------------------------------------\n";
  // getchar();
#endif
  if( not canRun() ) { 
    p_alg_started = true; 
    return; 
  }
  
  // First assignment.
  if (!p_alg_started and p_LO->head()) 
  {
    p_past_cost = 0;		// Set the past cost to 0
    p_time_stamp->reset( owner().id() );
    p_assignCPA();
  }

  p_alg_started = true;
  
  // Process incoming NEW_SOLUTION_Msg
  if (p_new_solution_msg_handler->recvNewMsg())
  {
#ifdef DBG
    // cout << "Received new solution: "
    //   << p_new_solution_msg_handler->solution().dump() << endl;
    // getchar();
#endif
    p_setBestCPA( p_new_solution_msg_handler->solution() );
  }

  // Process incoming TERMINATE message
  if (p_terminate_msg_handler->recvNewMsg()) 
  {
#ifdef DBG
   // cout << "Received terminate\n";
   // getchar();
#endif
    finalize();
  }

  // Process incoming FB_ESTIMATE_MSG
  while (p_fb_estimate_msg_handler->recvNewMsg())
  {
    Utils::sum_emplace(p_fb_estimates, 
      p_fb_estimate_msg_handler->recvEstimate());
    cost_t new_bound = Utils::sum(p_CPA->cost(), p_fb_estimates);
#ifdef DBG
   // cout << owner().name() << " new bound: " << new_bound
   //       << " vs upper-bound:" << p_upperbound;
   // getchar();
#endif
    if (Utils::isWorse(new_bound, p_upperbound))
    {
      p_assignCPA();
    }
  }

  // Process incoming FB_p_CPAMSG
  while (p_fb_cpa_msg_handler->recvNewMsg())
  {
    if( p_time_stamp->justAssigned())
      p_v_boundary_search->reset();      
#ifdef DBG
   // getchar();
#endif

    // Compute the function cost estimate based on the received PA.
    cost_t f = p_fb_cpa_msg_handler->computeEstimate(); 
    oid_t aj = p_fb_cpa_msg_handler->received().source();
    // Sends the function cost estimate back to the sender agent. 
    p_fb_estimate_msg_handler->prepareOutgoing( f );
    p_fb_estimate_msg_handler->send( aj );
  }

  // Process incoming p_CPAMSG
  if (p_cpa_msg_handler->recvNewMsg())
  {
    if( p_time_stamp->justAssigned())
      p_v_boundary_search->reset();   
#ifdef DBG
    // getchar();
#endif
    // Set past cost and update local CPA if the CPA message received was
    // sent by higher priority agent (i.e., not backtrack)
    if (p_cpa_msg_handler->received().source() < owner().id())
    {
      // ::::::::::::::::::::::::::::::::::
      // it should be:
      // this->savePAtoLocalCPA( p_cpa_msg_handler->PA() )
      // :::::::::::::::::::::::::::::::::
      p_cpa_msg_handler->savePAtoLocalCPA();
      p_past_cost =  p_CPA->cost();
      p_time_stamp->reset( owner().id() );
    }
    
    if (Utils::isWorse(p_CPA->cost(), p_upperbound))  
      { 
#ifdef DBG
        // cout << "Recv CPA with worst cost than upperbound : " << p_upperbound;
        // getchar();
#endif
        p_backtrack(); 
      }
    else { 
      // Assigns the ancestor values received in the CPA. 
      // :::::::::::::::::::::::::::::::::::::::::::
      // NOTE: The following works only if the variables in the CPA are
      // stored lexicographically, and if the variables id have continuous
      // ID=0...N-1.
      // :::::::::::::::::::::::::::::::::::::::::::
      for (int i = 0; i < p_v_ancestors.size(); ++i)
        p_val_ancestor_consistency[ i ] = (*p_CPA)[ p_v_ancestors[ i ] ];
      p_assignCPA();
    }
  }
}


// ok
cost_t AFB::p_estimate(vector<int> boundary_values)
{
  cost_t sum = 0;
  for (int i = 0; i < boundary_values.size(); ++i) 
  {
#ifdef DBG
    // cout << "lb[ " << i << "] " << boundary_values[ i ] << " :"
    //      << p_lowerbounds[ i ][ boundary_values[ i ] ] << endl;
#endif
    sum += Utils::sum( sum, p_lowerbounds[ i ][ boundary_values[ i ] ]);
  }
  return sum;
}


void AFB::p_assignCPA()
{
  // Clears the the saved estimation from the FB msgs received.
  p_fb_estimates = 0;
  int nb_vA = p_v_ancestors.size();

  // Choose a value whose past + local + future cost < UB
  while (true)
  {
    // Finds the next solution for the boundary variables.
    if (!p_v_boundary_search->nextSolution()){
      // std::cout << "Boundary search failed\n";
      break;			// search terminated.
    }

    ++p_running_assignment_counter;
    p_time_stamp->incrAt( owner().id() );

    Solution& v_boundary_sol = p_v_boundary_search->getSolution();
    
    // Finds the cost for the ancestor variable assignment. (ok var order).
    for (int i = nb_vA; i < p_val_ancestor_consistency.size(); ++i)
      p_val_ancestor_consistency[ i ] = v_boundary_sol[ i-nb_vA ];
    
    if (!p_v_ancestor_consistency->enforceConsistency(p_val_ancestor_consistency))
      continue; 

    cost_t pred_cost = p_v_ancestor_consistency->cost();

    Solution& v_private_sol = _mva_table[ v_boundary_sol ];

    if( !Constants::isFinite(v_private_sol.cost() ) )
      continue;

    cost_t local_cost = Utils::sum(v_boundary_sol.cost(), v_private_sol.cost());    
    cost_t cpa_cost = p_past_cost + local_cost + pred_cost;
    // The best cost for all constraints shared between this agent a_i and some
    // agent aj with j > i.
    cost_t future_cost = p_estimate(v_boundary_sol.values());
    
#ifdef DBG
    // cout << owner().name() << " (" << p_time_stamp->dump() << "): "
    //      << " [b->" << v_boundary_sol.dump() << "]\t [p->"
    //      << v_private_sol.dump() << "] (" << cpa_cost << ")"
    //      << " \t future_cost = " << future_cost
    //      << " sum: " << Utils::sum(cpa_cost, future_cost)
    //      << " / ub: " << p_upperbound << "\n";
    // getchar();
#endif
    // Increments the running assignment counter.
    p_updateCPA(v_boundary_sol, v_private_sol, cpa_cost);
    
    if (Utils::isBetter(Utils::sum(cpa_cost, future_cost) , p_upperbound))
      break;
#ifdef DBG
    // else
    //   cout << "New cost does not improve current ub\n";
#endif
  }

  if (p_v_boundary_search->isTerminated())
  { p_backtrack(); return; }

  if (p_LO->tail())
  {
    // Saves solution and updates bounds for current agent.
    p_setBestCPA( *p_CPA );
    p_new_solution_msg_handler->broadcast();
    p_assignCPA();
#ifdef DBG
    // cout << owner().name() << " Tail -> Solution Found: " << p_best_CPA.dump() << std::endl;
    // getchar();
#endif

  }
  else
  {
    // Sends the CPA to next agent.
    p_cpa_msg_handler->send( p_LO->successor()->id() );
    // Sends the estimate request to every agent with lower priority.
    for(oid_t j=owner().id() + 1; j < g_dcop->nbAgents(); ++j) {
      p_fb_cpa_msg_handler->send( j );
    }
  }

}


void AFB::p_backtrack()
{
#ifdef DBG
  // cout << "BACKTRACK ";
#endif
  // Clears the the saved estimation from the FB msgs received.
  p_fb_estimates = 0;
  p_running_assignment_counter = 0;
  p_time_stamp->reset( owner().id() );
  p_resetCPA();
  p_v_boundary_search->reset(); 
  
  if(p_LO->head()) 
  {
    p_terminate_msg_handler->broadcast();
    finalize();
  }
  else {
    p_cpa_msg_handler->send( p_LO->predecessor()->id() );
  }
}


void AFB::p_computeBounds()
{
  // An auxiliary vector storing the values to be checked in a constraint. 
  // It's size (10) is the current limit of the ext-soft constraint arity.
  int* tuple = new int[ 10 ]; 
  cost_t cost;

  // Considers only inter-agent constraints whose partecipating variables' 
  // owners aj are such that j > i.
  vector<oid_t> constraints = owner().interAgentConstraintIDs();
        
  for( oid_t aid : owner().neighbours() )
  {
    if (aid < owner().id())
      Utils::exclude_emplace(g_dcop->agent(aid).interAgentConstraintIDs(),
			                       constraints);
  }

  int bidx = 0;
  for (IntVariable* bvar : owner().boundaryVariables())
  {
    for (int val : bvar->domain().content())
      // p_lowerbounds[ bidx ][ val ] = p_LO->head() ? 0 : Constants::NaN;
      p_lowerbounds[ bidx ][ val ] = 0;

#ifdef DBG
    // cout << owner().name() << ": lowerbound[" << bidx << "] (" << bvar->name() << ")\n";
#endif
    
    for (oid_t cid : constraints)
    {
      ExtSoftConstraint* esc = 
        dynamic_cast<ExtSoftConstraint*>(&(g_dcop->constraint(cid)));
      
      // The index of current variable in the constraint scope.
      int idx_var_in_esc = Utils::findIdx( esc->scopeIds(), bvar->id() );
      if (idx_var_in_esc == -1) continue;
    
      vector<cost_t> B(bvar->size(), Constants::worstvalue); 
      int d_min = bvar->min();

      // Scans the whole set of values and save min costs given each 
      // domain element of the variable vi 
      esc->resetIterator();
      while (esc->next())
      {
      	esc->getNext(tuple, cost);
      	int val = tuple[idx_var_in_esc];
      	int idx = val - d_min;
      	B[ idx ] = Utils::getBest(cost, B[ idx ]);
#ifdef DBG
        // cout << "\t(" << tuple[0] << " " << tuple[1] << ") cost " << cost << " -- " << " B[" << idx << "]:" << B[idx] << "\n";
#endif
      }

      for (int val : bvar->domain().content() ) 
        Utils::sum_emplace(p_lowerbounds[ bidx ][ val ], B[ val-d_min ]);
    }
    
#ifdef DBG
    // for (int val : bvar->domain().content() )
    //   std::cout << "  " << val << ": " << p_lowerbounds[ bidx ][ val ]<<"\n";
#endif
    
    bidx++;
  }
#ifdef DBG
  // getchar();
#endif
  delete[] tuple;
}
