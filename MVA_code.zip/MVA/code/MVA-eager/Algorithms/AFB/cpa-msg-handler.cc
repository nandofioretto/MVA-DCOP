#include "Algorithms/AFB/cpa-msg-handler.hh"
#include "Algorithms/AFB/time-stamp-cpa.hh"
#include "SearchEngines/solution.hh"
#include "Algorithms/Orderings/linear-ordering.hh"
#include "Communication/scheduler.hh"
//#include "Problem/dcop-instance.hh"
#include "Utilities/statistics.hh"

#include <memory>

CPA_MsgHandler::CPA_MsgHandler(Agent& a)
: MessageHandler(a), p_received(nullptr), p_outgoing(nullptr)
{
  p_outgoing = std::unique_ptr<CPA_Msg>(new CPA_Msg);
}

CPA_MsgHandler::~CPA_MsgHandler()
{ }


void CPA_MsgHandler::initialize(Solution::sptr cpa, TimeStampCPA::sptr ts)
{
  LinearOrdering& LO = dynamic_cast<LinearOrdering&>(owner().ordering());
  p_outgoing->setSource(owner().id());
  if(!LO.tail())
    p_outgoing->setDestination( LO.successor()->id() );

  p_outgoing->timeStamp() = *ts;

  p_local_time_stamp = ts;
  p_local_CPA = cpa;

  p_local_vars_id = owner().localVariableIDs();
}


bool CPA_MsgHandler::recvNewMsg()
{  
  p_received = nullptr;
  while(!p_received)
  { 
    processIncoming();
    if (!p_received) return false; // mailbox is empty
    
    // std::cout << p_received->dump() << "\n";
    // std::cout << "recv-t: " << p_received->timeStamp().dump() << " vs local-t: "
    //           << p_local_time_stamp->dump() << "\n";

    TimeStampCPA::cmp_t cmp = 
      p_received->timeStamp().compare(*p_local_time_stamp);
   
    if (cmp == TimeStampCPA::kNewer) {
      p_local_time_stamp->assign(p_received->timeStamp());
      // std::cout <<"local time stamp updated: " << p_local_time_stamp->dump();
    }
    else if (cmp == TimeStampCPA::kOlder) {
      // std::cout <<"msg discarded\n";
      p_received = nullptr;      
    }
  }
  return true;
}


void CPA_MsgHandler::processIncoming()
{
  if (owner().openMailbox().isEmpty("CPA")) {
    p_received = nullptr;
  }
  else {
    p_received = 
      std::dynamic_pointer_cast<CPA_Msg>(owner().openMailbox().readNext("CPA"));
  }
}


void CPA_MsgHandler::send(oid_t dest_id)
{
  CPA_Msg::sptr to_send(p_outgoing->clone());

  if (dest_id != Constants::nullid) {
    to_send->setDestination(dest_id);
  }

  ASSERT(p_local_CPA, "No CPA was found when sending a CPA message");
  to_send->setPA(*p_local_CPA);
  to_send->setTimeStamp(*p_local_time_stamp);

  owner().openMailbox().send(to_send);
  Scheduler::FIFOinsert(to_send->destination());
}
