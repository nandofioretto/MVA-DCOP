#include "Algorithms/AFB/fb_cpa-msg.hh"
#include "Kernel/globals.hh"

using namespace std;

FBCPA_Msg::FBCPA_Msg()
{ }


FBCPA_Msg::~FBCPA_Msg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
FBCPA_Msg::FBCPA_Msg(const FBCPA_Msg& other)
  : CPA_Msg(other)
{ }


bool FBCPA_Msg::operator==(const FBCPA_Msg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


FBCPA_Msg* FBCPA_Msg::clone()
{
  return new FBCPA_Msg(*this);
}