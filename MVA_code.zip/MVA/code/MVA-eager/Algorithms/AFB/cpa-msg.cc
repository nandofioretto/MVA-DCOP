#include "Algorithms/AFB/cpa-msg.hh"
#include "Kernel/globals.hh"

using namespace std;

CPA_Msg::CPA_Msg()
{ 
  p_PA.initialize( g_dcop->nbVariables() );
}


CPA_Msg::~CPA_Msg()
{ }


// Note: this is a protected copy constructor - it can only called 
// by this object and used by the clone function. 
CPA_Msg::CPA_Msg(const CPA_Msg& other)
  : Message(other)
{
  p_PA = other.p_PA;
  p_time_stamp = other.p_time_stamp;
}

  
bool CPA_Msg::operator==(const CPA_Msg& other)
{
  return (source() == other.source() && destination() == other.destination());
}


CPA_Msg* CPA_Msg::clone()
{
  return new CPA_Msg(*this);
}


string CPA_Msg::dump() const
{
  string result = Message::dump();
  result += " | CPA: " + p_PA.dump() + "|";
  //result += " " + p_time_stamp.dump();
  return result;
}
