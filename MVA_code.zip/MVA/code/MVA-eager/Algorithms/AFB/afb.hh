#ifndef ULYSSES_ALGORITHMS__AFB__AFB_H_
#define ULYSSES_ALGORITHMS__AFB__AFB_H_

#include <memory>
#include <unordered_map>
#include <map>
#include <vector>

#include "Kernel/globals.hh"
#include "Algorithms/algorithm.hh"
#include "SearchEngines/solution.hh"
#include "Kernel/Constraints/soft-consistency.hh"
#include "Kernel/Agents/agent.hh"
#include "Algorithms/Orderings/linear-ordering.hh"
#include "SearchEngines/solution.hh"

class SearchEngine;
class TimeStampCPA;

class FBESTIMATE_MsgHandler;
class CPA_MsgHandler;
class FBCPA_MsgHandler;
class NEWSOLUTION_MsgHandler;
class TERMINATE_MsgHandler;
class Solution;


bool operator< (const Solution& lhs, const Solution& rhs);


// The Asynchronous Forward Bound algorithm.
class AFB : public Algorithm 
{
public:
  AFB(Agent& owner);

  virtual ~AFB();

  // It initializes the AFB algorithm, by computing the lower bounds for each
  // values of the boundary variables of the agent running this algorithm.
  virtual void initialize();

 // It finalizes the AFB algorithm.
  virtual void finalize();

  // It returns true if the algorithm can be executed in this agent.
  virtual bool canRun();
  
  // It executes the Asynchronous Forward Bound algorithm.
  virtual void run();

  // It stops the algorithm saving the current results and states if provided
  // by the algorithm itself.
  virtual void stop()
  { }

  // It returns whether the algorithm has terminated its execution.
  virtual bool terminated() 
  { 
    return p_alg_terminated; 
  }
  

private:
  // It sets the solution given as a parameter as the best solution, and 
  // it updates the current lower bound.
  void p_setBestCPA( Solution& sol )
  {
    if(Utils::isBetter(sol.cost(), p_best_CPA.cost()))
    {
      p_best_CPA = sol;
      p_upperbound = sol.cost();      
    }
  }

  // It updates the current CPA solution sobstituiting the values for the 
  // current agent local variables according to those given as parameter.
  // It assumes that the variables ID are contiguous number starting at 0,
  // and that the scope order for the boundary and private seach follow that
  // of the boundary and private agent variables.
  void p_updateCPA(Solution& v_boundary_sol, Solution& v_private_sol, 
                   cost_t new_cost)
  {
    int i = 0;
    for (int vid : owner().boundaryVariableIDs()){
      p_CPA->setValue(vid, v_boundary_sol[ i++ ]);      
    }
    i = 0;
    for (int vid : owner().privateVariableIDs()) {
      p_CPA->setValue(vid, v_private_sol[ i++ ]);    
    }
    p_CPA->setCost( new_cost );
  }

  // It assigns a new value to the local variables in the current agent. 
  void p_assignCPA();

  // Resets the CPA values for the variables held by current agent to unknown.
  // It is used in the backtrack function.
  void p_resetCPA()
  {
    for (int vid : owner().boundaryVariableIDs())
      p_CPA->setValue(vid, Constants::NaN);
    for (int vid : owner().privateVariableIDs())
      p_CPA->setValue(vid, Constants::NaN);    
  }

  // It computes the estimate cost of the inter-agent constraints of this agent
  // with lower priority agents, given the current boundary value assignments.
  cost_t p_estimate(std::vector<int> boundary_values);

  // It computes the bound for each element in the domain of the agent's
  // boundary variables. 
  // For each value u of boundary variable x_k of agent a_i:
  // h( u ) = \sum_{c \in {c' | x_k \in scope(c') \land 
  //   \forall x_l \in scope(c') . owner(x_l).id >= i } } 
  // The considered cost is the: best( c_|{x_k = u} ) 
  void p_computeBounds();
  
  // It backtrack on the search tree.
  void p_backtrack();

public:
  typedef std::unique_ptr<AFB> uptr;
  typedef std::shared_ptr<AFB> sptr;  

private:

  std::unique_ptr<CPA_MsgHandler> p_cpa_msg_handler;

  std::unique_ptr<FBESTIMATE_MsgHandler> p_fb_estimate_msg_handler;

  std::unique_ptr<FBCPA_MsgHandler> p_fb_cpa_msg_handler;

  std::unique_ptr<NEWSOLUTION_MsgHandler> p_new_solution_msg_handler;

  std::unique_ptr<TERMINATE_MsgHandler> p_terminate_msg_handler;

  // The local running assignment counter - counts the assignments made 
  // by this agent, reset at each change of a higher priority agent (i.e., 
  // the agents with a smaller index w.r.t. this one in the linear ordering).
  size_t p_running_assignment_counter; // not used

  // The most up-to-date time stamp, with respect to this agent knowledge.
  std::shared_ptr<TimeStampCPA> p_time_stamp;

  // The current CPA;
  // The values of the CPA correspond to the variables of each agent in the
  // DCOP in the following order:
  // xi < xj <-> owner(xi).id < owner(xj).id OR 
  //             owner(xi).id = owner(xj).id AND xi.id < xj.id
  std::shared_ptr<Solution> p_CPA;

  // The best solution found so far
  Solution p_best_CPA; 

  // Lower bounds map variables to values to costs:
  // p_lowerbounds[ b ][ val ] holds the sum of the constraint's best costs
  // whose a participating variable is var = the b-th owner's boundary
  // variable, and there are other participating variables owned by some agent 
  // a_j, with j > i.
  // Note: we consider only inter-agent constraints. 
  std::vector< std::unordered_map<int, cost_t> > p_lowerbounds;  

  // The cost of current bound for the DCOP instance.
  cost_t p_upperbound;

  // Is the CPA cost prior an assignment is made by current agent.
  // This cost it is stored whenever this agent is induced to commit a choice
  // by a higher priority agent, and used during backtrack to reset the 
  // previous CPA cost.
  cost_t p_past_cost;

  // The sum of the FB estimates gotten from the FB_ESTIMATE messages.
  cost_t p_fb_estimates;

  // It holds true if the lagorithm has started from this agent.
  bool p_alg_started;
  
  // It holds true if the algorithm is terminated for this agent.
  bool p_alg_terminated;
  
  // Boundary variable search engine.
  std::unique_ptr<SearchEngine> p_v_boundary_search;
  
  // Private variable search engine.
  std::unique_ptr<SearchEngine> p_v_private_search;

  // The soft consistency manager for the ancestor constraints.
  std::unique_ptr<SoftConsistency> p_v_ancestor_consistency;

  // The values of the ancestor variables and boundary variables in a
  // given assignment -- used to compute the cost of the ancestor constraints.
  std::vector<int> p_val_ancestor_consistency;

  // The id of the ancestor variables.
  std::vector<oid_t> p_v_ancestors;

  // A link to the agent ordering. Use for efficiency reasons.
  std::shared_ptr<LinearOrdering> p_LO;


  std::map<Solution, Solution> _mva_table;

};

#endif // ULYSSES_ALGORITHMS__AFB__AFB_H_
