#ifndef ULYSSES_ALGORITHMS__AFB__CPA_MSG_HANDLER_H_
#define ULYSSES_ALGORITHMS__AFB__CPA_MSG_HANDLER_H_

#include <memory>
#include <vector>
#include <string>

#include "Kernel/globals.hh"
#include "Communication/message-handler.hh"
#include "Algorithms/AFB/cpa-msg.hh"
#include "SearchEngines/solution.hh"

class Agent;
class TimeStampCPA;

// The CPA message handler.
// It is only defined for incoming messages.
class CPA_MsgHandler : public MessageHandler
{
public: 
  typedef std::unique_ptr<CPA_MsgHandler> uptr;
  typedef std::shared_ptr<CPA_MsgHandler> sptr;

  CPA_MsgHandler(Agent& a);

  ~CPA_MsgHandler();

  // It prepare the outgoing message, based on the information 
  // collected from the AFB algorithm.
  virtual void prepareOutgoing() 
  { 
    ASSERT(false, "Disallowed!"); 
  }

  // It process the message of type CPA read from the inbox. 
  // It saves the messages in a local storage to be process at needed.
  virtual void processIncoming();

  // It sends the outgoing message to the next agent in the linear ordering.
  virtual void send(oid_t dest_id=Constants::nullid);

  // It initializes the outoing message parameters, and sets the pointers to 
  // the local CPA and local time stamp.
  virtual void initialize(std::shared_ptr<Solution> cpa, 
			  std::shared_ptr<TimeStampCPA> ts);

  // It saves the Partial assignment received into the CPA held by the agent 
  // in the AFB class.
  void savePAtoLocalCPA()
  {
    *p_local_CPA = p_received->PA();

    for(oid_t id : p_local_vars_id)
      p_local_CPA->setValue( id, Constants::NaN);
  }

  // It checks if there is at least a new message of type CPA in the agent's 
  // mailbox. If true, it saves it into the p_received store, and it updates 
  // the local time stamp. 
  bool recvNewMsg();

  // Returns the received CPA message
  CPA_Msg& received() const
  {
    ASSERT( p_received, "Trying to access to a non instantiated message\n");
    return *p_received;
  }
  
private:
  // The messages received, and saved here as a store.
  std::shared_ptr<CPA_Msg> p_received;

  // The outgoing message
  std::unique_ptr<CPA_Msg> p_outgoing;

  // A pointer to CPA stored in the AFB object, which will be attached to the 
  // new otgoing messages.
  Solution::sptr p_local_CPA;

  // The owner local variables ID. It is used to reset the owner CPA assigments 
  // upon receival of a new CPA message.
  std::vector<oid_t> p_local_vars_id;
  
  // A pointer to the local timestamp held by this agent.
  std::shared_ptr<TimeStampCPA> p_local_time_stamp;

};


#endif // ULYSSES_ALGORITHMS__AFB__CPA_MSG_HANDLER_H_
