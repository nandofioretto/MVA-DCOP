#include "Algorithms/AFB/terminate-msg-handler.hh"
#include "Algorithms/AFB/terminate-msg.hh"
#include "Kernel/Agents/agent.hh"
#include "Communication/scheduler.hh"
#include "Problem/dcop-instance.hh"
#include "Utilities/statistics.hh"


TERMINATE_MsgHandler::TERMINATE_MsgHandler(Agent& a)
  : MessageHandler(a)
{
  p_outgoing = std::unique_ptr<TERMINATE_Msg>(new TERMINATE_Msg);
  p_outgoing->setSource(owner().id());
}

TERMINATE_MsgHandler::~TERMINATE_MsgHandler()
{ }


void TERMINATE_MsgHandler::processIncoming()
{
  if (owner().openMailbox().isEmpty("CPA"))
    p_received = nullptr;
  else
    p_received = std::move(std::dynamic_pointer_cast<TERMINATE_Msg>
			  (owner().openMailbox().readNext("TERMINATE")));
}


void TERMINATE_MsgHandler::broadcast()
{
  for(Agent* a : g_dcop->agents())
  {
    if( a->id() == owner().id())
      continue;

    std::shared_ptr<TERMINATE_Msg> to_send(p_outgoing->clone());
    to_send->setDestination(a->id());

    // It also schedule the next agent.
    owner().openMailbox().send(to_send);
  }
}
