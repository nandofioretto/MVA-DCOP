#include "Algorithms/Orderings/ordering.hh"
#include "Kernel/Agents/agent.hh"


Ordering::Ordering(Agent& a)
  : p_agent(&a) 
{ }
 

Ordering::~Ordering() 
{ }
