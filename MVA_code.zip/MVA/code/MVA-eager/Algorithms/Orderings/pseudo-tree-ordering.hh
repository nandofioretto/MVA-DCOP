#ifndef ULYSSES_ALGORITHMS__ORDERINGS__PSEUDO_TREE_ORDERING_H_
#define ULYSSES_ALGORITHMS__ORDERINGS__PSEUDO_TREE_ORDERING_H_

#include "Kernel/globals.hh"
#include "Algorithms/Orderings/ordering.hh"
#include "Kernel/Agents/agent.hh"

#include <set>
#include <string>

// Pseudo-Tree ordering associated to one agent. (a.k.a. pseudo-node).
// This object is constructed by the PseudoTreeAlgorithm, and it is linked
// to the PseudoTreeMsg and the PseudoTreeMsgHandler
class PseudoTreeOrdering : public Ordering
{
public:
  typedef std::unique_ptr<PseudoTreeOrdering> uptr;
  typedef std::shared_ptr<PseudoTreeOrdering> sptr;   
  
  PseudoTreeOrdering(Agent& owner);

  virtual ~PseudoTreeOrdering(); 

  virtual std::string dump() const;

  // Getters
  oid_t parent() const // Deprecated
    { return p_parent; }

  oid_t parentID() const
    { return p_parent; }

  bool isRoot() const // Deprecated
    { return (p_parent == Constants::nullid); }
  
  bool root() const
    { return (p_parent == Constants::nullid); }

  bool isLeaf() const // Deprecated
    { return p_children.empty(); }  

  bool leaf() const
    { return p_children.empty(); }

  oid_t content() const
    { return p_this_node; }

  std::set<oid_t>& children()
    { return p_children; }

  oid_t nbChildren()
    { return p_children.size(); }
  
  std::set<oid_t>& pseudoChildren()
    { return p_pseudo_children; }

  oid_t nbPseudoChildren()
    { return p_pseudo_children.size(); }

  std::set<oid_t>& pseudoParents()
    { return p_pseudo_parents; }

  oid_t nbPseudoParents()
    { return p_pseudo_parents.size(); }

  std::set<oid_t>& separator()
    { return p_separator; }

  oid_t nbSeparator()
    { return p_separator.size(); }

  std::set<oid_t>& ancestors()
    { return p_ancestors; }

  oid_t nbAncestors()
    { return p_ancestors.size(); }

  // Setters 
  void setParent(oid_t a_id) 
    { p_parent = a_id; }

  void addChild(oid_t a_id)
    { p_children.insert(a_id); }

  void removeChild(oid_t a_id)
  {
    std::set<oid_t>::iterator it = p_children.find( a_id );
    if (it != p_children.end()) 
      p_children.erase( it );
  }

  void addPseudoChild(oid_t a_id)
    { p_pseudo_children.insert(a_id); }

  void removePseudoChild(oid_t a_id)
  {
    std::set<oid_t>::iterator it = p_pseudo_children.find( a_id );
    if (it != p_pseudo_children.end()) 
      p_pseudo_children.erase( it );
  }

  void addPseudoParent(oid_t a_id)
    { p_pseudo_parents.insert(a_id); }

  void removePseudoParent(oid_t a_id)
  {
    std::set<oid_t>::iterator it = p_pseudo_parents.find( a_id );
    if (it != p_pseudo_parents.end())
      p_pseudo_parents.erase( it );
  }

  void addSeparator(oid_t a_id)
  {
    if( a_id != p_this_node)
      p_separator.insert(a_id);
  }

  void addAncestor(oid_t a_id)
    { p_ancestors.insert(a_id); }
  
private:

  oid_t p_this_node;

  oid_t p_parent;
  
  // The set of descendant nodes
  std::set<oid_t> p_children;

  // The set of descendant nodes which are connected with this node through a 
  // back edge.
  std::set<oid_t> p_pseudo_children;

  // The set of ancestor nodes which are connected with this node through a 
  // back edge.
  std::set<oid_t> p_pseudo_parents;

  // The separator set of this agent: all ancestor nodes which are connected 
  // with this node (through any edge)  or which are connected with its 
  // descendants.
  std::set<oid_t> p_separator;

  // These are the agent that need to be traversed in a path from the 
  // current node to the root node, traversing only tree-edges. 
  std::set<oid_t> p_ancestors;

};

#endif // ULYSSES_ALGORITHMS__ORDERINGS__PSEUDO_TREE_ORDERING_H_
