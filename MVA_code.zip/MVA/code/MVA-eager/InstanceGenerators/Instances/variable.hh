#ifndef ULYSSES_INSTANCE_GENERATOR__INSTANCE__VARIABLE_H_
#define ULYSSES_INSTANCE_GENERATOR__INSTANCE__VARIABLE_H_

#include <string>
#include <memory>

namespace InstanceGenerator
{
  class Variable
  {
  public:
    typedef std::shared_ptr<Variable> ptr;
    
    Variable(std::string name, std::string domain, std::string agent)
      : p_name(name), p_domain(domain), p_agent(agent)
    { }
    
    std::string name() const
    { 
      return p_name; 
    }

    std::string domain() const
    { 
      return p_domain; 
    }

    std::string agent() const
    { 
      return p_agent; 
    }
    
    std::string dump() const
    {
      return p_name + " (domain: " + p_domain + ") owned by: " + p_agent;
    }

  private:
    // The Variable name.
    std::string p_name;
    
    // The domain name associated to this variable.
    std::string p_domain;
    
    // The name of the agent which ownes this variable, 
    std::string p_agent;
  };
}

#endif // ULYSSES_INSTANCE_GENERATOR__INSTANCE__VARIABLE_H_
