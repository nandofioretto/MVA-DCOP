#include "Instances/instance.hh"

using namespace InstanceGenerator;

Instance::Instance()
  : p_max_constraint_arity(2)
{ }

Instance::~Instance()
{ }


std::string Instance::dump() const
{
  std::string res;
  res += "Agents\n";
  for (const Agent::ptr a : p_agents)
    res += a->dump() + '\n';

  res += "\nDomains\n";
  for (const Domain::ptr d : p_domains)
    res += d->dump() + '\n';

  res += "\nVariables\n";
  for (const Variable::ptr v : p_variables)
    res += v->dump() + '\n';

  res += "\nConstraints\n";
  for (const Constraint::ptr c : p_constraints)
    res += c->dump() + '\n';

  res += "\nRelations\n";
  for (const Relation::ptr r : p_relations)
    res += r->dump() + '\n';

  return res;
}
