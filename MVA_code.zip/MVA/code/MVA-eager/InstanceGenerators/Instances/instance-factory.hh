#ifndef ULYSSES_INSTANCE_GENERATOR__INSTANCES__INSTANCE_FACTORY_H_
#define ULYSSES_INSTANCE_GENERATOR__INSTANCES__INSTANCE_FACTORY_H_

#include <string>
#include <vector>

#include "Instances/instance.hh"

namespace InstanceGenerator
{
  class InstanceFactory
  {
  public:
    static Instance* create(int argc, char* argv[]);    
  };


}

#endif // ULYSSES_INSTANCE_GENERATOR__INSTANCES__INSTANCE_FACTORY_H_
