#ifndef ULYSSES_INSTANCE_GENERATOR__RANDOM__RANDOM_INSTANCE_H_
#define ULYSSES_INSTANCE_GENERATOR__RANDOM__RANDOM_INSTANCE_H_

#include <map>
#include <string>
#include <vector>

#include "Instances/instance.hh"

namespace InstanceGenerator
{
  class RandomInstance : public Instance
  {
  public:
    // It generates a number of random instances which are described by the 
    // paramter specified as input.
    //
    // @param nb_agents The number of agents of the problem.
    // @param nb_local_variables The number of local variables of each agent.
    // @param domain_size The number of elements in range [1...dom_size] 
    //        associated to each variable of the problem.
    // @param max_constr_arity The higher constraint arity among all 
    //        constraints of the problem.
    // @param max_nb_neighbors The maximum number of an agent's neighbor.
    // @param max_nb_boundary_variables The maximum number of an agent's
    //        boundary variables.
    // @param p1_local_variables The graph connectivity among the local 
    // variables of an agent.
    // @param p1_agents The graph connectivity among agents.
    // @param p2 The constraint tightness
    RandomInstance(int nb_agents, int nb_local_variables, int domain_size,       
      int max_constr_arity, int max_nb_neighbors, int max_nb_boundary_variables,
      double p1_local_variables, double p1_agents, double p2);
      
    ~RandomInstance();

    // Given the set of agent id, creates the instance agents.
    void addAgents(std::vector<int> agents_id);
    
    // Creates the instance variables, given the set of problem nodes,
    // and the specifics for their domain. The variables are mapped to the 
    // corresponding agent with the p_map_vars_to_agents mapping.
    void addVariables(std::vector<int> variables_id, int d_min, int d_max);
    
    // Creates a new relation of arity, constraint tighness and value range
    // given as parameter. The values and constraint costs are randomly 
    // generated via uniform distribution ranging respectively in [d_min, d_max]
    // and [0,1000];
    void addRelation(int arity, double p2, int d_min, int d_max);
    
    // Creates a new constraint whose scope is given as a paramter and 
    // associates it to the relation with corresponding arity.
    void addConstraint(std::vector<int> variables_id, int arity);

  private:
    // Maps variables graph nodes to agent's ID.  
    std::map<int, int> p_map_vars_to_agents;
   };
  
}


#endif // ULYSSES_INSTANCE_GENERATOR__RANDOM__RANDOM_INSTANCE_H_
