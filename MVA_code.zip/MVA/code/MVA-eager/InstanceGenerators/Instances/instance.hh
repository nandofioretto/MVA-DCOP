#ifndef ULYSSES_INSTANCE_GENERATOR__INSTANCES__INSTANCE_H_
#define ULYSSES_INSTANCE_GENERATOR__INSTANCES__INSTANCE_H_

#include <string>
#include <vector>

#include "Instances/agent.hh"
#include "Instances/domain.hh"
#include "Instances/variable.hh"
#include "Instances/relation.hh"
#include "Instances/constraint.hh"

namespace InstanceGenerator
{
  class Instance
  {
  public:
   Instance();
    
    ~Instance();

    void save(Agent::ptr agent)
    {
      p_agents.push_back( agent );
      p_agent_with_name[ agent->name() ] = p_agents.size()-1;
    }
    
    Agent& agent(std::string name)
    {
      assert(p_agent_with_name.find(name) != p_agent_with_name.end());
      return *p_agents[ p_agent_with_name[ name ] ];
    }
   
    std::vector<Agent::ptr>& agents()
    {
      return p_agents;
    }
    
    void save(Domain::ptr dom)
    {
      p_domains.push_back( dom );
      p_domain_with_name[ dom->name() ] = p_domains.size()-1;
    }

    Domain& domain(std::string name)
    {
      assert(p_domain_with_name.find(name) != p_domain_with_name.end());
      return *p_domains[ p_domain_with_name[ name ] ];
    }
    
    std::vector<Domain::ptr>& domains()
    {
      return p_domains;
    } 
    
    void save(Variable::ptr var)
    {
      p_variables.push_back( var );
      p_variable_with_name[ var->name() ] = p_variables.size()-1;
    }
    
    Variable& variable(std::string name)
    {
      assert(p_variable_with_name.find(name) != p_variable_with_name.end());
      return *p_variables[ p_variable_with_name[ name ] ];
    }
    
    std::vector<Variable::ptr>& variables()
    { 
      return p_variables;
    }
   
    void save(Constraint::ptr con)
    {
      p_constraints.push_back( con );
      p_constraint_with_name[ con->name() ] = p_constraints.size()-1;
    }
    
    Constraint& constraint(std::string name)
    {
      assert(p_constraint_with_name.find(name) != p_constraint_with_name.end());
      return *p_constraints[ p_constraint_with_name[ name ] ];
    }
    
    std::vector<Constraint::ptr>& constraints()
    {
      return p_constraints;
    }

    void save(Relation::ptr rel)
    {
      p_relations.push_back( rel );
      p_relation_with_name[ rel->name() ] = p_relations.size()-1;
    }
    
    Relation& relation(std::string name)
    {
      assert(p_relation_with_name.find(name) != p_relation_with_name.end());
      return *p_relations[ p_relation_with_name[ name ] ];
    }
    
    std::vector<Relation::ptr>& relations()
    {
      return p_relations;
    }

    int maxConstraintArity() const
    {
      return p_max_constraint_arity;
    }

    std::string dump() const;

    
  protected:
    std::vector<Agent::ptr> p_agents;
    std::map<std::string, int> p_agent_with_name;
        
    std::vector<Variable::ptr> p_variables;
    std::map<std::string, int> p_variable_with_name;

    std::vector<Domain::ptr> p_domains;
    std::map<std::string, int> p_domain_with_name;
        
    std::vector<Constraint::ptr> p_constraints;
    std::map<std::string, int> p_constraint_with_name;
    
    std::vector<Relation::ptr> p_relations;
    std::map<std::string, int> p_relation_with_name;

    int p_max_constraint_arity;
  };


}

#endif // ULYSSES_INSTANCE_GENERATOR__INSTANCES__INSTANCE_H_
