#ifndef ULYSSES_INSTANCE_GENERATOR__RANDOM_HC_IJCAI_H_
#define ULYSSES_INSTANCE_GENERATOR__RANDOM_HC_IJCAI_H_

#include <map>
#include <string>
#include <vector>

#include "Instances/instance.hh"

namespace InstanceGenerator {
  namespace IJCAI {
    class RandomHC : public Instance
    {
    public:
      // Random Graph with hard constraints between boundary variables.
      // 
      // nb_agents
      // nb_local_variables
      // domain_size
      // max_nb_boundary_variables
      // p1_local
      // p1_global
      // p2
      RandomHC(int A, int Li, int Di, int max_Bi, double p1l, double p1g, double p2);
      
      ~RandomHC();
      
      // Given the agent id, it creates the instance agents returning its name. 
      std::string addAgent(int agent_id);
      
      // It creates an instance domain whose values are in the interval [min, 
      // max]. It returns the domain name.
      std::string addDomain(int min, int max);
      
      // It creates the instance variables of name, agent owner and domain given
      // as parameters.
      void addVariable(std::string var_name, std::string agent_name, std::string dom_name);
      
      // It creates a relation for two transmission lines, returning its name.
      std::string addEqRelation(std::string di, std::string dj);
      
      // IT creates a constraint associated to the transmission relation above.
      void addEqConstraint(std::string vi, std::string vj, std::string tl_rel);
      
      void addRelation(int arity, double p2, int d_min, int d_max);

      void addConstraint(std::vector<int> variables_id, int arity);
      
      void addBinaryConstraint(std::vector<std::string> scope);

    private:
      // Maps agent's ID to their name.
      std::map<int, std::string> p_agent_name;

      // Maps variables ID's to their name.
      std::map<int, std::string> p_variable_name;

    // Maps variables graph nodes to agent's ID.  
    std::map<int, int> p_map_vars_to_agents;
    };
  }
}
#endif // ULYSSES_INSTANCE_GENERATOR__RANDOM__HC_IJCAI_H_
