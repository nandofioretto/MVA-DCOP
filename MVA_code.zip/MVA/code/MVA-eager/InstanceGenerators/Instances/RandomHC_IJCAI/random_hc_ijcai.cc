#include <vector>
#include <numeric>
#include <initializer_list>
#include <type_traits>
#include <cmath>

#include "Instances/RandomHC_IJCAI/random_hc_ijcai.hh"
#include "Graph/planar-graph.hh"
#include "Graph/random-graph.hh"
#include "Graph/graph-utils.hh"
#include "Utilities/utils.hh"


#define RELAXED_PROBLEM

using namespace InstanceGenerator;
using namespace IJCAI;
using namespace std;


RandomHC::RandomHC(int A, int Li, int Di, int max_Bi, double p1l, double p1g, double p2) {
  
  p_max_constraint_arity = 8;
  
  unsigned seed = chrono::system_clock::now().time_since_epoch().count();
  std::default_random_engine rnd(seed);

  RandomGraph graph(A, p1g, A-1);
  //PlanarGraph graph(nb_smart_houses, max_nb_neighbors);
  int nb_nodes = graph.nbNodes();

  // List all nodes of the power grid (is a set)
  std::vector<std::string> grid;

  // Power that can be transmited at each time slot
  int tl_d_min = -1*ceil(Di / 2.0);
  int tl_d_max =  ceil(Di / 2.0);
  // Power that can be generated at each time slot
  int g_d_min = 0;
  int g_d_max = Di-1;

  // DOMAINS
  std::string tl_dom = addDomain(tl_d_min, tl_d_max); 
  std::string g_dom  = addDomain(g_d_min, g_d_max);

  // Add the relation f_ij = -f_ji   
  std::string tl_rel = addEqRelation(tl_dom, tl_dom);

  // AGENTS:
  for (int n = 0; n < nb_nodes; ++n) {
    p_agent_name[ n ] = addAgent( n ); 
  }
  
  
  // Constraints over boundary variables of different agents
  for (int n = 0; n < nb_nodes; ++n) {
    std::string house_n = p_agent_name[ n ];

    std::string var_i = "v_" + std::to_string(n);
    addVariable(var_i, p_agent_name[ n ], g_dom); 
    std::vector<std::string> scope(2);
    scope[ 0 ] = var_i;

    // Add Transmission lines with each neighbouring house.
    std::vector<std::string> lines_in;
    for (int w : graph.neighbors(n))
    {
      std::string house_w = p_agent_name[ w ];

      std::string line_in = "tl_" + std::to_string(n) + "_" + std::to_string(w);
      std::string line_out= "tl_" + std::to_string(w) + "_" + std::to_string(n);
      lines_in.push_back( line_in );
      
      // Check existence
      if (!Utils::find(line_in, grid) && !Utils::find(line_out, grid))
      {
        grid.push_back(line_in);
        grid.push_back(line_out);
        
        // Register tranmission line variables lineIn, lineOut w Domains
        addVariable(line_in, house_n, tl_dom);   // ok
        addVariable(line_out, house_w, tl_dom);  // ok
        
        // Add constraint transmission line: (link to transmittion line relation)
        addEqConstraint(line_in, line_out, tl_rel); // ok
      }

      scope[ 1 ] = line_in;
      addBinaryConstraint(scope);
    }//- neighbours explored
  }

  // Add local graphs
  for(int n = 0; n < nb_nodes; ++n) {
    RandomGraph subgraph(Li, p1l);
    
    int last_node = graph.nbNodes();
    graph.join(subgraph, n, max_Bi);
    
    // Map new added Variables to agent
    p_map_vars_to_agents[ n ] = n;        // Map old variable to agent
    for (int i = last_node; i< graph.nbNodes(); ++i) {
      std::string var_i = "v_" + std::to_string(i);
      p_map_vars_to_agents[ i ] = n;
      addVariable(var_i, p_agent_name[ n ], g_dom); 
    }
  }
  
  
  
  for (int k = p_max_constraint_arity; k >= 3; k--) {
    vector< vector<int> > cliques = GraphUtils::cliques(graph, k);
    if(!cliques.empty())
      addRelation(k, p2, 0, Di-1);  
    
    for (vector<int> nodes : cliques) {
      // Save Constraint of arity k
      addConstraint(nodes, k);
      
      // Remove edges from graph (all pairs in nodes)
      do {
	int u = nodes[ 0 ], v = nodes[ 1 ];
	graph.eraseEdge( u, v );
      } while (Utils::next_combination
	       (nodes.begin(), nodes.begin() + 2, nodes.end()) );
    }
  }
  
  // Creates constraints for all the binary constraints left
  if( graph.nbEdges() > 0) {
    addRelation(2, p2, 0, Di-1);  
    
    std::vector<int> scope(2);
    for (int i=0; i<graph.nbNodes(); ++i)
      for (int j=0; j<i; ++j)
	
	if (graph.edge(i, j)) {
	  scope[ 0 ] = i; scope[ 1 ] = j;
	  addConstraint(scope, 2);
	}
  }
}


RandomHC::~RandomHC()
{ }


std::string RandomHC::addAgent(int agent_id)
{
  std::string name = "house_"+std::to_string(agent_id);
  Instance::save(Agent::ptr(new Agent( name )));
  return name;
}


std::string RandomHC::addDomain(int min, int max)
{
  std::string dname = "dom" + std::to_string(Instance::p_domains.size());
  Instance::save(Domain::ptr(new Domain(dname, min, max)));
  return dname;
}


void RandomHC::addVariable
  (std::string var_name, std::string agent_name, std::string dom_name)
{
  Instance::save(Variable::ptr( new Variable(var_name, dom_name, agent_name)) );
}


std::string RandomHC::addEqRelation
  (std::string di, std::string dj)
{
  Domain& dom_i = Instance::domain( di );
  Domain& dom_j = Instance::domain( dj );
  
  Relation::ptr rel( new Relation("tl_rel", 2, Constants::infinity));
  
  for (int di : dom_i.values())
    for (int dj : dom_j.values())
      if ((di + dj) == 0)
        rel->addTuple( std::make_pair(std::initializer_list<int>{di, dj}, 0) );
   
  Instance::save( rel );

  return rel->name();
}


void RandomHC::addEqConstraint
  (std::string vi, std::string vj, std::string tl_rel)
{
  int c_id = Instance::p_constraints.size();
  Instance::save( Constraint::ptr( new Constraint("c_"+std::to_string(c_id),
     std::initializer_list<std::string>{vi, vj}, tl_rel) ) );
}


void RandomHC::addRelation(int arity, double p2, int d_min, int d_max)
{
  uniform_int_distribution<cost_t> U_cost(0, 10);
  uniform_int_distribution<int> U_values(d_min, d_max);
  
  unsigned seed =
    chrono::system_clock::now().time_since_epoch().count();
  std::default_random_engine rnd(seed);
  
  int nb_values = (p2 * std::pow((d_max - d_min + 1), arity));
  
  Relation::ptr rel( new Relation("r_"+std::to_string(arity), arity));
  std::set<std::vector<int> > tuples;
  std::vector<int> tuple(arity);
  
  while (tuples.size() < nb_values)
  {
    for (int i = 0; i < arity; ++i) 
      tuple[ i ] = U_values(rnd);
    tuples.insert( tuple );
  }

  for(std::vector<int> tuple : tuples) {
    rel->addTuple( std::make_pair(tuple, U_cost(rnd)) );    
  }
  
  Instance::save( rel );
}


void RandomHC::addConstraint(std::vector<int> variables_id, int arity)
{
  std::vector<std::string> scope;
  for (int var_id : variables_id)
    scope.push_back("v_"+std::to_string(var_id));
  std::string rel = "r_"+std::to_string(arity);

  int c_id = Instance::p_constraints.size();
  Instance::save( Constraint::ptr(
    new Constraint("c_"+std::to_string(c_id), scope, rel)) );
}


void RandomHC::addBinaryConstraint(std::vector<std::string> scope)
{
  std::string rel = "r_2";

  int c_id = Instance::p_constraints.size();
  Instance::save( Constraint::ptr(
    new Constraint("c_"+std::to_string(c_id), scope, rel)) );
}
