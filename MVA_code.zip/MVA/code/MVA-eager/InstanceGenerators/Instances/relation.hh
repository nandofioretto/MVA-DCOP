#ifndef ULYSSES_INSTANCE_GENERATOR__INSTANCE__RELATION_H_
#define ULYSSES_INSTANCE_GENERATOR__INSTANCE__RELATION_H_

#include <string>
#include <vector>
#include <memory>

#include "Kernel/globals.hh" // Create a file constants.hh and types.hh

namespace InstanceGenerator
{
  class Relation
  {
  public:
    typedef std::shared_ptr<Relation> ptr;
    typedef std::pair<std::vector<int>, cost_t> relentry_t;
    
    Relation(std::string name, int arity, cost_t def_cost=Constants::infinity,
             std::string semantics="soft")
      : p_name(name), p_arity(arity), p_default_cost(def_cost), 
	p_semantics(semantics)
    { }
    
    std::string name() const
    {
      return p_name;
    }

    std::string semantics() const
    {
      return p_semantics;
    }

    cost_t defaultCost() const
    {
      return p_default_cost;
    }
    
    size_t arity() const
    {
      return p_arity;
    }

    std::vector<relentry_t>& tuples()
    {
      return p_tuples;
    }

    size_t nbTuples() const
    {
      return p_tuples.size();
    }

    void addTuple(relentry_t tuple)
    {
      p_tuples.push_back(tuple);
    }

    std::string dump() const
    {
      std::string res = p_name + " arity: " + std::to_string(p_arity) + 
	" semantics: " + p_semantics + " def cost: " + 
	std::to_string(p_default_cost);
      for(const relentry_t& entry : p_tuples) {
	res += "\n [";
	for(int t : entry.first) 
	  res += std::to_string(t) + " ";
	res += "] cost: " + std::to_string(entry.second);
      }
      return res;
    }

    
  private:
    // The relation name
    std::string p_name;
    
    // The relation semantics
    std::string p_semantics;
    
    // The dafault cost of the relation
    cost_t p_default_cost;
    
    // The arity of each relation tuple.
    size_t p_arity;
    
    // The list of tuples with associated costs 
    std::vector<relentry_t> p_tuples;
  };
}

#endif // ULYSSES_INSTANCE_GENERATOR__INSTANCE__RELATION_H_
