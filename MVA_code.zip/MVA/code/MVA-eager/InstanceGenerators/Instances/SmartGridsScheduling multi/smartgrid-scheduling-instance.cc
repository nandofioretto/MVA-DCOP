#include <vector>
#include <numeric>
#include <initializer_list>
#include <type_traits>
#include <cmath>

#include "Instances/SmartGridsScheduling/smartgrid-scheduling-instance.hh"
#include "Graph/random-graph.hh"
#include "Graph/graph-utils.hh"
#include "Utilities/utils.hh"

#define RELAXED_PROBLEM

using namespace InstanceGenerator;
using namespace std;


double pdfNormal( double x, double mu, double sigma )
{
  double base = ( (x - mu) * (x - mu) ) / (2 * sigma * sigma);
  double div  = sigma * sqrt(2 * M_PI); 
  return (1 / div) * exp( -base );
}


// AGENTS:
// smart houses - low connectivity, generated at random.

// VARIABLES FOR EACH AGENT:
// - 1 (generator) -> n time-slots
// - 1 (PEV) -> n batteries (one per time-slot)
// - 1 transmission line for each neighbour ij

// DOMAINS:
// (generators) = [0 .. max_power]
// (PEV)        = [0 .. capacity]
// (transmission lines) = [-limit, +limit]

// OTHER VALUES:
// battery-capacity (fixed for all agents)
// demands for each time-slot ( normal distr. with pick hours) 
// cost of energy production  ( follow distr. of denamds )
// cost of storage energy     ( free )
// cost of borrowing energy   ( follow distr. of demands )
// cost of landing energy     ( same as borrowing but with negative sign )

// OBJECTIVE:
// minimize total costs
SmartGridSchedulingInstance::SmartGridSchedulingInstance
(int nb_smart_houses, int nb_time_slots, int max_power_generator, int battery_capacity, 
 int max_nb_neighbors, int transmission_lines_limit)
{
  p_max_constraint_arity = 3 + max_nb_neighbors;
  ASSERT(p_max_constraint_arity <= 9, "Maximum constraint arity exceed 9.");
  
  unsigned seed =
    chrono::system_clock::now().time_since_epoch().count();
  std::default_random_engine rnd(seed);

  // Fill demands with normal distribution with pick hours in the middle time-slot.
  std::vector<int> demands( nb_time_slots );
  double mu    = nb_time_slots / 2.0;
  double sigma = ceil(sqrt(nb_time_slots)); 
  for (int t = 0; t < nb_time_slots; t++ )
    demands[ t ] = pdfNormal( (double)t, mu, sigma );
  
  // Sobstituite this with one of the IEEE networks.
  RandomGraph graph(nb_smart_houses, 0.4, max_nb_neighbors);
  
  // List all nodes of the power grid (is a set)
  std::vector<std::string> grid;
  
  int nb_nodes = graph.nbNodes();
  // Power that can be transmited at each time slot
  int tl_d_min = -transmission_lines_limit;
  int tl_d_max =  transmission_lines_limit;
  // Power that can be generated at each time slot
  int g_d_min = 0;
  int g_d_max = max_power_generator;
  // Battery storage at each time slot
  int b_d_min = 0;
  int b_d_max = battery_capacity;

  // DOMAINS
  std::string tl_dom = addDomain(tl_d_min, tl_d_max); 
  std::string g_dom  = addDomain(g_d_min, g_d_max);
  std::string b_dom  = addDomain(b_d_min, b_d_max);

  // Add the relation f_ij = -f_ji   
  std::string tl_rel = addTransmissionLineRelation(tl_dom, tl_dom);

  // AGENTS:
  for (int n = 0; n < nb_nodes; ++n)
  {
    p_agent_name[ n ] = addAgent( n ); 
  }
  
  std::map<int, std::vector<std::string> > lines_in;
  for (int n = 0; n < nb_nodes; ++n)
  {
    std::string house_n = p_agent_name[ n ];

    // Add Transmission lines with each neighbouring house.
    
    for (int t = 0; t < nb_time_slots; t++)
    {
      if( t % 2 == 1 ) continue;
      std::vector<std::string> lines;
      for (int w : graph.neighbors(n))
      {
	std::string house_w = p_agent_name[ w ];

	std::string line_in = "tl_" + std::to_string(n) + "_" + std::to_string(w) + "_t" + std::to_string(t); 
	std::string line_out= "tl_" + std::to_string(w) + "_" + std::to_string(n) + "_t" + std::to_string(t);
	lines.push_back( line_in );
      
	// Check existence
	if (!Utils::find(line_in, grid) && !Utils::find(line_out, grid))
	{
	  grid.push_back(line_in);
	  grid.push_back(line_out);
        
	  // Register tranmission line variables lineIn, lineOut w Domains
	  addVariable(line_in, house_n, tl_dom);   // ok
	  addVariable(line_out, house_w, tl_dom);  // ok
        
	  // Add constraint transmission line: (link to transmittion line relation)
	  addTransmissionLineConstraint(line_in, line_out, tl_rel); // ok
	}
      }//- neighbours explored
      lines_in[ t ] = lines;
    }

    // I should generate power otherwise what??
    // int min_gen = g_d_min + 1;
    // int max_gen = g_d_max + 2;
    // std::uniform_int_distribution<int> U(min_gen, max_gen);
    

    // Add Variables to this house
    std::vector<std::string> generators_t;
    std::vector<std::string> batteries_t;
    for (int t = 0; t < nb_time_slots; t++)
    {
      // Power Genrated at time t
      std::string generator = "pg_t" + std::to_string(n) + "_" + std::to_string(t);
      grid.push_back( generator );
      addVariable( generator, house_n, g_dom );
      generators_t.push_back( generator );

      // Power Accumulated at time t
      std::string battery = "pa_t" + std::to_string(n) + "_" + std::to_string(t);
      grid.push_back( battery );
      addVariable( battery, house_n, b_dom );
      batteries_t.push_back( battery );
    }

    // Constraints 
    for (int t = 0; t < nb_time_slots; t++)
    {
      std::string generator = generators_t[ t ];
      std::string battery   = batteries_t[ t ];

      // PG_t + PA_t >= demand_t
      addDemandConstraint(generator, battery, demands[ t ] );

      // PA_t+1 = max( PG_t + PA_t - demand_t, capacity_B)
      if (t == 0)
      {
	std::string gen_tn = generators_t.back();
	std::string bat_tn = batteries_t.back();
	int demand_tn = demands.back();
	addPowerTransferConstraint(battery, gen_tn, bat_tn, lines_in[ t ], demand_tn, battery_capacity);
      }
      else if( t % 2 == 0) {
	addPowerTransferConstraint(battery, generators_t[ t-1 ], batteries_t[ t-1 ], 
				   lines_in[ t ], demands[ t-1 ], battery_capacity);

	// addBatteryConstraint(battery, generators_t[ t-1 ], batteries_t[ t-1 ], demands[ t-1 ], battery_capacity);
      }
    }
    
  }
  
}


SmartGridSchedulingInstance::~SmartGridSchedulingInstance()
{ }


std::string SmartGridSchedulingInstance::addAgent(int agent_id)
{
  std::string name = "house_"+std::to_string(agent_id);
  Instance::save(Agent::ptr(new Agent( name )));
  return name;
}


std::string SmartGridSchedulingInstance::addDomain(int min, int max)
{
  std::string dname = "dom" + std::to_string(Instance::p_domains.size());
  Instance::save(Domain::ptr(new Domain(dname, min, max)));
  return dname;
}


void SmartGridSchedulingInstance::addVariable
  (std::string var_name, std::string agent_name, std::string dom_name)
{
  Instance::save(Variable::ptr( new Variable(var_name, dom_name, agent_name)) );
}


std::string SmartGridSchedulingInstance::addTransmissionLineRelation
  (std::string di, std::string dj)
{
  Domain& dom_i = Instance::domain( di );
  Domain& dom_j = Instance::domain( dj );
  
  Relation::ptr rel( new Relation("tl_rel", 2, Constants::infinity));
  
  for (int di : dom_i.values())
    for (int dj : dom_j.values())
      if ((di + dj) == 0)
        rel->addTuple( std::make_pair(std::initializer_list<int>{di, dj}, 0) );
   
  Instance::save( rel );

  return rel->name();
}


void SmartGridSchedulingInstance::addTransmissionLineConstraint
  (std::string vi, std::string vj, std::string tl_rel)
{
  int c_id = Instance::p_constraints.size();
  Instance::save( Constraint::ptr( new Constraint("c_"+std::to_string(c_id),
     std::initializer_list<std::string>{vi, vj}, tl_rel) ) );
}



void SmartGridSchedulingInstance::addDemandConstraint
  (std::string generator, std::string battery, int demand )
{
  int r_id = Instance::p_relations.size();
  std::string demand_rel = "demand_rel_" + std::to_string(r_id);
  
  Relation::ptr rel( new Relation(demand_rel, 2, Constants::infinity));
  
  // Generate all permutations of lines_in \cdot time_slot
  std::vector< std::vector<int> > permutations;
 
  for (std::string s : Utils::concat(generator, battery))
  {
    Domain& dom = Instance::domain( Instance::variable( s ).domain() );
    Utils::cartesian_product(permutations, dom.values());
  }
  
  // Check which combo of those generated meets the demands.
  for (std::vector<int>& combo : permutations)
  {
    int sum_combo = std::accumulate(combo.begin(), combo.end(), 0);
    cost_t util = 0;
    if (sum_combo >= demand)
    {
      //std::for_each(combo.begin(), combo.end(), [&](int n){ util += n*n; });
      rel->addTuple( std::make_pair(combo, util) );
    }
  }
  
  // Automatize this step
  ASSERT(rel->nbTuples() > 0, "Over constrained problem - Demand Constraints.");
  
  int c_id = Instance::p_constraints.size();
  Instance::save( rel );
  
  Instance::save(Constraint::ptr( new Constraint( "c_"+std::to_string(c_id), 
		 Utils::concat(generator, battery), rel->name() ) ));
}


void SmartGridSchedulingInstance::addBatteryConstraint
(std::string battery, std::string generator_pt, std::string battery_pt, int demand_pt, int battery_capacity)
{
  int r_id = Instance::p_relations.size();
  std::string battery_rel = "battery_rel_" + std::to_string(r_id);
  
  Relation::ptr rel( new Relation(battery_rel, 3, Constants::infinity));
  
  // Generate all permutations of lines_in \cdot time_slot
  std::vector< std::vector<int> > permutations;
  for (std::string s : Utils::concat(generator_pt, battery_pt))
  {
    Domain& dom = Instance::domain( Instance::variable( s ).domain() );
    Utils::cartesian_product(permutations, dom.values());
  }
  
  Domain& battery_dom = Instance::domain( Instance::variable( battery ).domain() );

  for ( int bval : battery_dom.values() )
  {
    // Check which combo of those generated meets the demands.
    for (std::vector<int>& combo : permutations)
    {
      int residual = std::accumulate(combo.begin(), combo.end(), 0) - demand_pt;      
      cost_t util = 0;
      if (bval == residual || bval == battery_capacity )
      {
	rel->addTuple( std::make_pair(Utils::concat(bval, combo), util) );
      }
    }
  }

  // Automatize this step
  ASSERT(rel->nbTuples() > 0, "Over constrained problem - Battery constraint.");
  
  int c_id = Instance::p_constraints.size();
  Instance::save( rel );

  std::vector<std::string> scope(3);
  scope[ 0 ] = battery; 
  scope[ 1 ] = generator_pt;
  scope[ 2 ] = battery_pt;

  Instance::save(Constraint::ptr( new Constraint( "c_"+std::to_string(c_id), 
		 scope, rel->name() ) ));

}



void SmartGridSchedulingInstance::addPowerTransferConstraint
(std::string battery, std::string generator_pt, std::string battery_pt,
 std::vector<std::string> lines_in, int demand_pt, int battery_capacity)
{

  int r_id = Instance::p_relations.size();
  std::string power_transfer_rel = "power_transfer_rel_" + std::to_string(r_id);
  
  Relation::ptr rel( new Relation(power_transfer_rel, lines_in.size() + 3, Constants::infinity));
  ASSERT(rel->arity() <= 9, "Maximum constraint arity exceed 9.");

  // Generate all permutations of lines_in \cdot time_slot
  std::vector< std::vector<int> > permutations;
  for ( std::string s : Utils::concat(Utils::concat(generator_pt, battery_pt), lines_in) ) 
  {
    Domain& dom = Instance::domain( Instance::variable( s ).domain() );
    Utils::cartesian_product(permutations, dom.values());
  }
   
  Domain& battery_dom = Instance::domain( Instance::variable( battery ).domain() );

  for ( int bval : battery_dom.values() )
  {
    // Check which combo of those generated meets the demands.
    for (std::vector<int>& combo : permutations)
    {
      int residual = std::accumulate(combo.begin(), combo.end(), 0) - demand_pt;      
      cost_t util = 0;
      if (bval == residual || bval == battery_capacity )
      {
	rel->addTuple( std::make_pair(Utils::concat(bval, combo), util) );
      }
    }
  }
  
  // Automatize this step
  ASSERT(rel->nbTuples() > 0, "Over constrained problem.");
  
  int c_id = Instance::p_constraints.size();
  Instance::save( rel );

  std::vector<std::string> scope(3);
  scope[ 0 ] = battery;  scope[ 1 ] = generator_pt; scope[ 2 ] = battery_pt;
 
  Instance::save(Constraint::ptr( new Constraint( "c_"+std::to_string(c_id), 
		    Utils::concat(scope, lines_in), rel->name() ) ));
}





// CO2func( gen ) -> pow(gen, 2).
#ifdef FALSE
void SmartGridSchedulingInstance::addPowerBalanceCO2Constraint
(std::vector<std::string> lines_in, std::vector<std::string> generators, int sum_loads)
{
  int r_id = Instance::p_relations.size();
  std::string co2rel = "co2_rel_" + std::to_string(r_id);
  
  Relation::ptr rel( new Relation(co2rel, lines_in.size() + generators.size(), Constants::infinity));
  
  // Generate all permutations of lines_in \cdot generators
  std::vector< std::vector<int> > permutations;
  for (std::string s : Utils::concat(lines_in, generators)) 
  {
    Domain& dom = Instance::domain( Instance::variable( s ).domain() );
    Utils::cartesian_product(permutations, dom.values());
  }
  
  // Check which combo of those generated satisfies the power balance equation,
  // and compute the CO2 emission at the local agent generators.
  for (std::vector<int>& combo : permutations)
  {
    int sum_combo = std::accumulate(combo.begin(), combo.end(), 0);
    cost_t util = 0;
#ifdef RELAXED_PROBLEM
    if (sum_combo >= sum_loads)
#else
    if ((sum_combo + sum_loads) == 0) 
#endif
    {
      std::for_each(combo.begin(), combo.end(), [&](int n){ util += n*n; });
      rel->addTuple( std::make_pair(combo, util) );
    }
  }
  
  // Automatize this step
  ASSERT(rel->nbTuples() > 0, "Over constrained problem.");
  
  int c_id = Instance::p_constraints.size();
  Instance::save( rel );
  
  Instance::save(Constraint::ptr( 
    new Constraint( "c_"+std::to_string(c_id), 
                    Utils::concat(lines_in, generators), 
                    rel->name() ) ));
}
#endif
