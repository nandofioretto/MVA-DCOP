#ifndef ULYSSES_INSTANCE_GENERATOR__INSTANCE__CONSTRAINT_H_
#define ULYSSES_INSTANCE_GENERATOR__INSTANCE__CONSTRAINT_H_

#include <string>
#include <vector>
#include <memory>

namespace InstanceGenerator
{
  class Constraint
  {
  public:
    typedef std::shared_ptr<Constraint> ptr;
    
    Constraint(std::string name, std::vector<std::string> scope, std::string rel)
      : p_name(name), p_scope(scope), p_relation(rel)
    { }
    
    std::string name() const
    { 
      return p_name; 
    }

    std::vector<std::string>& scope()
    { 
      return p_scope; 
    }

    size_t arity() const
    {
      return p_scope.size();
    }
    
    std::string relation() const
    { 
      return p_relation; 
    }

    std::string dump() const
    {
      std::string res = p_name + " rel: " + p_relation + " (";
      for(std::string s : p_scope)
	res += s + " ";
      res += ")";
      return res;
    }

      
  private:
    // The constraint name
    std::string p_name;
        
    // The name of the variables in the scope of this constraint.
    std::vector<std::string> p_scope;
    
    // The name of the relation associated to this constraint.
    std::string p_relation;
  };
}

#endif // ULYSSES_INSTANCE_GENERATOR__INSTANCE__CONSTRAINT_H_
