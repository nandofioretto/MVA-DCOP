#ifndef ULYSSES_INSTANCE_GENERATOR__INSTANCE__AGENT_H_
#define ULYSSES_INSTANCE_GENERATOR__INSTANCE__AGENT_H_

#include <string>
#include <memory>

namespace InstanceGenerator
{
  class Agent
  {
  public:
    typedef std::shared_ptr<Agent> ptr;
    
    Agent(std::string name, std::string search="DFS", 
          std::vector<int> params = std::vector<int>())
      : p_name(name), p_solving_strategy(search), p_parameters(params)
    { }
    
    std::string name() const
    { 
      return p_name; 
    }
    
    std::string privateSolver() const
    { 
      return p_solving_strategy; 
    }
    
    std::vector<int> parameters() const
    { 
      return p_parameters; 
    }

    std::string dump() const
    {
      return p_name + " " + p_solving_strategy;
    }
    
  private:
    // The agent name
    std::string p_name;
    
    // The agent solving strategy used to solve the internal subproblem. 
    std::string p_solving_strategy;
    
    // The parameters to be assigned to the internal solving strategy
    std::vector<int> p_parameters;
  };
}

#endif // ULYSSES_INSTANCE_GENERATOR__INSTANCE__AGENT_H_
