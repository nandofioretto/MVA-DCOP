#ifndef ULYSSES_INSTANCE_GENERATOR__INSTANCE__DOMAIN_H_
#define ULYSSES_INSTANCE_GENERATOR__INSTANCE__DOMAIN_H_

#include <string>
#include <memory>
#include <numeric>      // std::iota

namespace InstanceGenerator
{
  class Domain 
  {
  public:
    typedef std::shared_ptr<Domain> ptr;
        
    Domain(std::string name, int min, int max)
      : p_name(name), p_min(min), p_max(max)
    { }
    
    std::string name() const
    { 
      return p_name; 
    }
    
    int min() const
    { 
      return p_min; 
    }

    int max() const
    { 
      return p_max; 
    }

    std::vector<int> values()
    {
      std::vector<int> v(this->size()) ;
      std::iota (std::begin(v), std::end(v), this->min());
      return v;
    }
    
    size_t size() const
    { 
      return (p_max - p_min + 1);
    }
    
    std::string dump() const
    {
      return p_name + " [" + std::to_string(p_min) + ", " 
	+ std::to_string(p_max) + "]"; 
    }

  private:
    // The domain name
    std::string p_name;

    // (Bound) domain minimum value
    int p_min;

    // (Bound) domain maximum value
    int p_max; 
  };
}

#endif // ULYSSES_INSTANCE_GENERATOR__INSTANCE__DOMAIN_H_
