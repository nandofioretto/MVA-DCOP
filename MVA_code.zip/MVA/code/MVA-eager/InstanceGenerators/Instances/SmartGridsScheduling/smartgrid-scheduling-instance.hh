#ifndef ULYSSES_INSTANCE_GENERATOR__SMART_GRIDS_SMARTGRIDSCHEDULING_INSTANCE_H_
#define ULYSSES_INSTANCE_GENERATOR__SMART_GRIDS_SMARTGRIDSCHEDULING_INSTANCE_H_

#include <map>
#include <string>
#include <vector>

#include "Instances/instance.hh"

namespace InstanceGenerator
{
  class SmartGridSchedulingInstance : public Instance
  {
  public:
    // It generates one smart grid instance described by the paramter specified 
    // as input.
    // Each house has one load whose consumption is randomly generated and not
    // bigger than the sum of its generators.
    //
    // @param nb_smart_houses The number of agents of the problem.
    // @param nb_local_generators The number of generators for each smart house
    // @param domain_generator The number of elements in range [0...dom_size] 
    //        associated to each generator variable.
    // @param max_nb_neighbors The maximum number of an agent's neighbor.
    // @param domain_transmission_line The number of elements in range
    //        [-dom_size/2 ... dom_size/2] associated to each transmission line
    //        note: dom_size must be odd.
    // @param max_constr_arity The higher constraint arity among all 
    //        constraints of the problem.
    //
    // Note: 
    // - the number of neighbours is equal to the number of boundary variables.
    // - Max constr arity <= max nb neighbours + nb local generators.
    SmartGridSchedulingInstance(int nb_smart_houses, int nb_time_slots, 
				int max_power_generator, int battery_capacity, 
				int max_nb_neighbors, int transmission_lines_limit);
    
    ~SmartGridSchedulingInstance();

    // Given the agent id, it creates the instance agents returning its name. 
    std::string addAgent(int agent_id);
    
    // It creates an instance domain whose values are in the interval [min, 
    // max]. It returns the domain name.
    std::string addDomain(int min, int max);
    
    // It creates the instance variables of name, agent owner and domain given
    // as parameters.
    void addVariable(std::string var_name, std::string agent_name, 
		     std::string dom_name);
    
    // It creates a relation for two transmission lines, returning its name.
    std::string addTransmissionLineRelation(std::string di, std::string dj);

    // IT creates a constraint associated to the transmission relation above.
    void addTransmissionLineConstraint(std::string vi, std::string vj, 
				       std::string tl_rel);


    void addDemandConstraint(std::string generator, std::string battery, int demand );

    void addBatteryConstraint(std::string battery, std::string generator_pt, 
			      std::string battery_pt, int demand_pt, int battery_capacity);

    void addPowerTransferConstraint(std::string battery, std::string generator_pt, 
				    std::string battery_pt, std::vector<std::string> lines_in, 
				    int demand_pt, int battery_capacity);

  private:
    // Maps variables graph nodes to agent's ID.  
    std::map<int, std::string> p_agent_name;
  };
 
}

#endif // ULYSSES_INSTANCE_GENERATOR__RANDOM__RANDOM_INSTANCE_H_
