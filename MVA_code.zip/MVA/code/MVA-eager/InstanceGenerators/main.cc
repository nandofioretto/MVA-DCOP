#include <iostream>
#include "Instances/Random/random-instance.hh"

#include "Instances/instance-factory.hh"
#include "IO/input.hh"
#include "IO/output-xml.hh"

using namespace InstanceGenerator;

int main(int argc, char* argv[])
{
  Input::checkParams(argc, argv);
  std::string pathout = Input::getPathOut(argv);
  std::string fileout = Input::getFileOut(argv);
  int nb_instances = Input::getNbInstances(argv);
  int nb_start     = Input::getNbStart(argv); 
  Output* create_xml = new OutputXML(pathout, fileout, nb_instances, nb_start);

  for (int i = 0; i < nb_instances; ++i) 
  {
    Instance* instance = InstanceFactory::create( argc, argv );
    create_xml->dump(instance);
  }

  return 0;
}
