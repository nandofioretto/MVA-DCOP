#include "Kernel/globals.hh"
#include "Graph/random-graph.hh"
#include "Graph/graph-utils.hh"
#include "Utilities/utils.hh"

#include <iostream>
#include <random>

using namespace InstanceGenerator;
using namespace std;
  
RandomGraph::RandomGraph(int nb_nodes, double p1, int max_nb_neighbors)
  : Graph(nb_nodes)
{
  if (max_nb_neighbors == 0) max_nb_neighbors = nb_nodes;
  unsigned seed =
    chrono::system_clock::now().time_since_epoch().count();
  p_rand = unique_ptr<default_random_engine>(new default_random_engine(seed));
  
  int max_nb_edges = (nb_nodes * (nb_nodes-1)) / 2;
  int nb_edges = std::ceil(p1 * max_nb_edges);
  ASSERT(nb_edges >= nb_nodes-1, "The graph connectivity " << p1 << 
	 "cannot ensure a connected graph.");
  
  // Generates random edges
  uniform_int_distribution<int> U(0, nb_nodes-1);
  int nb_nodes2 = nb_nodes * nb_nodes;
  
  while (!GraphUtils::connected(*this))
  {
    Graph::clear();
    while (nbEdges() != nb_edges)
    {
      int fails = 0;
      int u, v;
      do {
        u = U(*p_rand);
        WARNING( ++fails < nb_nodes2, "Failing too much!");
      } while(degree(u) >= max_nb_neighbors);
      
      fails = 0;
      do { 
        v = U(*p_rand);  
        WARNING( ++fails < nb_nodes2, "Failing too much!");
      } while(degree(v) >= max_nb_neighbors or v == u);

      if (not edge( u, v ))
        newEdge(u, v);
    }
  }
  
}


RandomGraph::~RandomGraph()
{ }
