#ifndef ULYSSES_INSTANCE_GENERATOR__GRAPH_H_
#define ULYSSES_INSTANCE_GENERATOR__GRAPH_H_

#include <vector>
#include <string>
#include <memory>

#include "Kernel/globals.hh"

namespace InstanceGenerator
{
  class Graph
  {
  public:
    typedef std::unique_ptr<Graph> uptr;
    typedef std::shared_ptr<Graph> sptr;
    
    // Creates a graph of a number of nodes as those given as parameter, and 
    // no edges.
    Graph(int nb_nodes);
    
    ~Graph();
    
    // It returns the number of nodes of the graph.
    size_t nbNodes() const
    {
      return p_nodes.size();
    }
  
    // It returns the number of edges of the graph.
    size_t nbEdges() const
    {
      return p_nb_edges; 
    }
    
    // It returns true if there is an edge between nodes u and v.
    bool edge(int u, int v) const
    {
      ASSERT( u < nbNodes() and v < nbNodes(), "Error in node encoding.");
      return p_edges[ u ][ v ];
    }
    
     // It returns the i-th node of the graph.
    int node(int i) const
    {
      ASSERT( i >= 0 and i < nbNodes(), "Error in node encoding.");
      return p_nodes[ i ];
    }
    
    // It returns the nodes of the graph
    std::vector<int> nodes() const
    {
      return p_nodes;
    }
    
    // It creates a new edge between nodes indexed u and v. 
    // It returns true if the edge was successufully created (did not exist 
    // before).
    bool newEdge(int u, int v);
    
    // Removes an edge between nodes indexed u and v.
    void eraseEdge(int u, int v);
    
    // It clears all the graph edges.
    void clear();
    
    // It returns the node degree associated to the node given as parameter. 
    int degree( int u );
    
    // It returns the neighbor nodes of the node given as parameter.
    std::vector<int> neighbors(int u);
    
    // It joins the current graph with the other given as a parameter, at the
    // node of current graph: target_node.
    // Target node is replaced by the first node of the other graph (in lex 
    // oreder) and the constraints are updated accordingly.
    // TODO: needs a better comment.
    void join(const Graph& other, int target_node, int max_out_nodes);
    
    // It returns a string description of the graph.
    std::string dump() const;
    
    
  private:
    // The nodes of the graph
    std::vector<int> p_nodes;
    
    // The adjacency matrix 
    std::vector<std::vector<bool> > p_edges;
    
    // The number of (undirected) edges of the graph.
    size_t p_nb_edges;
  };

}
#endif // ULYSSES_INSTANCE_GENERATOR__GRAPH_H_

