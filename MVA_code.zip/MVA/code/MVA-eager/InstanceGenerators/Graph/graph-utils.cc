#include <queue>
#include <set>
#include <algorithm>

#include "Graph/graph.hh"
#include "Graph/graph-utils.hh"
#include "Utilities/utils.hh"

using namespace InstanceGenerator;
using namespace std;


bool GraphUtils::connected(Graph& graph)
{
  if(graph.nbEdges() < (graph.nbNodes()-1)) return false;
  
  enum node_state{kUnvisited=0, kTraversed, kOpened, kClosed};
  vector<node_state> status(graph.nbNodes(), kUnvisited);
  queue<int> traversal_queue;
  int n_components = 0;

  for (int n : graph.nodes())
  {
    if (status[ n ] == kTraversed) continue;
    
    traversal_queue.push( n );
  
    while (!traversal_queue.empty())
    {
      int t = traversal_queue.front(); traversal_queue.pop(); 
      
      for( int u : graph.neighbors(t) ) {
        if(status[ u ] == kUnvisited) 
        { 
          status[ u ] = kOpened;
          traversal_queue.push( u );
        }
      }
      status[ t ] = kTraversed;
    }
    ++n_components;
  }
  return (n_components == 1);
}


vector< vector<int> > GraphUtils::cliques(Graph& graph, int size)
{ 
  vector<int> nodes = graph.nodes();
  vector<int> clique(size);
  vector<vector<int> > cliques;
  do 
  {
    bool is_clique = true;
    for (int u = 0; u < size; ++u) 
    {
      for (int v = u+1; v < size; ++v) 
      {
        if (!graph.edge(nodes[ u ], nodes[ v ]))
        { is_clique = false; break; }
      }
      if(!is_clique) break;
    }
    
    if(is_clique) {
      clique.assign(nodes.begin(), nodes.begin() + size);
      cliques.push_back( clique );
    }
      
  } while (Utils::next_combination
           (nodes.begin(), nodes.begin() + size, nodes.end()) );
  
  return cliques;
}
