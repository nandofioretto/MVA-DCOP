#include <iostream>

#include "graph.hh"
#include "Utilities/utils.hh"


using namespace InstanceGenerator;
using namespace std;
  
Graph::Graph(int nb_nodes) 
  : p_nb_edges(0)
{
  for (int i = 0; i < nb_nodes; ++i)
    p_nodes.push_back(i);
  
  p_edges.resize(nb_nodes);
  for (int i = 0; i < nb_nodes; ++i)
    p_edges[ i ].resize(nb_nodes, false);
}


Graph::~Graph()
{ }


bool Graph::newEdge(int u, int v)
{
  WARNING( u != v, "In general self cycles are not allowed.");
  
  if( p_edges[ u ][ v ] ) 
    return false;
  p_edges[ u ][ v ] = true;
  p_edges[ v ][ u ] = true;
  ++p_nb_edges;
  return true;
}


void Graph::eraseEdge(int u, int v)
{
  if(p_edges[ u ][ v ])
  {
    p_edges[ u ][ v ] = false;
    p_edges[ v ][ u ] = false;
    --p_nb_edges;
  }
}


void Graph::clear()
{
  for( int i=0; i<p_edges.size(); ++i)
    std::fill(p_edges[i].begin(), p_edges[i].end(), false);
  p_nb_edges = 0;
}


int Graph::degree(int u)
{
  int deg = 0;
  for(int i=0; i < p_edges[ u ].size(); ++i)
    deg += p_edges[ u ][ i ];
  return deg;
}


vector<int> Graph::neighbors(int u)
{
  vector<int> N;
  for(int i=0; i < p_edges[ u ].size(); ++i)
    if( p_edges[ u ][ i ] )
      N.push_back( i );
  return N;
}


void Graph::join(const Graph& other, int target_node, int max_out_nodes)
{
  vector<int> t_neighbours = neighbors(target_node);
  // Creates map from old nodes to new nodes.
  std::map<int, int> map_nodes;
  map_nodes[ 0 ] = target_node;
  int last_node = nbNodes() - 1;
  for (int i=1; i < other.nbNodes(); ++i)
  {
    p_nodes.push_back(last_node + i);
    map_nodes[ i ] = (last_node + i);
  }

  // Expand Edges.
  p_edges.resize(nbNodes());
  for (int i = 0; i < nbNodes(); ++i)
    p_edges[ i ].resize(nbNodes());
  
  // Clears row and column corresponding to target_node
  for (int i=0; i <= last_node; ++i) {
    if(p_edges[ i ][ target_node ]) {
      p_edges[ i ][ target_node ] = p_edges[ target_node ][ i ] = false;
      --p_nb_edges;
    }
  }

  // Copy old edges into new graph
  for (int i = 0; i < other.nbNodes(); ++i)
    for (int j = 0; j <= i; ++j)
      if (other.edge(i, j))
	newEdge( map_nodes[ i ], map_nodes[ j ] );

  // Merge the two graphs
  for (int i=0; i < t_neighbours.size(); ++i)
  {
    int u = t_neighbours[ i ];
    int j = (i % max_out_nodes);//(i % other.nbNodes());
    int v = map_nodes[ j ];

    newEdge(u, v);
  } 
}


string Graph::dump() const
{
  std::string res = "Nodes: " + Utils::dump(p_nodes);
  res += "\nEdges:\n";
  
  // Scan only the lower triangular matrix
  for (int i = 0; i < nbNodes(); ++i)
    for (int j = 0; j <= i; ++j)
      if (p_edges[ i ][ j ])
        res += std::to_string(node(j)) + "--" + std::to_string(node(i)) + "\n"; 
  
  return res;
}
