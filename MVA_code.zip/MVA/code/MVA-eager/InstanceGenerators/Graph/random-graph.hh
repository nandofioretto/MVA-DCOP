#ifndef ULYSSES_INSTANCE_GENERATOR__GRAPH__RANDOM_GRAPH_H_
#define ULYSSES_INSTANCE_GENERATOR__GRAPH__RANDOM_GRAPH_H_

#include <chrono>
#include <memory>
#include <random>
#include <string>

#include "Graph/graph.hh"

namespace InstanceGenerator
{
  class RandomGraph : public Graph
  {
   public:
     typedef std::unique_ptr<RandomGraph> uptr;
     typedef std::shared_ptr<RandomGraph> sptr;
     
     // Creates a random graph.
     //
     // @param nb_nodes The number of nodes in the graph.
     // @param p1 The network connectivity
     // @param max_nb_neigbors The maximum number of neigbors for each node, if 
     //   0, then it is ignored.
     RandomGraph(int nb_nodes, double p1, int max_nb_neighbors=0);

     ~RandomGraph();


  private:
    // The Network connectivity associated to this constraint graph.
    double p_p1;
    
    // A random engine used to generate random numbers.
    std::unique_ptr<std::default_random_engine> p_rand;
  };

}
#endif // ULYSSES_INSTANCE_GENERATOR__GRAPH__RANDOM_GRAPH_H_

