#ifndef ULYSSES_INSTANCE_GENERATOR__GRAPH__GRAPH_UTILS_H_
#define ULYSSES_INSTANCE_GENERATOR__GRAPH__GRAPH_UTILS_H_

#include <vector>
#include <string>
#include <memory>

class Graph;

namespace InstanceGenerator
{
  namespace GraphUtils
  {
	
    // It returns true if the graph given as a parameter is connected.
    bool connected(Graph& graph);
    
    // It returns all the cliques (as a list of nodes) of size k, of the graph
    // given as a parameter. 
    std::vector<std::vector<int> > cliques(Graph& graph, int k);
    
  }
}

#endif // ULYSSES_INSTANCE_GENERATOR__GRAPH__GRAPH_UTILS_H_
