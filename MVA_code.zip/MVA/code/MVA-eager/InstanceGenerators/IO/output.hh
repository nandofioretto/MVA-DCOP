#ifndef ULYSSES_INSTANCE_GENERATOR__IO__OUTPUT_H_
#define ULYSSES_INSTANCE_GENERATOR__IO__OUTPUT_H_

#include <string>

#include "Instances/instance.hh"
#include "Kernel/globals.hh"

namespace InstanceGenerator
{
  class Output
  {
  public: 
    Output(std::string pathout, std::string fileout, int nb_instances, int nb_start=0)
      : p_pathout(pathout), p_fileout(fileout), p_nb_instances(nb_instances),
	      p_curr_insance(nb_start)
    { }
    
    // Dumps instance on output file 
    virtual void dump(Instance* instance)
    {
      std::string file = p_pathout + "/rep_" + std::to_string(p_curr_insance) + "_" + p_fileout;
      // Template pattern
      dump(*instance, file);

      p_curr_insance++;
    }

    virtual void dump(Instance& instance, std::string file) = 0;


  protected:
    std::string costToString(cost_t cost)
    {
      if (cost == Constants::infinity)
        return "infinity";
      if (cost == -Constants::infinity)
        return "-infinity";
      return std::to_string(cost);
    }

  private:
    std::string p_pathout;

    std::string p_fileout;
    
    int p_nb_instances;

    int p_curr_insance;
  };

}

#endif // ULYSSES_INSTANCE_GENERATOR__IO__OUTPUT_XML_H_
