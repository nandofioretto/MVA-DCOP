#include <fstream>
#include <sstream>
#include <vector>
#include <string>

#include "IO/output-xml.hh"
#include "Instances/agent.hh"
#include "Instances/domain.hh"
#include "Instances/variable.hh"
#include "Instances/relation.hh"
#include "Instances/constraint.hh"


using namespace InstanceGenerator;

OutputXML::OutputXML(std::string pathout, std::string fileout, int nb_instances, int nb_start)
  : Output(pathout, fileout, nb_instances, nb_start)
{ }


void OutputXML::dump(Instance& instance, std::string file)
{
  size_t found = file.find_last_of(".");
  std::string extension = file.substr(found+1);
  if (found == std::string::npos)
    file += ".xml";
  else if(extension.compare("xml") != 0){
    file = file.substr(0, found);
    file += ".xml";
  }
  
  std::cout << "file is: " << file << std::endl; 
  
  std::ofstream os ( file.c_str() );
  if( os.is_open() )
  {
    dumpInstance( os );
    dumpPresentation( os, instance.maxConstraintArity() );
    dumpAgents( os, instance.agents() );
    dumpDomains( os, instance.domains() );
    dumpVariables( os, instance.variables() );
    dumpRelations( os, instance.relations() );
    dumpConstraints( os, instance.constraints() );
    os << "</instance>" << std::endl;
    os.close();
  }
  else std::cout << "Cannot open file: " << file << std::endl;
  
}


void OutputXML::dumpInstance(std::ostream &os)
{
  os << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
  os << open_xml_tag << "instance"
     << " xmlns:xsi=" 
     << txt_d << "http://www.w3.org/2001/XMLSchema-instance" << txt_d
     << " xsi:noNamespaceSchemaLocation="
     << txt_d << "src/ch/epfl/lia/frodo/algorithms/XCSPschema.xsd" << txt_d
     << ">" << std::endl;
}


void OutputXML::dumpPresentation(std::ostream &os, int max_con_arity)
{
  os << open_xml_tag << "presentation"
     << " name=" << txt_d << "RandomGraphs" << txt_d
     << " maxConstraintArity=" << txt_d << max_con_arity << txt_d
     << " maximize=" << txt_d << "false" << txt_d
     << " format=" << txt_d << "XCSP 2.1_FRODO" << txt_d 
     << close_xml_tag;
}


void OutputXML::dumpAgents(std::ostream &os, std::vector<Agent::ptr> agents)
{
  os << "<agents" << " nbAgents=" << txt_d << agents.size() 
     << txt_d << ">" << std::endl;
  for (Agent::ptr agent : agents)
  {
    os << "\t" << open_xml_tag << "agent"
       << " name=" << txt_d << agent->name() << txt_d 
       << close_xml_tag;
  }
  os << "</agents>" << std::endl;
}


void OutputXML::dumpDomains(std::ostream &os, std::vector<Domain::ptr> domains)
{
  os << "<domains" << " nbDomains=" << txt_d << domains.size() 
     << txt_d << ">" << std::endl;
  for (Domain::ptr dom : domains)
  {
    os << "\t" << open_xml_tag << "domain"
       << " name=" << txt_d << dom->name() << txt_d
       << " nbValues=" << txt_d << dom->size() << txt_d << ">"
       << dom->min() << ".." << dom->max()
       << "</domain>" << std::endl;
  }
  os << "</domains>" << std::endl;
}


void OutputXML::dumpVariables(std::ostream &os, std::vector<Variable::ptr> variables)
{
  os << "<variables" << " nbVariables=" << txt_d << variables.size() 
     << txt_d << ">" << std::endl;
  for (Variable::ptr var : variables)
  {
    os << "\t" << open_xml_tag << "variable"
       << " name=" << txt_d << var->name() << txt_d
       << " domain=" << txt_d << var->domain() << txt_d 
       << " agent=" << txt_d << var->agent() << txt_d 
       << close_xml_tag;
  }
  os << "</variables>" << std::endl;
}


void OutputXML::dumpRelations( std::ostream &os, std::vector<Relation::ptr> relations)
{
  os << "<relations" << " nbRelations=" << txt_d << relations.size() 
     << txt_d  << ">"  << std::endl;
  for (Relation::ptr rel : relations)
  {
    os << "\t" << open_xml_tag << "relation"
       << " name=" << txt_d << rel->name() << txt_d
       << " arity=" << txt_d << rel->arity() << txt_d 
       << " nbTuples=" << txt_d << rel->nbTuples() << txt_d 
       << " semantics=" << txt_d << rel->semantics() << txt_d
       << " defaultCost=" << txt_d << costToString(rel->defaultCost()) << txt_d
       << ">";
    int i=0;
    for(Relation::relentry_t& entry : rel->tuples())
    {
      os << costToString(entry.second) << ":";
      for(int value : entry.first) // scan each value in the entry tuple 
        os << value << " ";
      if (++i < rel->nbTuples()) os << "|";
    }
    os << "</relation>" << std::endl;
  }
  os << "</relations>" << std::endl;
}


void OutputXML::dumpConstraints(std::ostream &os, std::vector<Constraint::ptr> constraints)
{
  os << "<constraints" << " nbConstraints=" << txt_d << constraints.size() 
     << txt_d << ">" << std::endl;
  for (Constraint::ptr con : constraints)
  {
    os << "\t" << open_xml_tag << "constraint"
       << " name=" << txt_d << con->name() << txt_d
       << " arity=" << txt_d << con->arity() << txt_d 
       << " scope=" << txt_d; 
    int i=0;
    for (const std::string& var : con->scope())
    {
      os << var;
      if (++i < con->arity()) os << " ";
    }
    os << txt_d;
    os << " reference=" << txt_d << con->relation() << txt_d 
       << close_xml_tag;
  }
  os << "</constraints>" << std::endl;
}
