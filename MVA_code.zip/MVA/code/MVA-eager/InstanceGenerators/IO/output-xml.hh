#ifndef ULYSSES_INSTANCE_GENERATOR__IO__OUTPUT_XML_H_
#define ULYSSES_INSTANCE_GENERATOR__IO__OUTPUT_XML_H_

#include <string>

#include "IO/output.hh"
#include "Instances/instance.hh"

namespace InstanceGenerator
{
  class OutputXML : public Output
  {
  public: 
    OutputXML(std::string pathout, std::string fileout, int nb_instances, int nb_start=0);
    
    virtual void dump(Instance& instance, std::string file);    

  private:
    void dumpInstance(std::ostream &os);
    void dumpPresentation(std::ostream &os, int max_con_arity);
    void dumpAgents(std::ostream &os, std::vector<Agent::ptr> agents);
    void dumpDomains(std::ostream &os, std::vector<Domain::ptr> domains);
    void dumpVariables(std::ostream &os, std::vector<Variable::ptr> variables);
    void dumpRelations( std::ostream &os, std::vector<Relation::ptr> relations);
    void dumpConstraints(std::ostream &os, std::vector<Constraint::ptr> constraints);

    const std::string txt_d = "\"";
    const std::string open_xml_tag = "<";
    const std::string close_xml_tag = "/>\n";
  };

}

#endif // ULYSSES_INSTANCE_GENERATOR__IO__OUTPUT_XML_H_
