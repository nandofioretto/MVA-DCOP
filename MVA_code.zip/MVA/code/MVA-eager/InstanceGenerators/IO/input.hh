#ifndef ULYSSES_INSTANCE_GENERATOR__IO__INPUT_H_
#define ULYSSES_INSTANCE_GENERATOR__IO__INPUT_H_

#include <cstring>
#include <iostream>
#include <stdlib.h>     /* atoi */

namespace InstanceGenerator
{
  namespace Input
  {
    // It returns the output path
    inline int getNbInstances(char* argv[])
    { return atoi(argv[ 1 ]); }

    inline int getNbStart(char* argv[])
    { return atoi(argv[2]); }

    // It returns the output path
    inline std::string getPathOut(char* argv[])
    { return argv[ 3 ]; }

    // It returns the output file
    inline std::string getFileOut(char* argv[])
    { return argv[ 4 ]; }

    // It returns the description of the usage help 
    inline std::string usage()
    {
      return
	"ulysses-generator nb_instances outpath outfile instance\n\
	 where:\n\
	  nb_instances = the number of instances to generate\n\
          n_start      = the instance starting number\n\
	  outpath      = the directory of output\n\
	  outfile      = the output filename (will be numbered)\n\
	  instance is one of the following:\n\
        -random:\n\
             nb_agents\n\
             nb_local_variables\n\
             domain_size\n\
             max_constr_arity\n\
             max_nb_neighbors\n\
             max_nb_boundary_variables\n\
             p1_local_variables\n\
             p1_agents\n\
             p2\n\
        -smartgrid:\n\
             nb_smart_houses\n\
             nb_local_generators\n\
             domain_generator\n\
             max_nb_neighbors\n\
             domain_transmission_lines\n\
        -bus-scheduling:\n\
             nb_divisions\n\
             nb_time_slots\n\
             max_nb_bus_time\n\
             max_nb_neighbors\n\
             nb_bus_to_exchange\n\
        -smartgrid-scheduling:\n\
             nb_smart_houses\n\
             nb_time_slots\n\
             max_power_at_generator\n\
             battery_capacity\n\
             max_nb_neighbors\n\
             transmission_line_limit\n\
        -IJCAI15-random: A   Li   Di   max(Bi)   p1L   p1G   p2\n";

    }
    
    inline void checkParams(int argc, char* argv[])
    {
      if(argc < 5)
        goto printParamErr;

      for (int i=0; i<argc; ++i) {
        if (strcmp("-random", argv[i]) == 0 && argc == 15)
          return;
        if (strcmp("-IJCAI15-random", argv[i]) == 0 && argc == 13)
          return;
        if (strcmp("-smartgrid", argv[i]) == 0 && argc == 11)
          return;
        if (strcmp("-bus-scheduling", argv[i]) == 0 && argc == 11)
          return;
        if (strcmp("-smartgrid-scheduling", argv[i]) == 0 && argc == 12)
          return;
      }
      printParamErr:
      std::cout << "Wrong number of parameters received" << std::endl
        << usage() << std::endl;
      exit(1);
    }

  }// Input
}// InstanceGenerator

#endif // ULYSSES_INSTANCE_GENERATOR__IO__INPUT_H_
