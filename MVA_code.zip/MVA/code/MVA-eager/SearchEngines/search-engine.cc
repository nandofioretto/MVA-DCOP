#include "Kernel/globals.hh"
#include "SearchEngines/search-engine.hh"

using namespace std;

SearchEngine::SearchEngine(Agent& owner) :
  p_owner(&owner), search_ended_( false ), search_failed_( false)
{ 
  static size_t g_kVSearchEngineCounter = 0;
  ObjectInfo::setId( g_kVSearchEngineCounter++ );
}


SearchEngine::~SearchEngine()
{
  // if(varID2scopePos) delete[] varID2scopePos;
  // if(scopePos2varID) delete[] scopePos2varID;
}

void SearchEngine::unsetAuxiliaryVarsAssignment()
{
  for (int i=0; i<auxiliary_vars_.size(); ++i) {
    auxiliary_vars_[ i ]->domain().setMin( state_auxiliary_vars_[ i ].first );
    auxiliary_vars_[ i ]->domain().setMax( state_auxiliary_vars_[ i ].second );
    auxiliary_vars_[ i ]->resetLastChoice();
  }
}
