#include "Kernel/globals.hh"
#include "Utilities/utils.hh"
#include "Utilities/constraint-utils.hh"
#include "SearchEngines/BranchAndBound/branch-and-bound.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint.hh"

#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"

#include "Problem/dcop-instance.hh"

//#define DBG

using namespace std;


BranchAndBound::BranchAndBound(Agent& owner) 
  : SearchEngine(owner), curr_level_(0), zero_level_(0), 
best_bound_(Constants::worstvalue), curr_bound_(0)
{ 
  p_soft_consistency = SoftConsistency::uptr(new SoftConsistency(owner));
}


BranchAndBound::~BranchAndBound()
{ }


void BranchAndBound::initialize(vector<oid_t> scope, vector<oid_t> c_store,
std::vector<oid_t> aux_vars)
{  
  // Initializes the scope and solutions of the search
  scope_ = g_dcop->variables( scope );
  if(!aux_vars.empty()) 
  {
    auxiliary_vars_ = g_dcop->variables( aux_vars );
    state_auxiliary_vars_.resize(aux_vars.size());
    for(int i=0; i<auxiliary_vars_.size(); ++i)
      state_auxiliary_vars_[ i ] =
        std::make_pair(auxiliary_vars_[ i ]->min(), auxiliary_vars_[ i ]->max());
  }

  // Initializes the search stack
  for (IntVariable* v : scope_)
    search_stack_.registerRestorable( v );
  
  p_soft_consistency->initialize( g_dcop->constraints(c_store));
  
  size_t ssize = scope_.size();
  trail_pt_.resize(ssize, 0);

  // Initializes The solution Vectors:
  curr_solution_.initialize(ssize);
  best_solution_.initialize(ssize);

  // Initializes the constraint triggered array
  constraints_trigged_.resize(ssize);
  psum_costs_.resize(ssize, 0);

  // Auxiliary array used to populate the best_costs_ array 
  std::vector<std::vector<oid_t> > _cons_trig_id(ssize);
  best_costs_.resize(ssize, 0);
  std::vector<oid_t> vars_id = aux_vars; // include the boundary variable
  std::vector<oid_t> union_cons;

  // Retrieves all constraints which involve exclusively the variable 
  // extracted at level i, it intersects them with the constraints given 
  // as parameter (currently in the store) and removes those constrains 
  // which were already consisdered in some previous level.
  // Note the boundary variables are to be included in every level as 
  // the shared constraints B_i - P_i need to be evaluated by this search.
  for (int i=0; i<ssize; ++i)
  {
    vars_id.push_back(scopeAt( i ).id());
    std::vector<oid_t> cons = ConstraintUtils::involvingExclusively( vars_id );
    Utils::intersect_emplace(cons, c_store);
    Utils::exclude_emplace(union_cons, cons);   // remove union_cons from cons
    
    for (oid_t c : cons) {
      constraints_trigged_[ i ].push_back( Utils::findIdx(c_store, c) );
      _cons_trig_id[ i ].push_back( c );
    }
    Utils::merge_emplace(union_cons, cons);
  }

  // Init Best Costs:
  // best_costs_[ i ] =  \sum_{c \in Ti} best_cost( c )
  // where Ti = cup_{j=i+1..n} constraints_trigged_[ j ]
  int i = ssize;
  while (--i >= 0)
  {
    best_costs_[ i ] = ((i+1) < ssize) ? best_costs_[ i+1 ] : 0;
    if ((i+1) == ssize)
      continue; // skip last level
    
    for (Constraint* c : g_dcop->constraints(_cons_trig_id[ i + 1 ]) ) {
      ExtSoftConstraint* esc = dynamic_cast<ExtSoftConstraint*>(c);
      best_costs_[ i ] += esc->bestCost();
    }
  }

}


void BranchAndBound::initialize(vector<IntVariable*> scope, vector<Constraint*> c_store,
std::vector<IntVariable*> aux_vars)
{
  ASSERT(false, "TODO: this need to be fixed!");
}


void BranchAndBound::setInitialAssignment(vector<int> initial_assignment)
{
  vector<IntVariable*> tmp;
  zero_level_ = 0;

  for (int i=0; i<initial_assignment.size(); ++i)
  {
    int val = initial_assignment[ i ];
    if (Constants::isFinite( val ))
    {
      Domain::EventType dom_event = scope_[ i ]->enforceAssignment( val );
      if (dom_event == Domain::kFailed) 
        { search_failed_ = true; return; }

      // insert scope element assigned in the front of the vector
      tmp.insert( tmp.begin() + zero_level_, scope_[ i ] );
      trail_pt_[ zero_level_ ] = search_stack_.size(); 
      ++zero_level_; 
    }
    else
      // insert scope element not assigned in the back of the vector
      tmp.push_back( scope_[ i ] );
  }
  scope_.swap( tmp );
  curr_level_ = zero_level_;

  // Update partial states in current and best solutions. 
  for (int i=0; i<zero_level_; ++i)
    curr_solution_[ i ] = best_solution_[ i ] = 
      scopeAt(i).value();
}


void BranchAndBound::setAuxiliaryVarsAssignment(std::vector<int> assignment)
{
  if(scope_.empty()) return;
  
  ASSERT(auxiliary_vars_.size() == assignment.size(), "Error in initializing \
    the auxiliary variables.");
  for (int i=0; i<assignment.size(); ++i)
  {
    // Domain::EventType dom_event =
    //   scope_[ i ]->enforceAssignment( assignment[ i ] );
    // if (dom_event == Domain::kFailed)
    //   { search_failed_ = true; return; }
    Domain::EventType dom_event =
      auxiliary_vars_[ i ]->silentAssignment( assignment[ i ] );
  }
}


bool BranchAndBound::nextSolution() 
{
  ASSERT(false, "TODO");

  search_failed_ = false;
  search_ended_  = false;  
				   
  // check wheter the scope of the search is empty
  if( size() == zero_level_ )
    { search_ended_ = true; return true; } 

  curr_solution_.reset();

  bool find_sol = iSearchStep();

  // When the search ends, it retores the variable states, which were 
  // held before the first propagation.
  if (search_ended_)
    search_stack_.restore( 0 );

  return find_sol;
}


bool BranchAndBound::bestSolution() 
{
  search_failed_ = false;
  search_ended_  = false;

  search_stack_.restore( 0 );

  // check wheter the scope of the search is empty
  if( size() == zero_level_ )
  { 
    search_ended_ = true; 
    best_solution_.setCost( 0 );
    return true; 
  } 

  curr_level_ = zero_level_;
  best_bound_ = Constants::worstvalue;
  curr_bound_ = 0;
  best_solution_.reset();
 
  // Search Best Solution
  rSearch();
  search_ended_ = true;
  return (Constants::isFinite( best_solution_.cost() ));
}


bool BranchAndBound::allSolutions()
{
  ASSERT(false, "TODO");

  search_failed_ = false;
  search_ended_  = false;

  search_stack_.restore( 0 );

  // check wheter the scope of the search is empty
  if( size() == zero_level_ )
    { search_ended_ = true; return true; } 
 
  curr_level_ = zero_level_;
  curr_solution_.reset();

  while (!search_ended_) {
    iSearchStep();
    solutions_.push_back( curr_solution_ );
  }

  return (not solutions_.empty());
}



// private
bool BranchAndBound::rSearch()
{
  if (curr_level_ == size()) {
    return processSolution();
  }
  
  size_t trail_pt = search_stack_.size();

  IntVariable& var = nextVariable();
  int val = var.domain().min() - 1; 
    
  while (labeling( var, val ))
  {
    // std::cout << "lev[ " << curr_level_ << "] trail_top: "
    //           << trail_pt << "/" << search_stack_.size()
    //           << " var: " << var.name() << " (" << val << ") :";

    p_soft_consistency->setQueue( constraints_trigged_[ curr_level_ ] );

    // std::cout << "C: " << Utils::dump(constraints_trigged_[ curr_level_ ]) << " ";

    if (p_soft_consistency->enforceConsistency())
    {
      // update current cost:
      curr_bound_ += p_soft_consistency->cost();
      psum_costs_[ curr_level_ ] = p_soft_consistency->cost();
      
      // std::cout << psum_costs_[ curr_level_ ] << " bound: "
      //     << curr_bound_ << "("
      //     << curr_bound_ + best_costs_[ curr_level_ ] << ")"
      //     << " / " << best_bound_ << std::endl;

      if (Utils::isBetter(curr_bound_ + best_costs_[ curr_level_ ], best_bound_))
      {
        ++curr_level_; 
        rSearch(); 
        --curr_level_; 
      }
      // else
      //   std::cout << "bound check failed (lev:" << curr_level_ << ")\n";

      curr_bound_ -= psum_costs_[ curr_level_ ];
    }
    // else
    //   std::cout << "Infeasible assignment - backtrack (lev:" << curr_level_ << ")\n";

    search_stack_.restore(trail_pt);
  }
  return true;
}


// private
bool BranchAndBound::iSearchStep( )
{
  ASSERT(false, "TODO");

  // Restore to previous last level if coming form a solution.
  if( curr_level_ == size() )
    search_stack_.restore( trail_pt_[ --curr_level_] );

  while (curr_level_ >= zero_level_)
  {
    IntVariable& var = nextVariable();
    int val = var.lastChoice(); 
    trail_pt_[ curr_level_ ] = search_stack_.size();    
    
    if (labeling(var, val))
    {
      // @todo -  Compute partial cost and check bounds. 
      if (++curr_level_ == size()) {
        bool sol = processSolution();
        // Restore to previous level
        if (sol) return true;
        search_stack_.restore( trail_pt_[ --curr_level_] );
      }
    }
    else {
      --curr_level_;
      if (curr_level_ >= zero_level_) {
        search_stack_.restore( trail_pt_[curr_level_] );
      }
    }
  }

  search_ended_ = true;		// Flag search termination
  curr_level_ = zero_level_; 	// Reset currLevel counter
  return false; 		// All domains are now emtpy
}


bool BranchAndBound::labeling(IntVariable& var, int& val)
{
#ifdef VERBOSE_TIMEOUT
  // This need to be sobstituited by an OBSERVER PATTERN
  owner().statistics().setSimulatedTime(owner().statistics().stopwatch()); 
  owner().checkOutOfLimits();
  owner().statistics().setStartTimer();
#endif

  int next = var.domain().nextValue(val);
  if (next == val) {		// No more values to label
    var.resetLastChoice();
    return false;
  }

  val = next;			// set the returning value
  return (var.enforceAssignment( val ) != Domain::kFailed);
}



IntVariable& BranchAndBound::nextVariable()
{
  //while (scopeAt(curr_level_).isSingleton());
  return scopeAt(curr_level_);
}


bool BranchAndBound::processSolution()
{
  // Consistency already enforced during search
  saveSolution();
  curr_solution_.setCost( curr_bound_ );

  // This will always happen at this point
  // update best solution if necessary
  // if (curr_solution_.betterThan( best_solution_ )){
  best_solution_ = curr_solution_;
  best_bound_ = curr_bound_;
  // }
  // cout << curr_solution_.dump() << endl;
  return true;
}


string BranchAndBound::dump() const
{
  string result = "Search[Branch&Bound]: ( ";
  for (auto &i : scope_)
    result += i->name() + ", ";
  result += ") - ";
  result += p_soft_consistency->dump();
  return result;
}
