#ifndef _ULYSSES__SEARCHENGINES__SEARCH_ENGINE_H_
#define _ULYSSES__SEARCHENGINES__SEARCH_ENGINE_H_

#include <memory>
#include <vector>
#include <string>

#include "Kernel/object-info.hh"
#include "SearchEngines/solution.hh"
#include "Utilities/utils.hh"

class IntVariable;
class Constraint;
class Agent;

// The DCOP Abstract Search Engine class.
// This is an abstract search engine, whose implementations are used to explore
// the value assignemnts for a subset of variables of a given Agent.
class SearchEngine : public ObjectInfo
{
public:
  typedef std::unique_ptr<SearchEngine> uptr;
  typedef std::shared_ptr<SearchEngine> sptr;

  SearchEngine(Agent& owner);

  virtual ~SearchEngine();

  // It initializes the data-structures used by the search engine during 
  // solution search. 
  //
  // @param scope The variable IDs for which an assignment is sought. If empty then 
  //     'vars' is used as scope of the search 
  // @param cons The constraint IDs taken into account during solution search.
  // @param aux_vars The vector of auxiliary variables for the search
  virtual void initialize( std::vector<oid_t> scope, std::vector<oid_t> cons,
			   std::vector<oid_t> aux_vars=std::vector<oid_t>() ) = 0;

  virtual void initialize( std::vector<IntVariable*> scope, std::vector<Constraint*> cons,
			   std::vector<IntVariable*> aux_vars=std::vector<IntVariable*>() ) = 0;
  
  // It sets the initial value assignment for the variables in the search
  // scope, and order the search scope so that the variables assigned are
  // listed as first.
  //
  // @param initial_assignment An assignment for all the variable in the 
  //        search scope, in order. NaN Values are ignored.
  virtual void setInitialAssignment(std::vector<int> initial_assignment 
				    = std::vector<int>()) = 0;

  // Sets the auxiliary variables initial assignment
  virtual void setAuxiliaryVarsAssignment(std::vector<int> assignment = 
					  std::vector<int>()) = 0;

  // Restore the auxiliary variables to the previous valeues (bounds).
  virtual void unsetAuxiliaryVarsAssignment();
  
  // It resets search state.
  virtual void reset() = 0;

  // It finds the next satisfiable solution in the given enumeration 
  // of the solution space.
  virtual bool nextSolution() = 0;
  
  // It finds the assignment to the variables in scope which optimizes
  // the local cost.
  virtual bool bestSolution() = 0;
  
  // It finds all possible satisfiable solutions.
  virtual bool allSolutions() = 0;

  // Simplify the CSP by calling the Consistency function 
  // proper of the search engine.
  virtual bool reduce() 
  { 
    return true;
  };

  // It returns the last solution found. 
  virtual Solution& getSolution()
  {
    return curr_solution_;
  }
  
  // It returns the best solution found. 
  virtual Solution& getBestSolution()
  {
    return best_solution_;
  }

  // Returns all the solutions found.
  std::vector<Solution>& getAllSolutions()
  { 
    return solutions_; 
  }

  // It indicates whether the search is terminated. 
  bool isTerminated() const
  {
    return search_ended_;
  }

  // It indicates whether the search could not find any feasible assignment.
  bool isFailed() const
  {
    return search_failed_;
  }

  // It returns the scope of the search.
  std::vector<IntVariable*>& scope()
  {
    return scope_;
  }

  // It returns the i-th variable of the search scope.
  IntVariable& scopeAt(int i)
  {
    return *scope_[ i ];
  }
 
  // It returns the size of the search scope.
  size_t size() const
  {
    return scope_.size();
  }
  
  // Copies the current solution to the best solution if the former
  // cost is better than the current best.
  void updateBestSolution()
  {
    if (Utils::isBetter(curr_solution_.cost(), best_solution_.cost()))
	best_solution_ = curr_solution_;
  }

  virtual std::string dump() const = 0;
 
  // It returns the agent on which this search engine is running.
  Agent& owner() const
  {
    return *p_owner;
  }
    
protected:
  // The scope of the search.
  std::vector<IntVariable*> scope_;

  // The list of auxiliary variables
  std::vector<IntVariable*> auxiliary_vars_;
  
  // The previous state of the auxiliary variables, stored when assigning them.
  std::vector<std::pair<int,int> > state_auxiliary_vars_;

  // The set of solutions found. Saved only when the option to return all 
  // the solutions generated is selected.
  std::vector<Solution> solutions_; 

  // The last solution found.
  Solution curr_solution_;

  // The best solution found.
  Solution best_solution_;

  // It signals whether the search has ended.
  bool search_ended_;

  // It signals whether the search could not find any feasible solution.
  bool search_failed_;
  
  // The agent executing this consistency manager.
  // It is used to record Statistics infomation
  Agent* p_owner;
};

#endif  // _ULYSSES__SEARCH_ENGINE__SEARCH_ENGINE_H_
