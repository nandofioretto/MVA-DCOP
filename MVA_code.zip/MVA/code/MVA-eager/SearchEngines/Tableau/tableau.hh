#ifndef _ULYSSES__SEARCHENGINES__TABLEAU__TABLEAU_H_
#define _ULYSSES__SEARCHENGINES__TABLEAU__TABLEAU_H_

#include "Kernel/globals.hh"
#include "SearchEngines/DepthFirstSearch/depth-first-search.hh"

#include <algorithm>

class IntVariable;
class Constraint;
class Solution;
class Agent;

// A DFS search engine.
// Implements a DFS on the set of variables assigned as scope of the search.
class Tableau : public DepthFirstSearch
{
public:
  Tableau(Agent& owner);
    
  ~Tableau();
  
  // It voids the initalization of the searchEngine
  virtual void initialize(std::vector<oid_t> scope, 
                          std::vector<oid_t> cons,
			  std::vector<oid_t> aux_vars=std::vector<oid_t>())
  { 
    DepthFirstSearch::initialize(scope, cons, aux_vars);
    DepthFirstSearch::allSolutions();
    owner().statistics().incrNCCCs(solutions_.size());
    owner().statistics().incrUsedMemory(solutions_.size() * scope.size() * sizeof(int) + sizeof(cost_t));
    reset();
  }
  
  // It voids the initalization of the searchEngine
  virtual void initialize(std::vector<IntVariable*> scope, 
                          std::vector<Constraint*> cons,
			  std::vector<IntVariable*> aux_vars=std::vector<IntVariable*>() )
  { 
    DepthFirstSearch::initialize(scope, cons, aux_vars);
    DepthFirstSearch::allSolutions();
    owner().statistics().incrNCCCs(solutions_.size());
    owner().statistics().incrUsedMemory(solutions_.size() * scope.size() * sizeof(int) + sizeof(cost_t));
    reset();
  }

  // It sets the initial value assignment for the variables in the search
  // scope, and order the search scope so that the variables assigned are
  // listed as first.
  //
  // @param initial_assignment An assignment for all the variable in the 
  //        search scope, in order. Values of type kNan are ignored.
  virtual void setInitialAssignment(std::vector<int> initial_assignment= std::vector<int>())
  { 
    ASSERT(false, "Should not be called.");
  }
  
  
  // Sets the auxiliary variables initial assignment
  virtual void setAuxiliaryVarsAssignment(std::vector<int> assignment=std::vector<int>())
  { 
    ASSERT(false, "Should not be called.");
  }
  
  // It resets search state.
  virtual void reset()
  {
    p_index = 0;
    search_ended_ = false;
  }

  // It increase the index to get the next solution stored in the solution
  // table. It returns false if such operation was not possible
  virtual bool nextSolution()
  {
    owner().statistics().incrNCCCs();
    search_ended_ = false;
    if( (p_index+1) >= solutions_.size() ) {
      p_index = 0;
      search_ended_ = true;
      return false; 
    }
    //p_index++;
    curr_solution_ = solutions_[ p_index++ ];
    return true;
  }
  
  // It finds the assignment to the variables in scope which optimizes
  // the local cost.
  virtual bool bestSolution()
    { return Constants::isFinite(best_solution_.cost()); }

  // It finds all possible satisfiable solutions.
  virtual bool allSolutions()
  { return (!solutions_.empty()); }

  // Returns the solution associated to the p_index
  // virtual Solution& getSolution()
  // {
  //   return solutions_[ p_index ];
  // }

  virtual std::string dump() const;

private:
  // The index associated to the solution table.
  size_t p_index;
  
};

#endif // _ULYSSES__SEARCHENGINES__TABLEAU__TABLEAU_H_
