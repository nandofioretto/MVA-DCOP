#include "SearchEngines/Tableau/tableau.hh"

Tableau::Tableau(Agent& owner)
  : DepthFirstSearch(owner), p_index(0)
{ 
  search_ended_ = false;
}


Tableau::~Tableau()
{ }


std::string Tableau::dump() const
{
  std::string result = "Search[Tableau]: ( ";
  for (auto &i : scope_)
    result += i->name() + ", ";
  result += ") - ";
  result += "curr index: " + std::to_string(p_index);
  result += " / " + std::to_string(solutions_.size());
  return result;
}
