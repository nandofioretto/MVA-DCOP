#ifndef _ULYSSES__SEARCHENGINES__SAMPLING__GIBBS__GIBBS_SAMPLING_H_
#define _ULYSSES__SEARCHENGINES__SAMPLING__GIBBS__GIBBS_SAMPLING_H_

#include "Kernel/globals.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/soft-consistency.hh"
#include "SearchEngines/search-engine.hh"
#include "SearchEngines/solution.hh"

#include <algorithm>
#include <random>
#include <functional>

class IntVariable;
class Constraint;
class Solution;
class Agent;

// A Gibbs Sampler. A Markov Chain Monte Carlo method which approximate the joint 
// probability distribution describing the solution space defined over the 
// variables in the search scope.
//
// DISCLAIMER: Works only with bound domains!!
class GibbsSampling : public SearchEngine
{
public:
  GibbsSampling(Agent& owner, size_t nb_seeds=1, size_t max_iterations=100);
    
  ~GibbsSampling();
    
  // It initializes the data-structures used by the search engine during 
  // solution search. 
  //
  // @param scope The variables ID for which an assignment is sought.
  // @param cons The constraints ID taken into account during solution search.
  // @param aux_vars The vector of auxiliary variables for the search
  virtual void initialize( std::vector<oid_t> scope, std::vector<oid_t> cons,
			   std::vector<oid_t> aux_vars=std::vector<oid_t>() );

  virtual void initialize(std::vector<IntVariable*> scope, std::vector<Constraint*> c_store,
			  std::vector<IntVariable*> aux_vars);

  // It sets the initial value assignment for the variables in the search
  // scope, and order the search scope so that the variables assigned are
  // listed as first.
  //
  // @param initial_assignment An assignment for all the variable in the 
  //        search scope, in order. Values of type kNan are ignored.
  virtual void setInitialAssignment(std::vector<int> initial_assignment 
				    = std::vector<int>());

  // Sets the auxiliary variables initial assignment
  virtual void setAuxiliaryVarsAssignment(std::vector<int> assignment = 
					  std::vector<int>());

  // Do nothing while unsetting the auxiliary variables assignments as they 
  // are not actually assigned by merely copied in some local store.
  virtual void unsetAuxiliaryVarsAssignment()
    { }
  
  // It resets search state.
  virtual void reset()
  {
    zero_level_ = 0;
  }

  // It finds the next satisfiable solution in the given enumeration 
  // of the solution space.
  virtual bool nextSolution();
  
  // It finds the assignment to the variables in scope which optimizes
  // the local cost.
  virtual bool bestSolution();

  // It finds all possible satisfiable solutions.
  virtual bool allSolutions();
    
  virtual std::string dump() const;

  virtual void setZeroLevel(int lev)
  {
    zero_level_ = lev;
  }

  virtual void setParams(size_t nb_seeds, size_t max_iters) 
  {
    nb_seeds_ = nb_seeds;
    max_iterations_ = max_iters;
  }


private:
  // Sets the intial random assignment for the variables in scope
  void setRandomAssignment();

  // Performs one iteration of the Gibbs sampling process .
  bool sample();
     
  // It sets the best solution as the current sample assignment.
  void saveBestSolution( cost_t new_cost )
  {
    for (int i=0; i<size(); ++i)
      best_solution_[ i ] = sample_[ i + zero_level_ ];
    best_solution_.setCost( new_cost );
  }
    
  // It sets the current solution as the current assignment.
  void saveSolution( cost_t new_cost )
  {
    for (int i=0; i<size(); ++i)
      curr_solution_[ i ] = sample_[ i + zero_level_ ];
    curr_solution_.setCost( new_cost );
  }
  
  
protected:
  // The current sample being produced via the Gibbs Sampler
  std::vector<int> sample_;

  // The vector of best costs (one for each
  std::vector<cost_t> best_costs_;

  // The domain size of all the variables in Boundary and Private
  std::vector<int> domain_size_;

  // The vector of the probabilities associated to each element of the domain 
  // of the variables in scope -- examined one at a time.
  std::vector<double> prob_;

  // The list of pairs <min, max> of each domain of the variables in scope of the search 
  std::vector< std::pair<int,int> > domain_val_;

  // The i-th vector contains the list of constraints which can be activated 
  // exclusively with i-th variables of the scope
  std::vector<std::vector<int> > constraints_trigged_;

  // The uniform distribution associate to each variable in the search scope,
  // used to generate the initial random assignment.
  std::vector< std::uniform_int_distribution<int> > uniform_distr_var_;

  // The starting level of the search - it holds the size of the variables
  // already assigned before performing this search.  //
  // @note: such variables are listed first in the search scope.  
  int zero_level_;

  // The generators of the random distributions  
  std::unique_ptr<std::default_random_engine> generator_;

  // Number of different initial random assignments to generate during the sampling process;
  size_t nb_seeds_;

  // Number of maximum iterations of the sampling process
  size_t max_iterations_;


  // The soft consistency manager.
  SoftConsistency::uptr p_soft_consistency;

};

#endif // _ULYSSES__SEARCHENGINES__SAMPLING__GIBBS__GIBBS_SAMPLING_H_
