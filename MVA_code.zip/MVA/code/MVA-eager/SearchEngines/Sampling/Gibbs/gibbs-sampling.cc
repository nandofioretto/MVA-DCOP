#include "Kernel/globals.hh"
#include "Utilities/utils.hh"
#include "SearchEngines/Sampling/Gibbs/gibbs-sampling.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Domains/int-domain.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Constraints/ext-soft-constraint.hh"

#include "Problem/dcop-instance.hh"

#include <chrono>
#include <random>
#include <functional>

//#define DBG
#define DISCOUNT_NCCCs
//#define TABLEAU

using namespace std;


GibbsSampling::GibbsSampling(Agent& owner, size_t nb_seeds, size_t max_iterations)
  : SearchEngine(owner),  
zero_level_(0), nb_seeds_(nb_seeds), max_iterations_(max_iterations)
{ 
  p_soft_consistency = SoftConsistency::uptr(new SoftConsistency(owner));
}


GibbsSampling::~GibbsSampling()
  { }


// to be congruent with the other assignments you should only act on private 
// variables. You could modify the variables directly (their domains, by really
// assigning them).
void GibbsSampling::initialize(vector<oid_t> scope, vector<oid_t> c_store, 
  std::vector<oid_t> aux_vars)
{
  // Initializes the scope and solutions of the search
  scope_ = g_dcop->variables( scope ); // SCOPE A.K.A. private_variables
  if(!aux_vars.empty()) 
  {
    auxiliary_vars_ = g_dcop->variables( aux_vars );
    state_auxiliary_vars_.resize(aux_vars.size());
    for(int i=0; i<auxiliary_vars_.size(); ++i)
      state_auxiliary_vars_[ i ] =
        std::make_pair(auxiliary_vars_[ i ]->min(), auxiliary_vars_[ i ]->max());
  }
  
  zero_level_ = aux_vars.size();
  p_soft_consistency->initialize(Utils::concat(aux_vars, scope), c_store);
  
  // Initializes The solution Vectors:
  best_solution_.initialize(scope_.size()); // Need to contain only private  
  curr_solution_.initialize(scope_.size()); // Need to contain only private   
  sample_.resize( aux_vars.size() + scope.size(), 0);
  best_costs_.resize( scope.size() , Constants::worstvalue);

  int max_d_size = 0;
  // Only scope of private variable needed!!
  domain_size_.resize( scope.size(), 0);
  domain_val_.resize( scope.size());
  constraints_trigged_.resize(scope.size());
  
  std::vector<oid_t> sing(1);
  for(int i=0; i<scope.size(); ++i)
  {
    IntVariable& v = *scope_[ i ];
        
    ASSERT( v.domain().type() == IntDomain::kBound, 
    "Sorry, the current version of Gibbs sampling works only with bound domains\n");
    // Note: this contains values and not domain labels! 
    domain_val_[ i ] = std::make_pair(v.min(), v.max());
    domain_size_[ i ] = v.size();
    max_d_size = std::max( max_d_size, domain_size_[ i ] );
    uniform_distr_var_.push_back(std::uniform_int_distribution<int>(v.min(), v.max()));
  
    // Retrieves all local constraints which involve the variable scope[i] 
    for (int j = 0; j < v.nbConstraints(Constraint::kExtSoft); ++j) 
    {
      oid_t cid = v.extSoftConstraintAt(j).id();
      int idx = Utils::findIdx(c_store, cid);
      if (idx >= 0)
        constraints_trigged_[ i ].push_back( idx );
    }
  }
  prob_.resize( max_d_size, 0 );
  
  // Set the generator for the random distributions
  unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
  generator_ = std::unique_ptr<std::default_random_engine>(new std::default_random_engine(seed));

  // Random assignment (reset assignment on Private vars)
  setRandomAssignment();
}


void GibbsSampling::initialize(vector<IntVariable*> scope, 
vector<Constraint*> c_store, std::vector<IntVariable*> aux_vars)
{
  ASSERT(false, "TODO: this need to be fixed!");
}


void GibbsSampling::setAuxiliaryVarsAssignment(std::vector<int> assignment)
{
  if(scope_.empty()) return;
  
  ASSERT(assignment.size() == zero_level_, "Error in setting auxiliary var \
    assignment: arrays zero_level and assignments have different dimensions.");
  for (int i=0; i<zero_level_; ++i)
    sample_[ i ] = assignment[ i ];
}


void GibbsSampling::setInitialAssignment(vector<int> assignment)
{
  ASSERT(assignment.size() == scope_.size(), "Error in setting scope var \
    assignment: wrong assignment size.");
  
  for (int i=0; i<assignment.size(); ++i) {
    curr_solution_[ i ] = best_solution_[ i ] = sample_[ i + zero_level_ ] 
      = assignment[ i ];
  }
}


bool GibbsSampling::nextSolution() 
{
  search_failed_ = false;
  search_ended_  = false;  

  best_solution_.reset();
  std::fill(best_costs_.begin(), best_costs_.end(), Constants::worstvalue);

  // check wheter the scope of the search is empty
  if( size() == (auxiliary_vars_.size() - zero_level_) )
  { 
    search_ended_ = true;
    // curr_solution_.setCost( 0 );
    return true; 
  } 
  
  for (int iter = 0; iter < max_iterations_; ++iter) {
    if( sample() ) break;  // converged
  }
  
// int iter = 0;
//   do {
//     // std::cout << "=====================================\n";
//     // std::cout << "               SAMPLE                \n";
//     sample();
//     // std::cout << "=====================================\n";
//   } while (!Constants::isFinite( curr_solution_.cost() )
//     || (++iter < max_iterations_));
//
  curr_solution_ = best_solution_;
  return (Constants::isFinite( curr_solution_.cost() ));
}


bool GibbsSampling::allSolutions()
{
  ASSERT(false, "Not Applicable");
}


bool GibbsSampling::bestSolution() 
{
  search_failed_ = false;
  search_ended_  = false;
  
  // check wheter the scope of the search is empty
  if( size() == (auxiliary_vars_.size() - zero_level_) )
  { 
    search_ended_ = true; 
    best_solution_.setCost( 0 );
    return true; 
  } 
  
  best_solution_.reset();
  std::fill(best_costs_.begin(), best_costs_.end(), Constants::worstvalue);
  
  // Search Best Solution
  for (int seed = 0; seed < nb_seeds_; ++seed)
  {
    // Random assignment (reset assignment on Private vars)
    setRandomAssignment();

    for (int iter = 0; iter < max_iterations_; ++iter) 
    {
      //std::cout << "Staring sample #" << iter << "\n";
      sample();
      //getchar();
#ifdef VERBOSE_TIMEOUT
      // This need to be sobstituited by an OBSERVER PATTERN
      owner().statistics().setSimulatedTime(owner().statistics().stopwatch()); 
      owner().checkOutOfLimits();
      owner().statistics().setStartTimer();
#endif
    }
  }
  search_ended_ = true;
  return (Constants::isFinite( best_solution_.cost() ));
}


void GibbsSampling::setRandomAssignment()
{
  for (int i=0; i<scope_.size(); ++i)
    sample_[ i + zero_level_ ] = uniform_distr_var_[ i ](*generator_);
}


bool GibbsSampling::sample()
{  
  bool converged = false;//true;
  bool counted = false;
  size_t ncccs_counted_once = owner().statistics().NCCC();
    
  // Sample over variable P( xi | xi-1)
  for (int xi = 0; xi < scope_.size(); ++xi)
  {
    int count_pr_gt0 = 0;
    
   // std::cout << "var: " << xi + zero_level_ << ": " << Utils::dump(sample_);
   // std::cout << "\tcos: " << Utils::dump(constraints_trigged_[ xi ]) << std::endl;
   // std::cout << "D choices: ";
    
#ifdef DISCOUNT_NCCCs
    size_t ncccs_prior_prob_estimation = owner().statistics().NCCC();
#endif
    // Computes the discrete probabilities associated to the current state.
    p_soft_consistency->setQueue( constraints_trigged_[ xi ] );
    for (int d = 0; d < domain_size_[ xi ]; ++d)
    {
      sample_[ xi + zero_level_ ] = (d + domain_val_[ xi ].first);
      if (p_soft_consistency->enforceConsistency( sample_ )){
        prob_[ d ] = DCOPinfo::maximize() ? (double)p_soft_consistency->cost()
          : 1 / (double)p_soft_consistency->cost();
        ++count_pr_gt0;
      }
      else{
        prob_[ d ] = 0.0;
      }
      // std::cout << d + domain_val_[ xi ].first << "(" << prob_[ d ] << ")\n";
    }
    // getchar();
#ifdef DISCOUNT_NCCCs
    owner().statistics().setNCCC(ncccs_prior_prob_estimation);
#endif
    
    // Check convergence conditions:
    // If there is no positive probability then the sample is unsatisfactory.
    // If there is a unique value gt0, then the sample has converged.
    //if(count_pr_gt0 == 0) {best_solution_.reset(); return true;} // FAILED
    // if(count_pr_gt0 > 1) converged = false;
    
    // Samples the current state: chooses a value for x, based on prob. P
    std::discrete_distribution<int> distr(prob_.begin(), prob_.end());

    // std::cout << "xi : " << xi << " prob: "
    //            << Utils::dump(distr.probabilities()) << std::endl;
    
    int val_idx = distr(*generator_);		    // index in the domain of xi
    int xi_val = domain_val_[ xi ].first + val_idx; // Dom.min + val_choice

    // std::cout << "choosen: " << xi_val << std::endl;
    
    sample_[ xi + zero_level_ ] = xi_val;

    // If tableau is defined, it computes the boundary solution cost as if it were tabled.
#ifdef TABLEAU
    size_t ncccs_prior_consistency = owner().statistics().NCCC();
    owner().statistics().setSimulatedTime(owner().statistics().stopwatch());
#endif
    // Compute Solution Cost
    p_soft_consistency->setQueue();
    if (!p_soft_consistency->enforceConsistency( sample_ ))
      continue;
    cost_t curr_cost = p_soft_consistency->cost();
    // std::cout << Utils::dump(sample_) << " : " << curr_cost << std::endl;

#ifdef DISCOUNT_NCCCs
    if( !counted ) {
       ncccs_counted_once = owner().statistics().NCCC();
       counted = true;
     }
#endif

#ifdef TABLEAU
    owner().statistics().setNCCC(ncccs_prior_consistency);
    owner().statistics().incrNCCCs();
    owner().statistics().setStartTimer();
#endif

    
    // Save Best
    if(Utils::isBetter(curr_cost, best_costs_[ xi ])) 
    {
      saveBestSolution( curr_cost );
      best_costs_[ xi ] = curr_cost;
    } 
  }
  owner().statistics().setNCCC(ncccs_counted_once);

  return converged;
}


string GibbsSampling::dump() const
{
  string result = "Search[Gibbs Sampling]: ( ";
  for (auto &i : scope_)
    result += i->name() + ", ";
  result += ") - axu: vars: (";
  for (auto &i : auxiliary_vars_)
    result += i->name() + ", ";
  result += ") - ";
  result += p_soft_consistency->dump();
  result += "\t curr sample: " + Utils::dump(sample_);
  // print aux variables
  return result;
}
