#ifndef ULYSSES_KERNEL__SEARCH_ENGINES__SEARCH_ENGINE_FACTORY_H_
#define ULYSSES_KERNEL__SEARCH_ENGINES__SEARCH_ENGINE_FACTORY_H_

#include "Kernel/globals.hh"
#include "SearchEngines/DepthFirstSearch/depth-first-search.hh"
#include "SearchEngines/BranchAndBound/branch-and-bound.hh"
#include "SearchEngines/Sampling/Gibbs/gibbs-sampling.hh"
#include "SearchEngines/Tableau/tableau.hh"

#include <string>
#include <map>
#include <vector>

class SearchEngine;
class Agent;

class SearchEngineFactory
{
public:
  static SearchEngine* create(Agent& owner, std::string type,
  std::vector<std::string> params = std::vector<std::string>() );  

  static SearchEngine* get(oid_t id)
  {
    return mapId2Ptr_[ id ];
  }

private:
  SearchEngineFactory() { }
  DISALLOW_COPY_AND_ASSIGN(SearchEngineFactory);

  // Maps agent IDs to (private) solvers (search englines).
  static std::map<oid_t, SearchEngine*> mapId2Ptr_;

};

#endif // ULYSSES_KERNEL__SEARCH_ENGINES__SEARCH_ENGINE_FACTORY_H_
