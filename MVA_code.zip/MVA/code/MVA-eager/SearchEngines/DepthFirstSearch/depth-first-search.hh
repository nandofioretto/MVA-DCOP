#ifndef _ULYSSES__SEARCHENGINES__DEPTHFIRSTSEARCH__DEPTH_FIRST_SEARCH_H_
#define _ULYSSES__SEARCHENGINES__DEPTHFIRSTSEARCH__DEPTH_FIRST_SEARCH_H_

#include "Kernel/globals.hh"
#include "Kernel/Stores/search-stack.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/soft-consistency.hh"
#include "SearchEngines/search-engine.hh"
#include "SearchEngines/solution.hh"

#include <algorithm>

class IntVariable;
class Constraint;
class Solution;
class Agent;

// A DFS search engine.
// Implements a DFS on the set of variables assigned as scope of the search.
class DepthFirstSearch : public SearchEngine
{
public:
  DepthFirstSearch(Agent& owner);
    
  ~DepthFirstSearch();
    
  // It initializes the data-structures used by the search engine during 
  // solution search. 
  //
  // @param scope The variable IDs for which an assignment is sought. If empty then 
  //     'vars' is used as scope of the search 
  // @param cons The constraint IDs taken into account during solution search.
  // @param aux_vars The vector of auxiliary variables for the search
  virtual void initialize( std::vector<oid_t> scope, std::vector<oid_t> cons,
			   std::vector<oid_t> aux_vars=std::vector<oid_t>() );

  virtual void initialize( std::vector<IntVariable*> scope, std::vector<Constraint*> cons,
			   std::vector<IntVariable*> aux_vars=std::vector<IntVariable*>() );

  // It sets the initial value assignment for the variables in the search
  // scope, and order the search scope so that the variables assigned are
  // listed as first.
  //
  // @param initial_assignment An assignment for all the variable in the 
  //        search scope, in order. Values of type kNan are ignored.
  virtual void setInitialAssignment(std::vector<int> initial_assignment 
				    = std::vector<int>());
  
  
  // Sets the auxiliary variables initial assignment
  virtual void setAuxiliaryVarsAssignment(std::vector<int> assignment = 
					  std::vector<int>());

  // It resets search state.
  virtual void reset()
  {
    if(!search_ended_)
    {
      curr_level_ = 0; zero_level_ = 0;
      search_stack_.restore( 0 );
      std::fill(trail_pt_.begin(), trail_pt_.end(), 0);
      for(IntVariable* v : scope_)
        v->resetLastChoice();
    }
  }

  // It finds the next satisfiable solution in the given enumeration 
  // of the solution space.
  // It sets the search_ended_ flag to true only if there are no 
  // more solutions to be returned (last solution already returned).
  virtual bool nextSolution();
  
  // It finds the assignment to the variables in scope which optimizes
  // the local cost.
  virtual bool bestSolution();

  // It finds all possible satisfiable solutions.
  virtual bool allSolutions();

  // It returns the last solution found. 
  virtual Solution& getSolution()
  {
    return curr_solution_;
  }
  
  // It returns the best solution found. 
  virtual Solution& getBestSolution()
  {
    return best_solution_;
  }

  // It simplifies the CSP by calling the Consistency function 
  // proper of the search engine.
  virtual bool reduce()
  {
    return true;
  }
    
  virtual std::string dump() const;

  void setZeroLevel(int lev)
  {
    zero_level_ = lev;
  }

protected:
  // It returns the next variable to be assigned, given a specified variable
  // ordering. 
  // The default ordering is leftmost.
  virtual IntVariable& nextVariable();

  // Performs a labeling on variable associated to currLevel 
  // 
  // @param var The variable to be assigned
  // @param val The previous value assigned to var, and the new value assinged
  //        which is returned into it.
  // @return Whether the labeling step was possible.
  virtual bool labeling(IntVariable& var, int& val);


private:
  // A recursive search exploring the whole search space.
  bool rSearch();

  // An iterative search exploring one step (i.e., the next valid value 
  // assignment) of the whole search space.
  bool iSearchStep();
     
  // It sets the current solution as the current assignment.
  void saveSolution()
  {
    for (int i=zero_level_; i<size(); ++i)
      curr_solution_[ i ] = scopeAt(i).value();
  }
  
  bool processSolution();
  
  // deprecated
  int nb_assigned();

protected:
  // The current depth-level in the search tree exploration. 
  int curr_level_;
  
  // The starting level of the search - it holds the size of the variables
  // already assigned before performing this search.
  //
  // @note: such variables are listed first in the search scope.  
  int zero_level_;

  // Used to backtrack at the appropriate trailstack size.
  // trail_pt_[ i ] contains the trailstack size at the moment
  // when the search for level i started.
  std::vector<int> trail_pt_;
  // The last value 
  std::vector<int> last_value_;

  // The search stack 
  SearchStack search_stack_;

  // The soft consistency manager.
  SoftConsistency::uptr p_soft_consistency;

};

#endif // _ULYSSES__SEARCHENGINES__DEPTHFIRSTSEARCH__DEPTH_FIRST_SEARCH_H_
