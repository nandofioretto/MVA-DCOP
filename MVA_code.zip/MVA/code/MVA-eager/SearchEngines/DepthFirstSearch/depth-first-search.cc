#include "Kernel/globals.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "SearchEngines/DepthFirstSearch/depth-first-search.hh"
#include "Utilities/utils.hh"

#include "Problem/dcop-instance.hh"
//#define DBG

using namespace std;


DepthFirstSearch::DepthFirstSearch(Agent& owner) 
  : SearchEngine(owner), curr_level_(0), zero_level_(0)
{ 
  p_soft_consistency = SoftConsistency::uptr(new SoftConsistency(owner));
}


DepthFirstSearch::~DepthFirstSearch()
{ }


void DepthFirstSearch::initialize(vector<oid_t> scope, vector<oid_t> cons,
vector<oid_t> aux_vars)
{
  // Initializes the scope and solutions of the search
  scope_ = g_dcop->variables( scope );
  if(!aux_vars.empty()){
    auxiliary_vars_ = g_dcop->variables( aux_vars );
    state_auxiliary_vars_.resize(aux_vars.size());
    for(int i=0; i<auxiliary_vars_.size(); ++i)
    state_auxiliary_vars_[ i ] = std::make_pair(auxiliary_vars_[ i ]->min(),
      auxiliary_vars_[ i ]->max());
  }
  // Initializes the search stack
  for (IntVariable* v : scope_)
    search_stack_.registerRestorable( v );
  
  p_soft_consistency->initialize(g_dcop->constraints(cons));
  
  size_t ssize = scope_.size();
  trail_pt_.resize(ssize, 0);

  // Initializes The solution Vectors:
  curr_solution_.initialize(ssize);
  best_solution_.initialize(ssize);
}


void DepthFirstSearch::initialize(vector<IntVariable*> scope, vector<Constraint*> cons,
vector<IntVariable*> aux_vars)
{
  // Initializes the scope and solutions of the search
  scope_ = scope;
  if(!aux_vars.empty()){
    auxiliary_vars_ = aux_vars;    
    state_auxiliary_vars_.resize(aux_vars.size());
  }
  
  // Initializes the search stack
  for (IntVariable* v : scope_)
    search_stack_.registerRestorable( v );
  
  p_soft_consistency->initialize(cons);

  size_t ssize = scope_.size();
  trail_pt_.resize(ssize, 0);

  // Initializes The solution Vectors:
  curr_solution_.initialize(ssize);
  best_solution_.initialize(ssize);
}


void DepthFirstSearch::setInitialAssignment(vector<int> initial_assignment)
{
  vector<IntVariable*> tmp;
  zero_level_ = 0;

  for (int i=0; i<initial_assignment.size(); ++i)
  {
    int val = initial_assignment[ i ];
    if (Constants::isFinite( val ))
    {
      Domain::EventType dom_event = scope_[ i ]->enforceAssignment( val );
      if (dom_event == Domain::kFailed) 
        { search_failed_ = true; return; }

      // insert scope element assigned in the front of the vector
      tmp.insert( tmp.begin() + zero_level_, scope_[ i ] );
      trail_pt_[ zero_level_ ] = search_stack_.size(); 
      ++zero_level_; 
    }
    else
      // insert scope element not assigned in the back of the vector
      tmp.push_back( scope_[ i ] );
  }
  scope_.swap( tmp );
  curr_level_ = zero_level_;

  // Update partial states in current and best solutions. 
  for (int i=0; i<zero_level_; ++i)
    curr_solution_[ i ] = best_solution_[ i ] = 
      scopeAt(i).value();
}


void DepthFirstSearch::setAuxiliaryVarsAssignment(std::vector<int> assignment)
{
  if(scope_.empty()) return;
    
  ASSERT(auxiliary_vars_.size() == assignment.size(), "Error in initializing \
    the auxiliary variables.");
  for (int i=0; i<assignment.size(); ++i)
  {    
    // Domain::EventType dom_event =
    //   scope_[ i ]->enforceAssignment( assignment[ i ] );
    // if (dom_event == Domain::kFailed)
    //   { search_failed_ = true; return; }
    Domain::EventType dom_event =
      auxiliary_vars_[ i ]->silentAssignment( assignment[ i ] );
  }
}

bool DepthFirstSearch::nextSolution() 
{
  search_failed_ = false;
  search_ended_  = false;
    
  // check wheter the scope of the search is empty
  if( size() == zero_level_ )
  {
    search_ended_ = true; 
    //curr_solution_.setCost( 0 );
    return true;
  }

  curr_solution_.reset();
  bool find_sol = iSearchStep();

  // When the search ends, it retores the variable states, which were 
  // held before the first propagation.
  if (search_ended_)
    search_stack_.restore( 0 );

  return find_sol;
}


bool DepthFirstSearch::bestSolution() 
{
  search_failed_ = false;
  search_ended_  = false;

  search_stack_.restore( 0 );

  // check wheter the scope of the search is empty
  if( size() == zero_level_ )
  { 
    search_ended_ = true; 
    best_solution_.setCost( 0 );
    return true;
  }

  best_solution_.reset();
  curr_solution_.reset();
  curr_level_ = zero_level_;
  
  // Search Best Solution
  rSearch();
  search_ended_ = true;
  return (Constants::isFinite( best_solution_.cost() ));
}


bool DepthFirstSearch::allSolutions()
{
  search_failed_ = false;
  search_ended_  = false;

  search_stack_.restore( 0 );

  // check wheter the scope of the search is empty
  if( size() == zero_level_ )
  { 
    search_ended_ = true; 
    curr_solution_.setCost( 0 );
    best_solution_.setCost( 0 );
    return true;
  }
 
  curr_level_ = zero_level_;
  curr_solution_.reset();
  best_solution_.reset();
  
  while (!search_ended_) {
    iSearchStep();
    solutions_.push_back( curr_solution_ );
  }

  return (not solutions_.empty());
}


// private
bool DepthFirstSearch::rSearch()
{
  if (curr_level_ == size()) {
    return processSolution();
  }
  
  size_t trail_pt = search_stack_.size();
  IntVariable& var = nextVariable();
  int val = var.domain().min() - 1; 

  // std::cout << "DFS::var: " << var.dump() << " val: " << val
  //   << " - trail_pt: " << trail_pt_[ curr_level_ ] << std::endl;
    
  while (labeling( var, val ))
  {
    // std::cout << "DFS::var: " << var.dump() << " val: " << val
    //   << " - trail_pt: " << trail_pt_[ curr_level_ ] << std::endl;
    
    ++curr_level_;
    rSearch();
    search_stack_.restore(trail_pt);
    --curr_level_;
  }
  return true;
}


// private
bool DepthFirstSearch::iSearchStep( )
{
  // Restore to previous last level if coming form a solution.
  if( curr_level_ == size() )
    search_stack_.restore( trail_pt_[ --curr_level_] );

  while (curr_level_ >= zero_level_)
  {
    IntVariable& var = nextVariable();
    int val = var.lastChoice();
    trail_pt_[ curr_level_ ] = search_stack_.size();    
    
    // std::cout << "DFS::var: " << var.name() << " val: " << val
    //   << " trail_pt: " << trail_pt_[ curr_level_ ] << std::endl;
    
    if (labeling(var, val))
    {
      // std::cout << "DFS::var: " << var.name() << " val: " << val
      //   << " - trail_pt: " << trail_pt_[ curr_level_ ] << std::endl;

      // @todo -  Compute partial cost and check bounds. 
      if (++curr_level_ == size()) {
        bool sol = processSolution();
        // Restore to previous level
        if (sol) return true;
        search_stack_.restore( trail_pt_[ --curr_level_] );
      }
    }
    else {
      --curr_level_;
      // std::cout << "FAIL - restornig trailpt: " << trail_pt_[curr_level_] << "\n";
      if (curr_level_ >= zero_level_) {
        search_stack_.restore( trail_pt_[curr_level_] );
      }
    }
  }

  search_ended_ = true;		// Flag search termination
  curr_level_ = zero_level_; 	// Reset currLevel counter
  return false; 		// All domains are now emtpy
}


bool DepthFirstSearch::labeling(IntVariable& var, int& val)
{
#ifdef VERBOSE_TIMEOUT
  // This need to be sobstituited by an OBSERVER PATTERN
  owner().statistics().setSimulatedTime(owner().statistics().stopwatch()); 
  owner().checkOutOfLimits();
  owner().statistics().setStartTimer();
#endif
  
  int next = var.domain().nextValue(val);
  if (next == val) {		// No more values to label
    var.resetLastChoice();
    return false;
  }
  val = next;			// set the returning value
  return (var.enforceAssignment( val ) != Domain::kFailed);
}



IntVariable& DepthFirstSearch::nextVariable()
{
  //while (scopeAt(curr_level_).isSingleton());
  return scopeAt(curr_level_);
}


bool DepthFirstSearch::processSolution()
{
  if( p_soft_consistency->enforceConsistency() ) {
    saveSolution();
    curr_solution_.setCost( p_soft_consistency->cost() );    
    // std::cout << "sol found: " << curr_solution_.dump() << "\n";
    
    // update best solution if necessary
    if (Utils::isBetter(curr_solution_.cost(), best_solution_.cost())){
      best_solution_ = curr_solution_;
      // std::cout << "updated best solution\n";
    }
    return true;
  }
  else
    return false;
}


string DepthFirstSearch::dump() const
{
  string result = "Search[DFS]: ( ";
  for (auto &i : scope_)
    result += i->name() + ", ";
  result += ") - ";
  result += p_soft_consistency->dump();
  result += "curr-level: " + std::to_string(curr_level_) + 
    " zero level: " + std::to_string(zero_level_) + "\n";
  result += "trail pt: " + Utils::dump(trail_pt_) + "\n";
  result += "last value: " + Utils::dump(last_value_);
  return result;
}
