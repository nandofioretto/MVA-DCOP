#include "SearchEngines/search-engine-factory.hh"
#include "Utilities/utils.hh"


SearchEngine* SearchEngineFactory::create
  (Agent& owner, std::string type, std::vector<std::string> params)
{
  if (type.compare("DFS") == 0 or type.compare("dfs") == 0) {
    return new DepthFirstSearch(owner);
  }
  if (type.compare("BB") == 0 or type.compare("bb") == 0) {
    return new BranchAndBound(owner);
  }
  if (type.compare("Gibbs") == 0 or type.compare("gibbs") == 0) {
    if (params.size() == 2 ) {
      int nb_seeds = (int)(Utils::stringToInt(params[ 0 ]));
      int max_iter = (int)(Utils::stringToInt(params[ 1 ]));
      return new GibbsSampling(owner, nb_seeds, max_iter);
    }
    else if (params.size() == 1) {
      int nb_seeds = (int)(Utils::stringToInt(params[ 0 ]));
      return new GibbsSampling(owner, nb_seeds, 100);
    }
    else {
      return new GibbsSampling(owner, 1, 100);
    }
  }
  if (type.compare("Tableau") == 0 or type.compare("tableau") == 0) {
    return new Tableau(owner);
  }
  

  return nullptr;
}