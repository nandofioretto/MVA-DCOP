#ifndef ULYSSES_GPU_ALGORITHMS__DPOP__GPU_UTIL_PROPAGATION_H_
#define ULYSSES_GPU_ALGORITHMS__DPOP__GPU_UTIL_PROPAGATION_H_

#include "Algorithms/DPOP/util-propagation.hh"
#include "Algorithms/Orderings/pseudo-tree-ordering.hh"
#include "Kernel/Constraints/soft-consistency.hh"

#include <memory>

class Agent;
class UtilMsgHandler;
class SearchEngine;
class Codec;
class Solution;
class ValuePropagation;

typedef PseudoTreeOrdering PseudoNode;

// It implements the DPOP UTIL propagation phase for a given agent.
// It joins the UTIL tables received from its children in the UTIL messages
// and computes the UTIL table to send to its parent. 
class GPUUtilPropagation : public UtilPropagation
{
public:
  typedef std::unique_ptr<GPUUtilPropagation> uptr;
  typedef std::shared_ptr<GPUUtilPropagation> sptr;

  typedef size_t code_t;
  typedef std::pair<code_t, cost_t> utilpair_t;
  friend class ValuePropagation;

  // Initializes the constraints which involve the variables in the sparator
  // of the agent running this algorithms.
  GPUUtilPropagation(Agent& owner);

  virtual ~GPUUtilPropagation();
  
  // It initializes the algorithm: it registers the UTIL message handler in the
  // agent inbox, and it construct the local space as comibnation of all the 
  // possible value assignments to the boundary variables, optimizing on the 
  // private variables. It will be used in the UTIL message construction.
  virtual void initialize();

  // It executes the algorithm. It construct the UTIL message and merges the
  // UTIL messages received from its children optimizing over the possible 
  // combinations of the boundary values.
  virtual void run();
  
  // Optimize the ancestor solution over the boundary variables and the
  // values of the UTIL messages received 
  virtual void optimize(Solution& v_ancestor_sol);


private:
};

#endif // ULYSSES_ALGORITHMS__DPOP__UTIL_PROPAGATION_H_

