#include <algorithm>
#include <memory>
#include <vector>

#include "GPU/Algorithms/DPOP/gpu_util-propagation.hh"
#include "GPU/Algorithms/DPOP/gpu_util-table.hh"

#include "Utilities/utils.hh"
#include "Utilities/constraint-utils.hh"
#include "Kernel/globals.hh"
#include "Kernel/codec.hh"
#include "Kernel/Agents/agent.hh"
#include "Kernel/Variables/variable-factory.hh"
#include "Kernel/Variables/int-variable.hh"
#include "Kernel/Constraints/constraint-factory.hh"
#include "Kernel/Constraints/soft-consistency.hh"
#include "Algorithms/DPOP/util-msg-handler.hh"
#include "SearchEngines/solution.hh"
#include "Communication/mailbox.hh"
#include "Communication/scheduler.hh"
#include "SearchEngines/search-engine-factory.hh"
#include "SearchEngines/DepthFirstSearch/depth-first-search.hh"
#include "SearchEngines/BranchAndBound/branch-and-bound.hh"
#include "SearchEngines/Sampling/Gibbs/gibbs-sampling.hh"
#include "Problem/dcop-instance.hh"

using namespace std;

GPUUtilPropagation::GPUUtilPropagation(Agent& owner)
  : UtilPropagation(owner)
    { }


GPUUtilPropagation::~GPUUtilPropagation()
{ }


void GPUUtilPropagation::initialize()
{
  Mailbox& MB = owner().openMailbox();
  attachMailSystem("UTIL", p_msg_handler);

  int agentID = owner().id();
  int nb_bvars = owner().nbBoundaryVariables();
  int nb_pvars = owner().nbPrivateVariables();
  int dom_size = owner().localVariableAt(0).size();
  int nb_constr = owner().nbConstraints();
  
  size_t nb_rows = pow(dom_size, nb_bvars);
  int nb_cols = (nb_bvars + nb_pvars + 1);

  int* util_table;
  
  // Copy the results back on a Table ->
  GPU::computeUtilTable(agentID, nb_bvars, nb_pvars, nb_constr, dom_size, util_table);

  // Process the util_table to save the -> p_v_boundary_combo and the b_v_boundary_combo
  // STOP TIMER HERE (these operation are not actually needed in an optimized code)
  owner().statistics().setSimulatedTime(owner().statistics().stopwatch()); 
  std::vector<int> b_values;
  std::vector<int> p_values;
  cost_t cost = 0;
  
  for (int row = 0; row < nb_rows*nb_cols; row += nb_cols)
  {    
    b_values.assign( &util_table[ row ], &util_table[ row ] + nb_bvars );
    code_t b_code = p_v_boundary_codec->encode( b_values );
    cost = util_table[ row + (nb_bvars + nb_pvars) ];
    p_v_boundary_combo.push_back(std::make_pair(b_code, cost));
    
    p_values.assign( &util_table[ row + nb_bvars ], &util_table[ row + nb_bvars ] + nb_pvars );
    code_t p_code = p_v_private_codec->encode(p_values);
    p_best_v_private_combo.push_back(p_code);
  }
  owner().statistics().setStartTimer();
  
  // delete[] util_table;
  // ---------------------------------

}


void GPUUtilPropagation::run()
{
  // std::cout << owner().name() << " running\n";

  PseudoNode& tree_node = dynamic_cast<PseudoNode&>(owner().ordering());
  UtilMsgHandler &handler = *p_msg_handler;
 
  // _PPP is the set of parents and pseudo-parents of this agent. 
  std::vector<oid_t> _PPP(tree_node.pseudoParents().begin(), tree_node.pseudoParents().end());
  _PPP.push_back(tree_node.parent());

  // The set of children and pseudo-children of this agent
  std::vector<oid_t> _pc(tree_node.pseudoChildren().begin(), tree_node.pseudoChildren().end());
  std::vector<oid_t> _c(tree_node.children().begin(), tree_node.children().end());
  std::vector<oid_t> _CPC = Utils::merge(_pc, _c);
  
  std::vector<oid_t> c_ppp = ConstraintUtils::extractOwnedByAny(owner().interAgentConstraintIDs(), _PPP);  
  std::vector<oid_t> c_cpc = ConstraintUtils::extractOwnedByAny(owner().interAgentConstraintIDs(), _CPC);  

  // Excludes the constraints shared with some children and pseudo-children to 
  // the set of constraints shared with the parent and pseduo-parent. This may 
  // happen in case of n-ary constraints.
  std::vector<oid_t> v_ancestor = 
    Utils::exclude(ConstraintUtils::extractScope(c_cpc), 
		   ConstraintUtils::extractScope(c_ppp));
  std::vector<oid_t> v_boundary = owner().boundaryVariableIDs();

  // v_ancestor = \cup_{m \int recvMsgs} m.vars \cup \cup_{a_i \in PPP} B_i
  for (UtilMsg::sptr msg : handler.received())
    Utils::merge_emplace(v_ancestor, msg->variables());
  
  // Get all the constraints involving any of the agent's boundary variable
  // with some boundary variable of the agent parent and pseudoparents.
  std::vector<oid_t> c_ancestor = ConstraintUtils::involvingExclusively( v_ancestor, owner().id() );
  std::vector<oid_t> c_boundary = ConstraintUtils::involvingExclusively( v_boundary, owner().id() );

  // Remove the constraints involving exclusively the boundary variables.
  Utils::exclude_emplace(c_boundary, c_ancestor);

  // Removes the agents' boundary vars, and gets the set of variables to be
  // sent in the UTIL message. 
  Utils::exclude_emplace(v_boundary, v_ancestor); // will sort the vectors

  // Init optimization Data stuctures
  handler.initialize(v_boundary, v_ancestor); 
  p_v_ancestor_codec = Codec::uptr(new Codec(v_ancestor));
  p_ancestor_consistency->initialize(Utils::concat(v_boundary, v_ancestor), c_ancestor);
  
  p_ba_values.resize( v_boundary.size() + v_ancestor.size() );

  // Search All best solutions for each combo of external-variables
  p_v_ancestor_search->initialize(v_ancestor, std::vector<oid_t>()/*c_ancestor*/);
  
  if(tree_node.isRoot())
  {
    Solution empty;
    optimize(empty);
    
    // Result is stored in the only entry of the UTIL message
    cost_t opt_cost = handler.outgoing().utilAt(0);
    // Save best cost in DCOPinfo
    g_dcop->setCost(opt_cost);

    if (!Constants::isFinite(opt_cost))
    {
      p_terminated = true;
      return;
    }
    
    // Save Solution
    int opt_b_idx = p_ancestorval2bcomboidx[ 0 ];
    size_t opt_b_code = p_v_boundary_combo[ opt_b_idx ].first;
    size_t opt_p_code = p_best_v_private_combo[ opt_b_idx ];
    std::vector<int> opt_v_boundary = p_v_boundary_codec->decode(opt_b_code);
    std::vector<int> opt_v_private  = p_v_private_codec->decode(opt_p_code);

    std::vector<std::pair<oid_t, int> > sol =
      Utils::make_pairs(Utils::concat(owner().boundaryVariableIDs(), 
				                              owner().privateVariableIDs()),
			                  Utils::concat(opt_v_boundary, opt_v_private));

    owner().saveSolution( sol );
    
  }
  else 
  {    
    while (p_v_ancestor_search->nextSolution())
    {
      Solution& v_ancestor_sol = p_v_ancestor_search->getSolution();
      // Optimize over vboundary_combo_ by also solving the constraints 
      optimize(v_ancestor_sol);
    }    
    handler.prepareOutgoing();
    handler.send( tree_node.parent() );
  }
  p_terminated = true;
}


// Optimize over the boundary variables, by integrating the received message costs
// and the constraints given as a parameter.
void GPUUtilPropagation::optimize(Solution& v_ancestor_sol)
{
  cost_t curr_sum = 0;
  cost_t best_sum = Constants::worstvalue;
  size_t best_bidx = -1;  

  // Values corresponding to the variables 
  for( int i=0; i<p_v_boundary_combo.size(); ++i)
  {
    curr_sum = 0;
    // retrieve solution: 
    std::vector<int>& b_values = p_v_boundary_codec->decode( p_v_boundary_combo[ i ].first );

    // std::cout << "checking combo: " << Utils::dump(b_values) << " ";
 
    Utils::concat_emplace(p_ba_values, b_values, v_ancestor_sol.values());   

    // std::cout << "(ba_values: " << Utils::dump(p_ba_values) << ") : ";

    // Add cost from all UTIL messages:
    cost_t u = p_msg_handler->msgCosts( p_ba_values );
    
    // Disable the if else -> "continue" to match the same NCCCs metrics as in FRODO
    if (Constants::isFinite( u ))
      curr_sum = Utils::sum(curr_sum, u);
    else 
      continue;
    // std::cout << "c_msgs: " << u;

    // Add cost of boundary values combination (optimzed over private vars)
    curr_sum = Utils::sum(curr_sum, p_v_boundary_combo[ i ].second);

    // std::cout << " + c_boun: " << p_v_boundary_combo[ i ].second;
 
    // Add cost of constraints of the inter agent variables
    if( p_ancestor_consistency->enforceConsistency( p_ba_values ) )
    {
      // std::cout << " + c_ances: " << p_ancestor_consistency->cost();
      curr_sum = Utils::sum(curr_sum, p_ancestor_consistency->cost());
      // std::cout << " = " << curr_sum;
    }
    else {
      // std::cout << " -> Failed!\n";
      continue;
    }

    if (Utils::isBetter(curr_sum, best_sum)) {
      // std::cout << " [new best] ";
      best_sum = curr_sum;
      best_bidx = i;
    }
    // std::cout << endl;
  }
  
  // Save in UTIL
  if (Constants::isFinite(best_sum))
  {
    p_msg_handler->saveUtil( v_ancestor_sol.values(), best_sum );
    // Store in local copy the ancestor util combo, and the best boundary index
    // to be used for fast retrival of boundary values during the VALUE 
    //propagation phase:
    code_t anc_key = p_v_ancestor_codec->encode( v_ancestor_sol.values() );
    p_ancestorval2bcomboidx[anc_key ] = best_bidx;
    
    owner().statistics().incrUsedMemory(sizeof(code_t));
    
    // std::cout << "--storing " << Utils::dump(v_ancestor_sol.values()) << " cost: " << best_sum << std::endl;
  }

}
