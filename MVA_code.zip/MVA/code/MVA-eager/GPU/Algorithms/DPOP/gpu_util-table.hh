#ifndef ULYSSES_GPU_ALGORITHMS_DPOP_UTIL_TABLE_H
#define ULYSSES_GPU_ALGORITHMS_DPOP_UTIL_TABLE_H

#include <vector>
#include <utility>      // std::pair, std::make_pair

namespace GPU
{
  void computeUtilTable(int agentID, int nb_bvars, int nb_pvars, int nb_constr, int dom_size, int* &util_table);
};

#endif // ULYSSES_GPU_ALGORITHMS_DPOP_UTIL_TABLE_H
