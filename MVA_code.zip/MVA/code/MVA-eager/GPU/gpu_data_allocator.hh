#ifndef ULYSSES_GPU_DATA_ALLOCATOR_H
#define ULYSSES_GPU_DATA_ALLOCATOR_H

#include <vector>
#include <utility>      // std::pair, std::make_pair

namespace GPU
{
  void initGlobalMemory(int dcop_nbAgents, int dcop_nbVariables, int dcop_nbConstraints, int dom_size, int dev_ID=0);
  void initAgent(int agentID, std::vector<int> b_varsID, std::vector<int> b_consID, 
      std::vector<int> p_varsID, std::vector<int> p_consID, int p_nb_variables);
  void initVariable(int varID, int min, int max);
  void initConstraint(int conID, std::vector<int> scopeID, std::vector<int> domains_size, 
      std::vector< std::pair< std::vector<int>, int> > utils, int def_cost);
  void initUTILTable(int agentID, int nb_bvars, int nb_pvars, int domsize);
  // void free();

  void dumpUtilTable(int agentID);
};

#endif // ULYSSES_GPU_DATA_ALLOCATOR_H
