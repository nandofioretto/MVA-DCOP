#ifndef ULYSSES_GPU_DEV_GLOBALS_H
#define ULYSSES_GPU_DEV_GLOBALS_H

/* Common dependencies */
#include <stdlib.h> // for atoi
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#include <cuda.h>
//#include <curand_kernel.h>


/* Tesla C2075 */
#define TOT_GLOBAL_MEM 1341587456
#define TOT_SHARED_MEM 49152  // per block
#define TOT_REGISTERS  32768  // per block
#define MAX_DIM_GRID   65535
#define MAX_DIM_BLOCK  1024
#define WARP_SIZE      32
#define CLOCK_RATE     1147000

#define cudaCheck(ans) { gpuAssert((ans), __FILE__, __LINE__); }
inline void gpuAssert(cudaError_t code, char *file, int line, bool abort=true)
{
  if (code != cudaSuccess) 
  {
    fprintf(stderr,"GPUassert: %s %s %d\n", cudaGetErrorString(code), file, line);
    if (abort) exit(code);
  }
}

// Assumption: Problem = minimization; Constraint arity = 2; domain sizes all equal

// The variable class
struct dev_class_Variable
{
  int ID;
  int dom_min;
  int dom_max;
};

// The Constraint class
struct dev_class_Constraint
{
  int ID;
  int arity;          // Fixed to 2
  int* scopeID;       // The position in the array gdev_Agent::variables_ID
  int* utils;    // The set of all utilities of the constraint

  int def_cost;  // The default cost
  // long int* ss_idx3D; // start and stop indexes for tuples in constraints with arity > 3
  // int* tuples;
};

// Local Structures (Agent)
struct dev_class_Agent
{
  int ID;
  int device_ID;        // The device id where the Agent is running.
  int nb_variables;     // The number of agent variables.
  int* variables_ID;    // The variables ID controlled by this agent and ordered so that boundary
                        // are listed first and the private variables are listed after. 
  int nb_boundary_vars;
  int nb_private_vars;

  int nb_constraints;   // The number of constraints
  int* constraints_ID;  // The list of constraints ID (or position) referred to those listed in the gdev_Constraints;
  int* map_varsID;
  
  int nb_boundary_cons;
  int nb_private_cons;
  
  int* DPOP_util_table; // The util table associated to the current agent where variables are 
                        // store s.t. boundary are listed first, then best private combo and then cost.
  int nb_bvars_combo;   // The number of util table rows.

  // int* b_vars_constraints_ID;
  // int* l_vars_constraints_ID;
};


struct host_class_DevMirror
{
  int* DPOP_util_table_DevPtr;
  int* DPOP_util_table;
  size_t DPOP_util_table_size;
  size_t DPOP_util_table_rows;
  size_t DPOP_util_table_cols;
  
  void dumpDPOPUtilTable() {
    for (int r=0; r<DPOP_util_table_rows; r++) {
      for (int c=0; c<DPOP_util_table_cols; c++) {
        if (c == DPOP_util_table_cols-1) printf(": ");
        printf("%d ", DPOP_util_table[ r * DPOP_util_table_cols + c ]);
      }
      printf("\n");
    }   
  }
};


size_t g_hash_util( int d, int a, int T[] );
void g_hash_tuple(int* T, int d, int a, size_t idx );
__device__ int ipow(int base, int exp);
__device__ int cuda_hash_util( int d, int scope[], int a, int T[]);
__device__ int cuda_hash_util2( int d, int scope[], int a, int T[], int i_sobst, int i_val);
__device__ void cuda_hash_tuple(int* T, int d, int a, size_t idx );


extern __device__ int gdev_nb_constraints;
extern __device__ int gdev_nb_variables;
extern __device__ int gdev_nb_agents;
extern __device__ int gdev_dom_size;
extern __device__ int gdev_opt_type;       // The optimization type (maximize / minimize [default]) 
extern __device__ long int gdev_infty;     // The infinity cost

extern __device__ dev_class_Constraint* gdev_Constraints;
extern __device__ dev_class_Variable*   gdev_Variables;
extern __device__ dev_class_Agent*      gdev_Agents;
extern host_class_DevMirror*  host_class_DevMirrors;


// DEPRECATED:::
// This structure is used to mantain the ptrs hangling from the use of 
// different agents on the same DEVICE
// This struct is mantained on HOST
// struct g_AgentMemoryAgenda
// {
//   long int* samples;
//
//   int nconstr;
//   g_AgentDS_Constr* constr;
//   int** scope;      // vector of pointers of size nconstr
//   long int** utils; // vector of pointers of size nconstr
//   long int** ss_idx3D; // start and stop indexes for tuples in constraints with arity > 3
//   int** tuples;
// };
// extern g_AgentMemoryAgenda hostAgentMemory;

#endif // ULYSSES_GPU_DEV_GLOBALS_H